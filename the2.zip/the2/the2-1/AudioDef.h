/////////////////audiodef.h/////////////

#if !defined(__STRUCT__AUDIO_DEFINE__2002)
#define __STRUCT__AUDIO_DEFINE__2002
//////////////////////////////////////////
#define INIT_GUID
#define LPDIRECTMUSICLOADER8	  IDirectMusicLoader8*
#define LPDIRECTMUSICPERFORMANCE8 IDirectMusicPerformance8*
#define LPDIRECTMUSICSEGMENT8	  IDirectMusicSegment8*
#define LPDIRECTMUSICAUDIOPATH	  IDirectMusicAudioPath*
#define LPDIRECTCSound3DBUFFER	  IDirectSound3DBuffer*
#define LPDIRECTCSound3DLISTENER  IDirectSound3DListener*
#define LPDIRECTSHOWGRAPHBUILDER  IGraphBuilder* 
#define LPDIRECTSHOWMEDIACONTROL  IMediaControl* 
#define LPDIRECTSHOWMEDIAPOSITION IMediaPosition* 
/////////////////////////////////////////////

#define   MAX_SOUND_NUM      64

//// define sound state
#define   SOUND_2D_PLAYING  -2
#define   SOUND_2D_IDLE     -1
#define   SOUND_NULL         0
#define   SOUND_3D_IDLE      1
#define   SOUND_3D_PLAYING   2

#define   MUSIC_ERROR       -1
#define   MUSIC_NULL         0
#define   MUSIC_IDLE         1
#define   MUSIC_PLAYING      2
#define   MUSIC_PAUSE        3
/////////////////////////////////
/// define sound resource id

#define   MENU_SOUND_BKG        0
#define   MENU_SOUND_ONITEM     1
#define   MENU_SOUND_CLICK      2
#define   MENU_SOUND_SELECT     3

#define   MENU_SOUND_TEST       4
#define   MENU_SOUND_TEST1      5
#define   MENU_SOUND_TEST2      6

#define   SOUND_RUN_0           10
#define   SOUND_RUN_1           11
#define   SOUND_RUN_2           12
#define   SOUND_RUN_3           13

#define   SOUND_AMBIENT         15
#define   SOUND_BIRD_0          16
#define   SOUND_BIRD_1          17
#define   SOUND_BIRD_2          18
#define   SOUND_BIRD_3          19
#define   SOUND_BIRD_4          20
#define   SOUND_BIRD_5          21
#define   SOUND_BIRD_6          22
#define   SOUND_BIRD_7          23
#define   SOUND_BIRD_8          24
#define   SOUND_BIRD_9          25

#define   SOUND_GUN_SINGLE      27
#define   SOUND_GUN_MULTI       28
#define   SOUND_GUN_RIFLE       29
#define   SOUND_BULLET_WHIZ     30

#define   SOUND_PAIN_1          32
#define   SOUND_PAIN_2          33
#define   SOUND_PAIN_3          34

#define   SOUND_DEATH_1         37
#define   SOUND_DEATH_2         38
#define   SOUND_DEATH_3         39




////////////////////////////////////////////////
#endif 
 