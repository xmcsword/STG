// House.cpp: implementation of the CHouse class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "House.h"
#include "math.h"
#include "texture.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHouse::CHouse()
{
    m_pModel=NULL;
	m_pSmoke=NULL;
	m_bSomking=true;
}

CHouse::~CHouse()
{
}
bool CHouse::InitHouse(CMs3dLoader *pModel,CSmokeParticle *pSmoke,
					   VERTEX position,float roty,unsigned int texid,bool bSmoking)
{
    m_pModel=pModel;
	if(m_pModel==NULL)return false;
	m_pSmoke=pSmoke;
	if(m_pSmoke==NULL)return false;

	m_position.xpos=position.xpos;
	m_position.zpos=position.zpos;
	m_position.ypos=m_cHmap.GetHeight(m_position.xpos,m_position.zpos);

	m_roty=roty;
    m_texID=texid;

    VERTEX v1=pModel->GetVertex(72);
    VERTEX v2=pModel->GetVertex(76);
 
    m_somkePos.xpos=m_position.xpos+(v1.xpos+v2.xpos)/2;
    m_somkePos.ypos=m_position.ypos+(v1.ypos+v2.ypos)/2;
    m_somkePos.zpos=m_position.zpos+(v1.zpos+v2.zpos)/2;
	
	m_bigBoundary.minx = m_pModel->m_boundary.minx + m_position.xpos;
	m_bigBoundary.maxx = m_pModel->m_boundary.maxx + m_position.xpos;
	m_bigBoundary.miny = m_pModel->m_boundary.miny + m_position.ypos;
	m_bigBoundary.maxy = m_pModel->m_boundary.maxy + m_position.ypos;
	m_bigBoundary.minz = m_pModel->m_boundary.minz + m_position.zpos;
	m_bigBoundary.maxz = m_pModel->m_boundary.maxz + m_position.zpos;

	VERTEX v3=pModel->GetVertex(51);
	VERTEX v4=pModel->GetVertex(69);

 	m_smallBoundary.maxx=v4.xpos + m_position.xpos;
	m_smallBoundary.minx=v3.xpos + m_position.xpos;

	m_smallBoundary.maxy=v4.ypos + m_position.ypos;
	m_smallBoundary.miny=v3.ypos + m_position.ypos;

	m_smallBoundary.maxz=v4.zpos + m_position.zpos;
	m_smallBoundary.minz=v3.zpos + m_position.zpos;


	m_bSomking=bSmoking;

	return true;

}
void CHouse::DrawHouse()
{
    if(!m_cHmap.IsInFrustum(&m_bigBoundary))return;

    glPushMatrix();	

	glTranslatef(m_position.xpos,m_position.ypos,m_position.zpos);
    glRotatef(m_roty,  0.0f,1.0f,0.0f); 
	
 	glBindTexture(GL_TEXTURE_2D,m_texID);
	glEnable(GL_TEXTURE_2D);
	m_pModel->Render();

    glPopMatrix();
	CHeightmap::m_numTriangles += 181 ;
}
void CHouse::DrawSmoke()
{
	if(!m_bSomking)return ;
    if(!m_cHmap.IsInFrustum(&m_bigBoundary))return;

    glPushMatrix();	

    glTranslatef(m_somkePos.xpos,m_somkePos.ypos,m_somkePos.zpos);

    glRotatef(m_cHmap.m_ViewRotY,  0.0f,1.0f,0.0f);
    glRotatef(-m_cHmap.m_ViewRotX,  1.0f,0.0f,0.0f);
		
	m_pSmoke->DrawParticle();

    glPopMatrix();
	CHeightmap::m_numTriangles += 100 ;
}
void CHouse::SetSmoking(bool bSomking)
{
    m_bSomking=bSomking;
}