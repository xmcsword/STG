// MediaPlayer.cpp: implementation of the CMediaPlayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MediaPlayer.h"

LPDIRECTSHOWGRAPHBUILDER   CMediaPlayer::m_pGraph=NULL;
LPDIRECTSHOWMEDIACONTROL   CMediaPlayer::m_pMediaControl=NULL;
LPDIRECTSHOWMEDIAPOSITION  CMediaPlayer::m_pMediaPosition=NULL;
int                        CMediaPlayer::m_musicState=MUSIC_NULL;
bool                       CMediaPlayer::m_bActive=true;
REFTIME                    CMediaPlayer::m_tmDuration=0;
int                        CMediaPlayer::m_numUser=0;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMediaPlayer::CMediaPlayer()
{
	if(m_numUser==0)
	{
        if(!Init())
		{
			m_musicState=MUSIC_ERROR;
			m_bActive=false;
		}
	}
	m_numUser++;
}

CMediaPlayer::~CMediaPlayer()
{
	m_numUser--;
	if(m_numUser==0)
	{
	    if(m_pGraph!=NULL)
		{
		    m_pGraph->Release();
	    	m_pGraph=NULL;
		}
	    if(m_pMediaControl!=NULL)
		{
		    m_pMediaControl->Release();
	    	m_pMediaControl=NULL;
		}
	    if(m_pMediaPosition!=NULL)
		{
		    m_pMediaPosition->Release();
	    	m_pMediaPosition=NULL;
		}
		m_musicState=MUSIC_NULL;
	}
}

bool CMediaPlayer::Init()
{

	HRESULT hr;
	hr=CoCreateInstance(CLSID_FilterGraph, NULL,
                     CLSCTX_INPROC, IID_IGraphBuilder, (void**)&m_pGraph);
	if(FAILED(hr))
	{
//		MessageBox(NULL, "Unable to CoCreateInstance IID_IGraphBuilder", "ERROR", MB_OK);
        m_pGraph=NULL;
		return false;
	}

	hr=m_pGraph->QueryInterface(IID_IMediaControl, (void**)&m_pMediaControl);
	if(FAILED(hr))
	{
		m_pMediaControl=NULL;
//		MessageBox(NULL, "QueryInterface IID_IMediaControl error", "ERROR", MB_OK);
		return false;
	}
	hr=m_pGraph->QueryInterface(IID_IMediaPosition, (void**)&m_pMediaPosition);
	if(FAILED(hr))
	{
//		MessageBox(NULL, "QueryInterface IID_IMediaPosition error", "ERROR", MB_OK);
		m_pMediaPosition=NULL;
		return false;
	}
    m_musicState=MUSIC_NULL;
	return true;
}
bool CMediaPlayer::CreateMusic(char *filename)
{

	if(m_musicState==MUSIC_ERROR|| m_musicState!=MUSIC_NULL)return false;
	HRESULT hr;
	WCHAR wcharStr[MAX_PATH];

	//Convert the file name to the string that DirectAudio needs
	MultiByteToWideChar(CP_ACP, 0, filename, -1, wcharStr, MAX_PATH);

	hr=m_pGraph->RenderFile(wcharStr, NULL);
	if(FAILED(hr))
	{
		MessageBox(NULL, "Load music file err", "ERROR", MB_OK);
		return false;
	}
	m_musicState=MUSIC_IDLE;

    m_pMediaPosition->get_Duration(&m_tmDuration);

	return true;
}
void CMediaPlayer::Play()
{
	if(m_musicState==MUSIC_ERROR|| 
	   m_musicState==MUSIC_NULL )return;
	if(!m_bActive)return;

	REFTIME curTime;
    m_pMediaPosition->get_CurrentPosition(&curTime);
    m_pMediaPosition->put_CurrentPosition(curTime);
	m_pMediaControl->Run();
	m_musicState=MUSIC_PLAYING;
}
void CMediaPlayer::Pause()
{
	if(m_musicState==MUSIC_ERROR || m_musicState==MUSIC_NULL)return;
    m_pMediaControl->Pause();
	m_musicState=MUSIC_PAUSE;
}
void CMediaPlayer::Stop()
{
	if(m_musicState==MUSIC_ERROR)return;
    m_pMediaControl->Stop();
    m_pMediaPosition->put_CurrentPosition(0);
	m_musicState=MUSIC_IDLE;
}
void CMediaPlayer::SetVolume(int iVolume)
{
	if(m_musicState==MUSIC_ERROR)return;
    IBasicAudio* pBA;
	HRESULT hrErr = m_pGraph->QueryInterface(IID_IBasicAudio,(void**)&pBA); 
	if(FAILED(hrErr)) return ; 
	if(iVolume<0)iVolume=0;
	if(iVolume>100)iVolume=100;
    iVolume=-6000+iVolume*100;
	pBA->put_Volume(iVolume);  
	pBA->Release();  
}
int CMediaPlayer::GetRemainTime()
{
	if(m_musicState==MUSIC_ERROR)return -1;
	REFTIME curTime;
    m_pMediaPosition->get_CurrentPosition(&curTime);
    return  int(m_tmDuration-curTime);
}
bool CMediaPlayer::IsMediaEnable()
{
    if(m_musicState==MUSIC_ERROR)return false;
	return true;
}
void CMediaPlayer::SetMediaActive(bool bActive)
{
    m_bActive=bActive;
}
bool CMediaPlayer::IsMediaActive()
{
    return m_bActive;
}