// LensFlare.cpp: implementation of the CLensFlare class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LensFlare.h"
#include "texmanager.h"
#include "GameSetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLensFlare::CLensFlare()
{
}
CLensFlare::~CLensFlare()
{
}
bool CLensFlare::InitLensFlare()
{
	CTexManager cTexManager;
	m_texFlare[0]=cTexManager.GetTextureID(TEX_LENSFLARE_0);
	m_texFlare[1]=cTexManager.GetTextureID(TEX_LENSFLARE_1);
	m_texFlare[2]=cTexManager.GetTextureID(TEX_LENSFLARE_2);
	m_texFlare[3]=cTexManager.GetTextureID(TEX_LENSFLARE_3);
	m_texFlare[4]=cTexManager.GetTextureID(TEX_LENSFLARE_4);
	m_texFlare[5]=cTexManager.GetTextureID(TEX_LENSFLARE_5);
	m_texFlare[6]=cTexManager.GetTextureID(TEX_LENSFLARE_6);

	m_LightPos=VERTEX(128000,30000,-72000);

    return true;
}
void CLensFlare::RenderLensFlare()
{
	if(!CheckLightVisible())return;

	float size=0.06f;
    float offset=1;
	glAlphaFunc(GL_GEQUAL,0.15f);
	glEnable(GL_ALPHA_TEST);

	glDisable(GL_DEPTH_TEST);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glEnable(GL_BLEND);
   	glEnable(GL_TEXTURE_2D); 
    glPushMatrix();	

	glTranslatef(m_cHmap.m_ViewPos.xpos,m_cHmap.m_ViewPos.ypos,m_cHmap.m_ViewPos.zpos);
  	glRotatef(m_cHmap.m_ViewRotY,  0.0f,1.0f,0.0f);
	glRotatef(-m_cHmap.m_ViewRotX,  1.0f,0.0f,0.0f);
    /////////////////////1
	glBindTexture(GL_TEXTURE_2D, m_texFlare[1]);
	glColor3f(0.05f,0.3f,0.5f);

	offset=1.3f;
	size=0.08f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
    /////////////////////2
	glBindTexture(GL_TEXTURE_2D, m_texFlare[2]);
	glColor3f(0.0f,0.3f,0.5f);
	
	offset=0.7f;
	size=0.03f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
    /////////////////////3
	glBindTexture(GL_TEXTURE_2D, m_texFlare[3]);
	glColor3f(0.05f,0.3f,0.5f);
	 
	offset=0.5f;
	size=0.04f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
    /////////////////////4
	glBindTexture(GL_TEXTURE_2D, m_texFlare[4]);
	glColor3f(0.4f,0.1f,0.0f);
	 
	offset=0.1f;
	size=0.06f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
    /////////////////////5
	glBindTexture(GL_TEXTURE_2D, m_texFlare[5]);
	glColor3f(0.3f,0.05f,0.0f);
	 
	offset=-0.3f;
	size=0.12f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
    /////////////////////6
	glBindTexture(GL_TEXTURE_2D, m_texFlare[6]);
	glColor3f(0.3f,0.0f,0.0f);
	 
	offset=-0.9f;
	size=0.14f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(sx*offset-size,sy*offset-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(sx*offset+size,sy*offset-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(sx*offset+size,sy*offset+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(sx*offset-size,sy*offset+size,-1.03923f);
    glEnd();	
	////////////////////////////////////////////////
	/////////////////////Draw light Shine
	
	glBindTexture(GL_TEXTURE_2D, m_texFlare[0]);
	glTranslatef(sx,sy,0);
	float dist=float(sqrt(sx*sx+sy*sy));

    glRotatef((m_cHmap.m_ViewRotY+m_cHmap.m_ViewRotX)*2,  0.0f,0.0f,1.0f);
	glColor3f(0.7f-dist*0.2f,0.5f-dist*0.5f,0.4f-dist*0.6f);

    glColor3f(0.8f+dist*0.5f,0.6f-dist*0.4f,0.2f);//0.3f-dist*0.4f);

	size=0.17f-dist*0.04f;
  	glBegin(GL_QUADS);
	    glTexCoord2f(0,0);
		glVertex3f(-size,-size,-1.03923f);

    	glTexCoord2f(1,0);
		glVertex3f(+size,-size,-1.03923f);

	    glTexCoord2f(1,1);
		glVertex3f(+size,+size,-1.03923f);

	    glTexCoord2f(0,1);
		glVertex3f(-size,+size,-1.03923f);
    glEnd();	
	////////////////////////////////////////////////
	glColor3f(1,1,1);
glPopMatrix();
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);

}
bool CLensFlare::CheckLightVisible()
{
	VERTEX v0=VERTEX(m_LightPos.xpos-m_cHmap.m_ViewPos.xpos,
		             m_LightPos.ypos-m_cHmap.m_ViewPos.ypos,
					 m_LightPos.zpos-m_cHmap.m_ViewPos.zpos);
	float rotx=m_cHmap.m_ViewRotX;
	float roty=m_cHmap.m_ViewRotY;
	//////// y rotate
    VERTEX v1=VERTEX(v0.xpos*cosf(roty*0.0174533f)-
		             v0.zpos*sinf(roty*0.0174533f),
			         v0.ypos,
                     v0.xpos*sinf(roty*0.0174533f)+
		             v0.zpos*cosf(roty*0.0174533f));

    //////// x rotate
    VERTEX v2=VERTEX(v1.xpos,
		             v1.ypos*cosf(rotx*0.0174533f)-
		             v1.zpos*sinf(rotx*0.0174533f),
                     v1.ypos*sinf(rotx*0.0174533f)+
		             v1.zpos*cosf(rotx*0.0174533f));

	////////////////////
	if(v2.zpos>-1)return false;
	double scale=-1.03923/v2.zpos;
	sx=float(v2.xpos*scale);
	sy=float(v2.ypos*scale);
	if(sx>0.8f || sx<-0.8f)return false;
	if(sy>0.6f || sy<-0.6f)return false;

	//////// Check Visible
	int halfScrW=CGameSetting::m_iScrWidth/2;
	int halfScrH=CGameSetting::m_iScrHeight/2;
	float depth[4];

	glReadPixels(int(sx*500)+halfScrW,halfScrH+int(sy*500),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW+5,halfScrH+int(sy*500)+5,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW+5,halfScrH+int(sy*500)-5,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW-5,halfScrH+int(sy*500)+5,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW-5,halfScrH+int(sy*500)-5,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW+10,halfScrH+int(sy*500),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW-10,halfScrH+int(sy*500),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW,halfScrH+int(sy*500)+10,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
	glReadPixels(int(sx*500)+halfScrW,halfScrH+int(sy*500)-10,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);
    if(depth[0]>0.9999f)return true;
 
    return false;
}
