// 3DTree.h: interface for the C3DTree class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DTREE_H__C1CB6201_9BF6_11D6_813B_5254AB37CDC9__INCLUDED_)
#define AFX_3DTREE_H__C1CB6201_9BF6_11D6_813B_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "structdef.h"

class C3DTree  
{
public:
	C3DTree();
	virtual ~C3DTree();
    bool Init3DTree(int treeType,float treeSize=0.2f);
	void Render3DTree(VERTEX position);

protected:
    void Draw3DTree();
	void DrawBranch(float width,float height);
	void DrawYellowTree();
	void DrawGreenTree();
	void DrawTop(float width,float height);

	float m_szTree;
	float m_height;
	int   m_type;

    unsigned int texTreeBody;
	unsigned int texBranch;

};

#endif // !defined(AFX_3DTREE_H__C1CB6201_9BF6_11D6_813B_5254AB37CDC9__INCLUDED_)
