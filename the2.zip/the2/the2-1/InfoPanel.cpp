// InfoPanel1.cpp: implementation of the CInfoPanel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InfoPanel.h"
#include "texManager.h"
#include "imgtext.h"
#include "stdio.h"
#include "input.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInfoPanel::CInfoPanel()
{
	m_gunBiasY=0;
	m_gunBiasAngleY=0;
	m_gunBiasZ=0;
	m_gunBiasX=0;
	m_gunBiasAngleX=0;

	m_bHelpOpen=false;
	m_bFire=false;	
}
CInfoPanel::~CInfoPanel()
{
}
bool CInfoPanel::InitInfoPanel()
{
	CTexManager cTex;
	if(!m_myWeapon.InitSMFLoader("model/soldier/mygun.smf",cTex.GetTextureID(TEX_MY_GUN),1))
    	return FALSE;

	m_texMetal=cTex.GetTextureID(TEX_METAL);
	m_texNavigator=cTex.GetTextureID(TEX_NAVIGATOR);
	m_texHelp=cTex.GetTextureID(TEX_HELP);

	m_cGunFire.InitGunFire(0.8f,1.2f);

	m_gunMouth=m_myWeapon.GetPos(SMF_GUN_MOUTH);

	return true;
}
void CInfoPanel::DrawInfoPanel()
{
	glColor3f(0,1,0);
	CHeightmap cHmap;

	double dist=sqrt(cHmap.m_distFromFocus);

	glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);
//	DrawMyWeapon();
    glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);

	glColor3f(0,1,0);

	CImgText::PrintValue(600,10,cHmap.m_ViewPos.xpos);
	CImgText::PrintValue(600,30,cHmap.m_ViewPos.ypos);
	CImgText::PrintValue(600,50,cHmap.m_ViewPos.zpos);
	CImgText::PrintValue(600,70,cHmap.m_ViewRotY);

	CImgText::PrintValue(500,10,cHmap.m_numTriangles);
    if(dist<3000)
	{
		char str[16];
		sprintf(str,"%.1fm",dist/4);
		CImgText::PrintString(400,300,str);
	}
	else 
		CImgText::PrintString(400,300,"3Km+");

	/////////////////////draw cursor
	glBegin(GL_LINES);
	    glVertex3f(0,      12,CImgText::GetTextDist());
        glVertex3f(0,      4,CImgText::GetTextDist());
        glVertex3f(0,      -4,CImgText::GetTextDist());
        glVertex3f(0,      -12,CImgText::GetTextDist());
	    glVertex3f(12,      0,CImgText::GetTextDist());
        glVertex3f(4,      0,CImgText::GetTextDist());
        glVertex3f(-4,     0,CImgText::GetTextDist());
        glVertex3f(-12,      0,CImgText::GetTextDist());
    glEnd();
	//////////////////Draw navigator
	if(CInput::m_keys[CGameSetting::m_iKeyHelp])
	{
		CInput::m_keys[CGameSetting::m_iKeyHelp]=false;
		m_bHelpOpen=!m_bHelpOpen;
	}
	if(m_bHelpOpen)
	{
	    if(CInput::m_keys[VK_ESCAPE])
		{
		    CInput::m_keys[VK_ESCAPE]=false;
		    m_bHelpOpen=false;
		}
	}
	glColor3f(1,1,1);
	glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_COLOR);
    glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D,m_texNavigator);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
		glTexCoord2f(0,0);
	    glVertex3f(-384, -156 ,CImgText::GetTextDist());
		glTexCoord2f(1,0);
	    glVertex3f(-256, -156 ,CImgText::GetTextDist());
		glTexCoord2f(1,1);
	    glVertex3f(-256, -284 ,CImgText::GetTextDist());
		glTexCoord2f(0,1);
	    glVertex3f(-384, -284 ,CImgText::GetTextDist());
	glEnd();
    //////////////////////
    glDisable(GL_BLEND);
	if(m_bHelpOpen)
	{
	    glBindTexture(GL_TEXTURE_2D,m_texHelp);
       	glBegin(GL_QUADS);
		glTexCoord2f(0,0);
	    glVertex3f(-380, 20 ,CImgText::GetTextDist());
		glTexCoord2f(1,0);
	    glVertex3f(-124, 20 ,CImgText::GetTextDist());
		glTexCoord2f(1,1);
	    glVertex3f(-124, 276 ,CImgText::GetTextDist());
		glTexCoord2f(0,1);
	    glVertex3f(-380, 276 ,CImgText::GetTextDist());
    	glEnd();
	}

    glDisable(GL_TEXTURE_2D);

	glPointSize(2);
	float x,y;
	glBegin(GL_POINTS);
		for(int i=0;i<m_cHmap.m_numSoldier;i++)
		{
			GetNavigatorPos(&m_cHmap.m_soldierPos[i],&x,&y);
			if(x !=0)
			{
				if(m_cHmap.m_soldierHealth[i]>0)
			        glColor3f(1,0,0);
				else
					glColor3f(1,1,0);

				glVertex3f(x,y,CImgText::GetTextDist());
			}
		}
	glEnd();
    /////////////////
	glColor3f(1,1,1);
}
void CInfoPanel::DrawMyWeapon()
{
	if(m_cHmap.m_bAttack)
	{
		m_bFire=!m_bFire;
	    m_gunBiasAngleX += 50;
	    if(m_gunBiasAngleX>360)m_gunBiasAngleX-=360;
	}
	else
	{
		m_bFire=false;
	    m_gunBiasAngleY+= 4;
	    if(m_gunBiasAngleY>360)m_gunBiasAngleY-=360;
	}

	m_gunBiasX=sinf(m_gunBiasAngleX*0.0174533f)*0.02f;
	m_gunBiasY=sinf(m_gunBiasAngleY*0.0174533f)*0.03f;
	if(!m_bFire)m_gunBiasZ=0;
	else m_gunBiasZ=0.02f;
	////////////////////////draw gun
/*	glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);
	glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);
    glBindTexture(GL_TEXTURE_2D,m_texMetal);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE);
    glEnable(GL_BLEND);*/


    glPushMatrix();	  
	glTranslatef(m_gunBiasX,m_gunBiasY,m_gunBiasZ);
	m_myWeapon.RenderOneFrame(0);
    glPopMatrix();
 
	/*
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_BLEND);*/

	/////////////////////////draw gun fire
	CHeightmap::m_numTriangles += 698 ;

	if(!m_bFire)return;

    glPushMatrix();	 
	glTranslatef(m_gunMouth.xpos,m_gunMouth.ypos+m_gunBiasY,m_gunMouth.zpos);

    m_cGunFire.DrawGunFire();
	//////////////end draw
    glPopMatrix();
	/////////////// Gun mouth
	CHeightmap::m_numTriangles += 2 ;

}
void  CInfoPanel::GetNavigatorPos(VERTEX *Pos,float *x,float *y)
{
    //////// translation
    VERTEX v0=VERTEX(Pos->xpos - m_cHmap.m_ViewPos.xpos,
	                 Pos->ypos - m_cHmap.m_ViewPos.ypos,
	                 Pos->zpos - m_cHmap.m_ViewPos.zpos);

   	//////// y rotate
    VERTEX v1=VERTEX(v0.xpos*cosf(m_cHmap.m_ViewRotY*0.0174533f)-
                     v0.zpos*sinf(m_cHmap.m_ViewRotY*0.0174533f),
	                 v0.ypos,
                     v0.xpos*sinf(m_cHmap.m_ViewRotY*0.0174533f)+
                     v0.zpos*cosf(m_cHmap.m_ViewRotY*0.0174533f));

    if(v1.xpos>1280 || v1.xpos<-1280 || v1.zpos>1280 || v1.zpos<-1280)
	{
		*x=0;
		return ;
	}
	*x=v1.xpos*0.05f-320;
	*y=-220-v1.zpos*0.05f;
}
