// AudioManager.cpp: implementation of the CAudioManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AudioManager.h"
#include "MediaPlayer.h"
#include "GameSetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAudioManager::CAudioManager()
{
}
CAudioManager::~CAudioManager()
{
}
void CAudioManager::InitCheck()
{
    CGameSetting cGameSetting;
    CAudio       cAudio;
    CMediaPlayer cMusic;

	if(cAudio.IsAudioEnable() && cMusic.IsMediaEnable())
		cGameSetting.m_bAudioEnable=true;
	else 
	{
        MessageBox(NULL, "Audio Invalidate !", "Warning", MB_OK);
		cGameSetting.m_bAudioEnable=false;
		cGameSetting.m_bMusic=false;
		cGameSetting.m_bSound=false;
	}

	if(cGameSetting.m_bMusic)cMusic.SetMediaActive(true);
	else cMusic.SetMediaActive(false);
	if(cGameSetting.m_bSound)cAudio.SetAudioActive(true);
	else cAudio.SetAudioActive(false);

	cMusic.SetVolume(cGameSetting.m_iMusicVolume);
	cAudio.SetVolume(cGameSetting.m_iSoundVolume);
}
bool CAudioManager::CreateMenuResource()
{
    CAudio       cAudio;
    CMediaPlayer cMusic;
    ////////////music
	if(!cMusic.CreateMusic("audio/music/menu.mp3"))
	{
//		MessageBox(0, "Unable to load  audio/menu.mp3", "Error", MB_OK | MB_ICONERROR);
	}
//	cMusic.SetVolume(cGameSetting.m_iMusicVolume);
	//////////// Sound
	cAudio.CreateSound(MENU_SOUND_CLICK,"audio/menu/click.wav",false);
	cAudio.CreateSound(MENU_SOUND_TEST,"audio/ambient/bird0.wav",false);
    ///////////////////////////////
	cMusic.Play();

	return true;
}
void CAudioManager::DeleteMenuResource()
{
    CMediaPlayer cMusic;
	cMusic.Stop();

	CAudio audio;
	audio.StopAll();
	audio.DeleteSound(MENU_SOUND_CLICK);
	audio.DeleteSound(MENU_SOUND_TEST);
}
////////////////////////////////////////////////
bool CAudioManager::CreateMissionResource()
{
    CAudio       cAudio;
	cAudio.CreateSound(SOUND_RUN_0,"audio/soldier/run0.wav",true);
	cAudio.CreateSound(SOUND_RUN_1,"audio/soldier/run1.wav",true);
	cAudio.CreateSound(SOUND_RUN_2,"audio/soldier/run2.wav",true);
	cAudio.CreateSound(SOUND_RUN_3,"audio/soldier/run3.wav",true);

	cAudio.CreateSound(SOUND_AMBIENT,"audio/ambient/ambient.wav",false);
	cAudio.CreateSound(SOUND_BIRD_0, "audio/ambient/bird0.wav",false);
	cAudio.CreateSound(SOUND_BIRD_1, "audio/ambient/bird1.wav",false);
	cAudio.CreateSound(SOUND_BIRD_2, "audio/ambient/bird2.wav",false);
	cAudio.CreateSound(SOUND_BIRD_3, "audio/ambient/bird3.wav",false);
	cAudio.CreateSound(SOUND_BIRD_4, "audio/ambient/bird4.wav",false);
	cAudio.CreateSound(SOUND_BIRD_5, "audio/ambient/bird5.wav",false);
	cAudio.CreateSound(SOUND_BIRD_6, "audio/ambient/bird6.wav",false);
	cAudio.CreateSound(SOUND_BIRD_7, "audio/ambient/bird7.wav",false);

	cAudio.CreateSound(SOUND_GUN_SINGLE, "audio/weapon/singleSound.wav",false);
	cAudio.CreateSound(SOUND_GUN_MULTI,  "audio/weapon/multiSound.wav",false);
	cAudio.CreateSound(SOUND_GUN_RIFLE,  "audio/weapon/gunShot.wav",true);
	cAudio.CreateSound(SOUND_BULLET_WHIZ,  "audio/weapon/whiz.wav",false);

	cAudio.CreateSound(SOUND_PAIN_1,  "audio/soldier/pain1.wav",true);
	cAudio.CreateSound(SOUND_PAIN_2,  "audio/soldier/pain2.wav",true);
	cAudio.CreateSound(SOUND_PAIN_3,  "audio/soldier/pain3.wav",true);

	cAudio.CreateSound(SOUND_DEATH_1,  "audio/soldier/death1.wav",true);
	cAudio.CreateSound(SOUND_DEATH_2,  "audio/soldier/death2.wav",true);
	cAudio.CreateSound(SOUND_DEATH_3,  "audio/soldier/death3.wav",true);

    CMediaPlayer cMusic;
	cMusic.Play();

    return true;
}
void CAudioManager::DeleteMissionResource()
{
    CMediaPlayer cMusic;
	cMusic.Stop();

	CAudio       cAudio;
	cAudio.StopAll();
	cAudio.DeleteSound(SOUND_RUN_0);
	cAudio.DeleteSound(SOUND_RUN_1);
	cAudio.DeleteSound(SOUND_RUN_2);
	cAudio.DeleteSound(SOUND_RUN_3);

	cAudio.DeleteSound(SOUND_AMBIENT);
	cAudio.DeleteSound(SOUND_BIRD_0);
	cAudio.DeleteSound(SOUND_BIRD_1);
	cAudio.DeleteSound(SOUND_BIRD_2);
	cAudio.DeleteSound(SOUND_BIRD_3);
	cAudio.DeleteSound(SOUND_BIRD_4);
	cAudio.DeleteSound(SOUND_BIRD_5);
	cAudio.DeleteSound(SOUND_BIRD_6);
	cAudio.DeleteSound(SOUND_BIRD_7);

	cAudio.DeleteSound(SOUND_GUN_SINGLE);
	cAudio.DeleteSound(SOUND_GUN_MULTI);
	cAudio.DeleteSound(SOUND_GUN_RIFLE);
	cAudio.DeleteSound(SOUND_BULLET_WHIZ);

	cAudio.DeleteSound(SOUND_PAIN_1);
	cAudio.DeleteSound(SOUND_PAIN_2);
	cAudio.DeleteSound(SOUND_PAIN_3);

	cAudio.DeleteSound(SOUND_DEATH_1);
	cAudio.DeleteSound(SOUND_DEATH_2);
	cAudio.DeleteSound(SOUND_DEATH_3);

}