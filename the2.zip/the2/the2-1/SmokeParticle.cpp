// SmokeParticle.cpp: implementation of the CSmokeParticle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SmokeParticle.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSmokeParticle::CSmokeParticle()
{
	m_numParticle=50;
	m_smokeLife=1;
	m_smokeFade=0;
	m_size     =1;
	particle=NULL;
	m_color[0]=0.6f;
	m_color[1]=0.5f;
	m_color[2]=0.1f;
	m_gravity=0;
}
CSmokeParticle::~CSmokeParticle()
{
	if(particle!=NULL)delete [] particle;
}
void CSmokeParticle::InitParticle(unsigned int texid,float fade,int  particleNumber,float size)
{
	m_numParticle = particleNumber;
	m_smokeFade   = fade;
	m_size        = size;
    m_texID       = texid;
    
	if(particle==NULL)
	    particle = new PARTICLE [ m_numParticle ];

    Reset();
}
void CSmokeParticle::SetSmokeSize(float size)
{
	m_size = size;
}
void CSmokeParticle::SetSmokeColor(float red,float green,float blue)
{
	m_color[0]=red;
	m_color[1]=green;
	m_color[2]=blue;
}
void CSmokeParticle::SetGravity(float gravity)
{
    m_gravity=gravity;
}
void CSmokeParticle::Reset()
{
	m_smokeLife=1;
	for(int i=0;i<m_numParticle;i++)
		SetSmokeParticle(i);
}
void CSmokeParticle::DrawParticle()
{
 	glBindTexture(GL_TEXTURE_2D,m_texID);
	glEnable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
//	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
    glEnable(GL_BLEND);

	for(int i=0;i<m_numParticle;i++)
	{
        if (particle[i].life > 0)
        {
            particle[i].pos.xpos += particle[i].normal.nx;
            particle[i].pos.ypos += particle[i].normal.ny;

            particle[i].normal.nx *= 1.02f;
            particle[i].normal.ny -= m_gravity; 
            particle[i].normal.ny *= 0.94f;

            particle[i].size *=1.02f;

            particle[i].life -= particle[i].fade;
    
            glColor4d(m_color[0],m_color[1],m_color[2],particle[i].life);

            glBegin(GL_QUADS);
              glTexCoord2d(1,1); 
			  glVertex3d( particle[i].pos.xpos+particle[i].size,particle[i].pos.ypos+ particle[i].size,particle[i].pos.zpos);
              glTexCoord2d(1,0); 
			  glVertex3d( particle[i].pos.xpos+particle[i].size,particle[i].pos.ypos-particle[i].size,particle[i].pos.zpos);
              glTexCoord2d(0,0); 
			  glVertex3d(particle[i].pos.xpos-particle[i].size,particle[i].pos.ypos-particle[i].size,particle[i].pos.zpos);
              glTexCoord2d(0,1); 
			  glVertex3d(particle[i].pos.xpos-particle[i].size,particle[i].pos.ypos+ particle[i].size,particle[i].pos.zpos);
          glEnd();
		}
		else SetSmokeParticle(i);
	}

    glColor3f(1,1,1); 
 	glDisable(GL_BLEND);

}
void CSmokeParticle::SetSmokeParticle(int num)
{
	if(num>(m_numParticle-1))return;
	m_smokeLife -= m_smokeFade;
	if(m_smokeLife<0)return ;

	particle[num].size =m_size*( (rand()%100)+200 )*0.01f;
	
    particle[num].pos.xpos = 0;//  /75.f;
    particle[num].pos.ypos = 0;
    particle[num].pos.zpos = m_size * (num-m_numParticle/2)*0.1f;

    particle[num].normal.nx = m_size * ((rand()%50)-25)*0.002f;
    particle[num].normal.ny = m_size * ((rand()%50)+8)*0.04f;

	particle[num].fade =float(rand()%100)*0.0001f + 0.015f;

    particle[num].life = 1;

}



