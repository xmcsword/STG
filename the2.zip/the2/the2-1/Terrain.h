// Terrain.h: interface for the CTerrain class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TERRAIN_H__A574B9A8_37A1_4B50_AE15_C397FFC404BB__INCLUDED_)
#define AFX_TERRAIN_H__A574B9A8_37A1_4B50_AE15_C397FFC404BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "heightmap.h"
#include "normal.h"
class CTerrain  
{
public:
	CTerrain();
	bool    InitTerrain();
//	void    UpdateTerrainmap();
    void    RenderTerrain();
	void    RestoreDrawMap();
	virtual ~CTerrain();
	int     GetNumTriangles();

protected:
	
	void    RenderTerrainTile(int x,int z);
    void    DrawLevel_1(int x,int z);
    void    DrawLevel_2(int x,int z);
    void    DrawLevel_3(int x,int z);
    void    DrawLevel_4(int x,int z);
    void    DrawLevel_5(int x,int z);
    void    DrawLevel_6(int x,int z);
    void    DrawLevel_7(int x,int z);

	void    UpdateLODmap();                    //��������Ҫ���ĵ����Ǻ�

	int     GetPos(int x,int z);
	int     GetXpos(int x,int z);
	int     GetZpos(int x,int z);

	void    DrawTerrainStrip(int X,int Z);

    CHeightmap       m_cHmap;

    TERRAIN_SKIN     Skinmap[64][64];
	unsigned short   NormalIndex[256*256];
	unsigned char    LODmap[256][256];
	//��¼��Ϣ�����ļ��ж�ȡLOD�ȼ���0��1��2��3��4��5��6��7

	float biasX;
	float biasZ;

	CNormal          cNormal;
	unsigned int     Blend[4];
	unsigned int     BaseA[3];
	unsigned int     BaseB[3];
	unsigned int     Detail[2];

    int              numTriangles;
};

#endif // !defined(AFX_TERRAIN_H__A574B9A8_37A1_4B50_AE15_C397FFC404BB__INCLUDED_)
