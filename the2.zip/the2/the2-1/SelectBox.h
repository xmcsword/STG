// SelectBox.h: interface for the CSelectBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SELECTBOX_H__887D5121_AC9F_11D6_8156_5254AB37CDC9__INCLUDED_)
#define AFX_SELECTBOX_H__887D5121_AC9F_11D6_8156_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "scrollbar.h"

class CSelectBox  
{
public:
	CSelectBox();
	virtual ~CSelectBox();
	void SetSelectBox(RECT rect,char *titleFile,int curItem=0);
    void SetSelect(int iItem);
	int  GetSelect();
	void RenderSelectBox();
	bool m_bValueChanged;
private:
	void  UpdateSelectBox();
	int    m_iLineHeight; //ÿ�и�
	int    m_numLine;     //������
	int    m_iShowLine;   //������������
	bool   m_bShowScroll;
	RECT   m_rect;
    int    m_iHead;       //��ʾ��һ�еĺ���

	int   m_iMaxItem;
    int   m_iSelect;

	CScrollBar     m_cScrollBar;
	CGraphButton  *m_pButton;
};

#endif // !defined(AFX_SELECTBOX_H__887D5121_AC9F_11D6_8156_5254AB37CDC9__INCLUDED_)
