// CtrlSetBox.h: interface for the CCtrlSetBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLSETBOX_H__E0D3CB81_AAFE_11D6_8154_5254AB37CDC9__INCLUDED_)
#define AFX_CTRLSETBOX_H__E0D3CB81_AAFE_11D6_8154_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "scrollbar.h"
#include "KeyValueEdit.h"

#define  CTRL_ITEM    10

class CCtrlSetBox  
{
public:
	CCtrlSetBox();
	virtual ~CCtrlSetBox();
	void   SetCtrlSetBox(RECT rect);
    void   RenderCtrlSetBox();
	void   LoadSetting();
	void   SaveSetting();
private:
	void   UpdateCtrlSetBox();
    
	RECT            m_rectBox;
	CScrollBar      m_cScrollBar;
    CKeyValueEdit   m_cEdit[CTRL_ITEM];

	int             m_numShow;
	int             m_iHead;
	bool            m_bShowScroll;
    char            m_sTitle[CTRL_ITEM][46];
};

#endif // !defined(AFX_CTRLSETBOX_H__E0D3CB81_AAFE_11D6_8154_5254AB37CDC9__INCLUDED_)
