// Menu.cpp: implementation of the CMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Menu.h"
#include "texmanager.h"
#include "audio.h"
#include "input.h"
#include "gamesetting.h"
#include "AudioManager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMenu::CMenu()
{
    m_cMainMenuSheet=NULL;
	m_cSinglePlayerSheet=NULL;
	m_cOptionsSheet=NULL;
	m_cCreditSheet=NULL;
	m_cNewGameSheet=NULL;

	m_bActive=false;
	m_bResource=false;
}

CMenu::~CMenu()
{
	DeleteMenu();
}
bool  CMenu::LoadMenu()
{
	if(m_bResource)return true;

	//////// Texture
	CTexManager cTexManager;
    //////
	if(!cTexManager.CreateMenuResource())
        MessageBox(0, "Create textures error", "Error", MB_OK | MB_ICONERROR);
    //////////////Cursor and background
	m_texCursor = cTexManager.GetTextureID(TEX_MENU_CURSOR);
	m_texBkg    = cTexManager.GetTextureID(TEX_MENU_BKG);

	///////////////////Sheets
    m_cMainMenuSheet     = new CMainMenuSheet;
	m_cSinglePlayerSheet = new CSinglePlayerSheet;
	m_cOptionsSheet      = new COptionsSheet;
	m_cCreditSheet       = new CCreditSheet;
	m_cNewGameSheet      = new CNewGameSheet;

    m_cMainMenuSheet->InitSheet();
	m_cSinglePlayerSheet->InitSheet();
	m_cOptionsSheet->InitSheet();
	m_cCreditSheet->InitSheet();
	m_cNewGameSheet->InitSheet();

    m_cMainMenuSheet->m_bActive=true;

	///////// sound 
    CAudioManager  cAudioManager;
	cAudioManager.CreateMenuResource();

    ///////////////////////////////
	m_bActive=true;
	m_bResource=true;
	return true;
}
void  CMenu::DeleteMenu()
{
	if(!m_bResource)return;

	//////// Texture
	CTexManager cTexManager;
	cTexManager.DeleteMenuResource();

    ////////// sheets
    if(m_cMainMenuSheet !=NULL)
	{
		delete m_cMainMenuSheet;
		m_cMainMenuSheet=NULL;
	}
	if(m_cSinglePlayerSheet!=NULL)
	{
		delete m_cSinglePlayerSheet;
		m_cSinglePlayerSheet=NULL;
	}
	if(m_cOptionsSheet  !=NULL) 
	{
		delete m_cOptionsSheet;
		m_cOptionsSheet=NULL;
	}
	if(m_cCreditSheet   !=NULL) 
	{
		delete m_cCreditSheet;
		m_cCreditSheet=NULL;
	}
	if(m_cNewGameSheet  !=NULL)  
	{
		delete m_cNewGameSheet;
		m_cNewGameSheet=NULL;
	}
	//////////////// delete audio
    CAudioManager  cAudioManager;
	cAudioManager.DeleteMenuResource();

	/////////////////////////////
	m_bActive=false;
	m_bResource=false;

}
void CMenu::RenderMenu()
{
	if(!m_bActive)return;
 
	UpdateMenu();

	DrawBackGround();
	/////////////////////////////////////

	m_cMainMenuSheet->RenderSheet();
	m_cSinglePlayerSheet->RenderSheet();
	m_cOptionsSheet->RenderSheet();
	m_cCreditSheet->RenderSheet();
	m_cNewGameSheet->RenderSheet();

	//////////////////////////////
	if(CInput::m_bShowMouse)DrawCursor();

}
void CMenu::UpdateMenu()
{
	if(m_cMainMenuSheet->m_bActive)
	{
		if(m_cMainMenuSheet->m_iSelect==0)
		{
            m_cMainMenuSheet->m_iSelect=-1;
			m_cMainMenuSheet->m_bActive=false;
			m_cSinglePlayerSheet->m_bActive=true;
		}	
		if(m_cMainMenuSheet->m_iSelect==2)
		{
            m_cMainMenuSheet->m_iSelect=-1;
			m_cMainMenuSheet->m_bActive=false;
			m_cOptionsSheet->m_bActive=true;
			m_cOptionsSheet->m_iFather=FATHER_MAIN_MENU;
			m_cOptionsSheet->LoadSetting();
		}	
		if(m_cMainMenuSheet->m_iSelect==3)
		{
            m_cMainMenuSheet->m_iSelect=-1;
			m_cMainMenuSheet->m_bActive=false;
			m_cCreditSheet->m_bActive=true;
		}	
		if(m_cMainMenuSheet->m_iSelect==4)
		{
			CGameSetting::m_iGameState=GAME_DEAD;
		}
	}
	if(m_cSinglePlayerSheet->m_bActive)
	{
		if(m_cSinglePlayerSheet->m_iSelect==0)
		{
			m_cSinglePlayerSheet->m_iSelect=-1;
			m_cSinglePlayerSheet->m_bActive=false;
			m_cMainMenuSheet->m_bActive=true;
		}
		if(m_cSinglePlayerSheet->m_iSelect==1)
		{
			m_cSinglePlayerSheet->m_iSelect=-1;
			m_cSinglePlayerSheet->SavePlayerInfo();
		}
		if(m_cSinglePlayerSheet->m_iSelect==2)
		{
			m_cSinglePlayerSheet->m_iSelect=-1;
			m_cSinglePlayerSheet->SavePlayerInfo();
			m_cSinglePlayerSheet->m_bActive=false;
			m_cNewGameSheet->m_bActive=true;
		}
		
	}
	if(m_cOptionsSheet->m_bActive)
	{
		if(m_cOptionsSheet->m_iSelect==0  || m_cOptionsSheet->m_iSelect==2)
		{
			m_cOptionsSheet->m_iSelect=-1;
			m_cOptionsSheet->m_bActive=false;
			if(m_cOptionsSheet->m_iFather==FATHER_MAIN_MENU)
				m_cMainMenuSheet->m_bActive=true;
			if(m_cOptionsSheet->m_iFather==FATHER_NEW_GAME)
				m_cNewGameSheet->m_bActive=true;
		}
	}
	if(m_cCreditSheet->m_bActive)
	{
		if(m_cCreditSheet->m_iSelect==0 )
		{
			m_cCreditSheet->m_iSelect=-1;
			m_cCreditSheet->m_bActive=false;
			m_cMainMenuSheet->m_bActive=true;
		}
	}

	if(m_cNewGameSheet->m_bActive)
	{
		if(m_cNewGameSheet->m_iSelect==0)
		{
			m_cNewGameSheet->m_iSelect=-1;
			m_cNewGameSheet->m_bActive=false;
			m_cSinglePlayerSheet->m_bActive=true;
		}
		if(m_cNewGameSheet->m_iSelect==1)
		{
			m_cNewGameSheet->m_iSelect=-1;
			m_cNewGameSheet->m_bActive=false;
			m_cOptionsSheet->m_bActive=true;
			m_cOptionsSheet->m_iFather=FATHER_NEW_GAME;
			m_cOptionsSheet->LoadSetting();
		}
		if(m_cNewGameSheet->m_iSelect==2)
		{
			m_cNewGameSheet->m_iSelect=-1;
//			m_cNewGameSheet->m_bActive=false;
			CGameSetting::m_iMissionSelect=m_cNewGameSheet->GetMissionSelect();
			CGameSetting::m_iGameState=GAME_MISSION;
		}
	}
}
void  CMenu::DrawBackGround()
{
 	    glBindTexture(GL_TEXTURE_2D, m_texBkg);
	    glEnable(GL_TEXTURE_2D);	
		glColor3f(1,1,1);
 	    glBegin(GL_QUADS);
     	    glTexCoord2f(0,1);    
	        glVertex3i(-400 , 300 , -520);
	        glTexCoord2f(1+0,1);   
	        glVertex3i(400 , 300 , -520);
		    glTexCoord2f(1+0,0);   
	        glVertex3i(400 , -300 , -520);
		    glTexCoord2f(0,0);    
	        glVertex3i(-400 , -300 , -520);
	    glEnd();
	    glDisable(GL_TEXTURE_2D);
}
void  CMenu::DrawCursor()
{
    	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	    glEnable(GL_BLEND);
 	    glBindTexture(GL_TEXTURE_2D, m_texCursor);
	    glEnable(GL_TEXTURE_2D);	
		glColor3f(1,1,1);
 	    glBegin(GL_QUADS);
     	    glTexCoord2f(0,1);    
	        glVertex3i(m_cInput.m_mousePosX-400 , 300-m_cInput.m_mousePosY , -520);
	        glTexCoord2f(1,1);   
	        glVertex3i(m_cInput.m_mousePosX+16-400 , 300-m_cInput.m_mousePosY , -520);
		    glTexCoord2f(1,0);   
	        glVertex3i(m_cInput.m_mousePosX+16-400 , 300-m_cInput.m_mousePosY-16 , -520);
		    glTexCoord2f(0,0);    
	        glVertex3i(m_cInput.m_mousePosX-400 , 300-m_cInput.m_mousePosY-16 , -520);
	    glEnd();
	    glDisable(GL_TEXTURE_2D);
	    glDisable(GL_BLEND);
}