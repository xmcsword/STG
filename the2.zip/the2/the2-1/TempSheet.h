// TempSheet.h: interface for the CTempSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEMPSHEET_H__5BE0DB81_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
#define AFX_TEMPSHEET_H__5BE0DB81_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphButton.h"

class CTempSheet  
{
public:
	CTempSheet();
	virtual ~CTempSheet();

	bool InitSheet();
	int  RenderSheet();

	int    m_iSelect;
	bool   m_bActive;
private:
	CGraphButton  m_cButton[5];
};

#endif // !defined(AFX_TEMPSHEET_H__5BE0DB81_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
