// Sprite.h: interface for the CSprite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPRITE_H__ABCAFE21_3E63_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_SPRITE_H__ABCAFE21_3E63_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "camera.h"
#include "heightmap.h"
#include "cmath.h"
#include "smfloader.h"
#include "gunfire.h"
/////////sprite type
#define SENTINEL    0
#define PATROL      1

class CSprite  
{
public:
	CSprite();
	virtual ~CSprite();
	bool InitSprite(int id,VERTEX startPos,float roty,CSMFLoader *pSoldier,CSMFLoader *pWeapon);
    void RenderSprite(bool noHarm);
	void UpdateSprite(bool freeze,bool noVisible);
	bool IsInSpriteBoundary(VERTEX pos);
	void Injure();
    void ResetSpriteState();
	//////////////////////////////
	VERTEX       m_orgPos;
    CCamera      m_Camera;
	float        m_Health;
protected:
	void UpdateSpriteState();
	void UpdateSpriteAction();
	void Scan();

	void SetSpriteAction(int iAction);

	void DrawGunFire(bool noHarm);
    void DrawSMFBoundary();

	CSMFLoader  *m_pSoldier;
	CSMFLoader  *m_pWeapon;
	CGunFire     m_cGunFire;

    int          m_nID;

    BOUNDARY_3D  m_boundary;

	CHeightmap   m_cHmap;
	CMath        m_cMath;

	float        m_RunSpeed;
	///////////// Sprite state
	int          m_spriteType;
	VERTEX       m_destPos;

    bool         m_bHearShot;
    bool         m_bFindEnemy;
	bool         m_bDangerous;
	bool         m_bWounded;

	bool         m_bFire;
    int          m_iAlarm;
	float        m_distFromViewer;

	/////////////model control
	int              startFrame;
	int              endFrame;
	int              curFrame;
	int              nextFrame;
    float            percent;
    float            interpolation;
	int              curAction;
	bool             bActionFinish;
	bool             bDrawWeapon;

	///////develop mode
};
#endif // !defined(AFX_SPRITE_H__ABCAFE21_3E63_11D6_812C_5254AB37CDC9__INCLUDED_)
