// Grass.h: interface for the CGrass class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRASS_H__93B5B761_9DA6_11D6_813E_5254AB37CDC9__INCLUDED_)
#define AFX_GRASS_H__93B5B761_9DA6_11D6_813E_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "structdef.h"

class CGrass  
{
public:
	CGrass();
	virtual ~CGrass();
    bool InitGrass(int type);
	void RenderGrass(VERTEX position);

protected:
    void DrawGrassStrip();
    void DrawGrassStar();

	void DrawCross(int angle);
 
	float m_size;
	float m_height;

	int   m_type;

    unsigned int texGrass;
};

#endif // !defined(AFX_GRASS_H__93B5B761_9DA6_11D6_813E_5254AB37CDC9__INCLUDED_)
