// Sprite.cpp: implementation of the CSprite class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Sprite.h"
#include "input.h"
#include "audio.h"
#include "scrmasker.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSprite::CSprite()
{
	m_pSoldier=NULL;
	m_pWeapon=NULL;

	m_Health=1;

    m_bFindEnemy=false;
	m_bDangerous=false;
	m_bWounded=false;
	m_bHearShot=false;
	m_bFire=false;
	m_iAlarm=0;
	/////////////model control
	startFrame=0;
	endFrame=39;
	curFrame=0;
	nextFrame=1;
    percent=0;
    interpolation=0.25f;
	bActionFinish=false;
	bDrawWeapon=true;
	curAction=SMF_STAND;
	m_bFire=false;

}
CSprite::~CSprite()
{
}
bool CSprite::InitSprite(int id,VERTEX startPos,float rotY,CSMFLoader *pSoldier,CSMFLoader *pWeapon)
{
	m_nID=id;
	m_pSoldier=pSoldier;
	m_pWeapon=pWeapon;
    
    startPos.ypos=m_cHmap.GetHeight(startPos.xpos,startPos.zpos);

	startPos.ypos+=(m_pSoldier->m_boundary.maxy-m_pSoldier->m_boundary.miny)/2;


	m_Camera.SetCamera(startPos,rotY);

	m_boundary.minx = m_pSoldier->m_boundary.minx + startPos.xpos;
	m_boundary.maxx = m_pSoldier->m_boundary.maxx + startPos.xpos;
	m_boundary.miny = m_pSoldier->m_boundary.miny + startPos.ypos;
	m_boundary.maxy = m_pSoldier->m_boundary.maxy + startPos.ypos;
	m_boundary.minz = m_pSoldier->m_boundary.minz + startPos.zpos;
	m_boundary.maxz = m_pSoldier->m_boundary.maxz + startPos.zpos;

	m_orgPos=startPos;

	SetSpriteAction(SMF_STAND);

	m_cGunFire.InitGunFire(3.5f,4.0f);
	return true;
}
void CSprite::RenderSprite(bool noHarm)
{
	if(!m_cHmap.IsInFrustum(&m_orgPos))return;
//	if(curAction>=SMF_DEATH1 && bActionFinish)return;

    glPushMatrix();	
    glTranslatef(m_orgPos.xpos,m_orgPos.ypos,m_orgPos.zpos);
    glRotatef(m_Camera.m_CamRotY,  0.0f,1.0f,0.0f);
	m_pSoldier->Animate(curFrame,nextFrame,percent);
	if(bDrawWeapon)m_pWeapon->Animate(curFrame,nextFrame,percent);

    glPopMatrix();

	DrawGunFire(noHarm);

	CHeightmap::m_numTriangles += 990 ;
	
	/*
	glColor3f(1,1,1);
	glBegin(GL_LINES);
	    glVertex3f(m_Camera.m_CamPos.xpos,m_Camera.m_CamPos.ypos,m_Camera.m_CamPos.zpos);
		glVertex3f(m_cHmap.m_ViewPos.xpos,m_cHmap.m_ViewPos.ypos-8,m_cHmap.m_ViewPos.zpos);
    glEnd();
*/
 //   DrawSMFBoundary();
}
void CSprite::UpdateSprite(bool freeze,bool noVisible)
{
	if(curAction>=SMF_DEATH1 && bActionFinish)return;
	if(m_cHmap.m_myHealth<=0)return;

    if(!noVisible)UpdateSpriteState();
	else
	{
		if(curAction!=SMF_STAND)SetSpriteAction(SMF_STAND);
		else
		{
	     	if(bActionFinish)
                SetSpriteAction(SMF_STAND);
		}
	}

	if(!freeze)UpdateSpriteAction();
}
void CSprite::ResetSpriteState()
{
	m_Health=1;
	bDrawWeapon=true;
    m_bFindEnemy=false;
	m_bDangerous=false;
	m_bWounded=false;
	m_bHearShot=false;
	m_bFire=false;
	m_iAlarm=0;
	m_Camera.SetCameraRotate(float(rand()%360));
	SetSpriteAction(SMF_STAND);
}
void CSprite::Injure()
{
	float harm=0.2f;
	float bias=float(m_cHmap.m_focusPosY)-m_Camera.m_CamPos.ypos;
	if(bias<0)bias=-bias;
	if(bias<2)harm=(2-bias);

	if(harm<0.2f)harm=0.2f;

    if(m_cHmap.m_focusPosY>m_orgPos.ypos)harm=1;

    m_Health-=harm;
	m_bWounded=true;  
}
void CSprite::Scan()
{
    VERTEX pos=m_pSoldier->GetPos(SMF_EYE_POS,percent);
	m_Camera.m_CamPos.xpos =m_orgPos.xpos + pos.xpos;
	m_Camera.m_CamPos.ypos =m_orgPos.ypos + pos.ypos;
    m_Camera.m_CamPos.zpos =m_orgPos.zpos + pos.zpos;

	if(m_cHmap.m_bAttack)
	{
		m_bHearShot=true;
        m_iAlarm=1;
		if(m_Camera.GetDistance(VERTEX(float(m_cHmap.m_focusPosX),
			                    float(m_cHmap.m_focusPosY),
								float(m_cHmap.m_focusPosZ))) < 30 )
			m_bDangerous=true;
		else 
			m_bDangerous=false;
	}
	else
	{
    	m_bDangerous=false;
		m_bHearShot=false;
	}

	m_distFromViewer=m_cMath.GetDistance(m_Camera.m_CamPos,m_cHmap.m_ViewPos);
	if(m_distFromViewer<25)
	{
		m_bFindEnemy=true;
		m_iAlarm=1;
		return;
	}
	if(m_Camera.IsEnemyInFrustum(m_cHmap.m_ViewPos))
	{
        if(!m_cHmap.CollideCheck(m_Camera.m_CamPos,m_cHmap.m_ViewPos,2))
		{
            if(m_iAlarm>0)
	            m_bFindEnemy=true;
			else
			{
             	int find=rand()%600;
				int findout;
                if(m_distFromViewer>800)findout=1;
            	else if(m_distFromViewer>600)findout=2;
             	else if(m_distFromViewer>400)findout=3;
				else if(m_distFromViewer>200)findout=50;
            	else findout=600;
				if(find<findout)m_bFindEnemy=true;
				else m_bFindEnemy=false;
			}
		}
		else 
			m_bFindEnemy=false;
	}

	if(m_bFindEnemy)m_iAlarm=1;
}
void CSprite::UpdateSpriteState()
{
	if(m_Health<=0)
	{
		if(curAction<SMF_DEATH1)
		{
			SetSpriteAction(SMF_DEATH1+rand()%2);
			int sound=SOUND_DEATH_1+rand()%3;
			CAudio::SetSoundPos(sound,&m_orgPos);
			CAudio::Play(sound,1,false,false);
		}
		m_bFire=false;
		m_Health--;
 		return;
	}
	/////////////////////////
	
    if(m_bWounded)
	{
		m_bWounded=false;
        if(curAction!=SMF_PAIN  && curAction!=SMF_CRPAIN)
		{
			int sound=SOUND_PAIN_1+rand()%3;
			CAudio::SetSoundPos(sound,&m_orgPos);
			CAudio::Play(sound,1,false,false);
		}
        if(curAction<SMF_CRSTAND)SetSpriteAction(SMF_PAIN);
		else SetSpriteAction(SMF_CRPAIN);
		return;
	}
	if(curAction==SMF_PAIN ||curAction==SMF_CRPAIN)
	{
		if(bActionFinish)
		{
			m_Camera.SetCamera(m_cHmap.m_ViewPos);
		    SetSpriteAction(SMF_CRSTAND);
		}
		return;
	}
	////////////////
	Scan();
	////////////////////////

	if(curAction==SMF_ATTACK )
	{
		if(m_bDangerous)
		{
			m_Camera.SetCamera(m_cHmap.m_ViewPos);
            SetSpriteAction(SMF_CRATTACK);
			return;
		}
        if(bActionFinish)
		{ 
			if(m_bFindEnemy)
			{
		    	m_Camera.SetCamera(m_cHmap.m_ViewPos);
                SetSpriteAction(SMF_ATTACK);
				return;
			}
			else
			{	
                SetSpriteAction(SMF_STAND);
				return;
			}
		}
		else 
			return;
	
	}

	if(curAction==SMF_CRATTACK )
	{
        if(bActionFinish)
		{ 
			if(m_bFindEnemy)
			{
		    	m_Camera.SetCamera(m_cHmap.m_ViewPos);
                SetSpriteAction(SMF_CRATTACK);
				return;
			}
			else
			{
                SetSpriteAction(SMF_STAND);
				return;
			}
		}
		else 
			return;
	
	}
	if(curAction==SMF_CRSTAND)
	{
		if(m_bFindEnemy)
		{
		    m_Camera.SetCamera(m_cHmap.m_ViewPos);
            SetSpriteAction(SMF_CRATTACK);
			return;
		}    
		if(m_bHearShot)
		{
		    m_Camera.SetCamera(m_cHmap.m_ViewPos);
		}	
		if(bActionFinish)
		{ 
            SetSpriteAction(SMF_STAND);
			return;
		}
		return;
	}
	if(curAction==SMF_STAND)
	{
		if(m_bDangerous)
		{
			m_Camera.SetCamera(m_cHmap.m_ViewPos);
            SetSpriteAction(SMF_CRSTAND);
			return;
		}
		if(m_bFindEnemy)
		{
		    m_Camera.SetCamera(m_cHmap.m_ViewPos);
            SetSpriteAction(SMF_ATTACK);
			return;
		}      
		if(m_bHearShot)
		{
		    m_Camera.SetCamera(m_cHmap.m_ViewPos);
		}
		if(bActionFinish)
		{ 
		    if(m_iAlarm>0)m_iAlarm--;
			else
			{
		        float angle=float(rand()%200-80);
		        m_Camera.SetCameraRotate(angle);
			}
            SetSpriteAction(SMF_STAND);
			return;
		}
	}
}
void CSprite::UpdateSpriteAction()
{
	/////////////////////////////update action
	percent+=interpolation;
	if(percent>1)
	{
		percent-=1;
        curFrame++;
        nextFrame++;
		if(nextFrame>endFrame)
		{
			nextFrame=endFrame;
			curFrame =endFrame;
		    bActionFinish=true;
		}
	}
	///////////////////////
}
/////////////////////////////////////////
void CSprite::SetSpriteAction(int iAction)
{
	////// check
	if(iAction>(m_pSoldier->numAction-1) || iAction<0)iAction=0;
	if(iAction>(m_pWeapon->numAction-1))bDrawWeapon=false;
	else bDrawWeapon=true;
	curAction=iAction;
	////////////
	startFrame=m_pSoldier->pAction[iAction].startFrame;
	endFrame  =m_pSoldier->pAction[iAction].endFrame;
    
	bActionFinish=false;
    curFrame=startFrame;
	nextFrame=curFrame+1;
	percent=0;

	if(curAction==SMF_ATTACK || curAction==SMF_CRATTACK )m_bFire=true;
	else m_bFire=false;
}
bool CSprite::IsInSpriteBoundary(VERTEX pos)
{
	if(pos.xpos>m_boundary.maxx || pos.xpos<m_boundary.minx)return false; 
	if(pos.ypos>m_boundary.maxy || pos.ypos<m_boundary.miny)return false; 
	if(pos.zpos>m_boundary.maxz || pos.zpos<m_boundary.minz)return false; 

    return true;
}
void CSprite::DrawGunFire(bool noHarm)
{
    if(!m_bFire)return;
	m_bFire=false;

	CAudio::SetSoundPos(SOUND_GUN_RIFLE,&m_orgPos);
	CAudio::Play(SOUND_GUN_RIFLE,1,false,false);

	VERTEX pos=m_pWeapon->GetPos(SMF_GUN_MOUTH,percent);
	float rotate=m_Camera.m_CamRotY*0.0174533f;
    float xpos= pos.xpos*cosf(rotate)+pos.zpos*sinf(rotate);
	float zpos=-pos.xpos*sinf(rotate)+pos.zpos*cosf(rotate);

    glPushMatrix();	  
    glTranslatef(m_orgPos.xpos + xpos,
		         m_orgPos.ypos + pos.ypos,
				 m_orgPos.zpos + zpos);

    glRotatef(m_cHmap.m_ViewRotY,  0.0f,1.0f,0.0f);
    glRotatef(-m_cHmap.m_ViewRotX,  1.0f,0.0f,0.0f);

 	///////////////////////////////////////////////////////
    m_cGunFire.DrawGunFire();
	//////////////end draw
	///////////////////////////////////////////////////////
    glPopMatrix();

	int hit=rand()%14;
	float dist=m_cMath.GetDistance(m_Camera.m_CamPos,m_cHmap.m_ViewPos);
    int hitDist;
    if(dist>600)hitDist=3;
	else if(dist>300)hitDist=4;
	else if(dist>100)hitDist=6;
	else if(dist>50)hitDist=8;
	else hitDist=10;
	if(hit<hitDist)
	{
		if(noHarm)return;
		int sound=SOUND_PAIN_1+rand()%3;
    	CAudio::SetSoundPos(sound,&m_cHmap.m_ViewPos);
    	CAudio::Play(sound,1,false,false);
		CScrMasker::SprayBlood();
		m_cHmap.m_myHealth-=0.15f+float(rand()%10)*0.01f;
	}
	else
	{
		if(hit>8)
    	    CAudio::Play(SOUND_BULLET_WHIZ,1,false,false);
	}
}
void CSprite::DrawSMFBoundary()
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(1,1,1);
	glBegin(GL_LINE_STRIP);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.minz);

	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.minz);
	glEnd();
	glBegin(GL_LINES);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.minz);

	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.maxz);

	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.maxz);
	glEnd();
	glColor3f(1,1,1);

}


