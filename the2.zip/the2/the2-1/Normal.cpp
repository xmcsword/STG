// Normal.cpp: implementation of the CNormal class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Normal.h"
#include <math.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNormal::CNormal()
{
	///////////////////////////////////////////////////////
	///////////////// 3dExplorer Normal
    ///////////////////////////////////////////////////////
	for(int xrot=0;xrot<10;xrot++)
	    for(int yrot=0;yrot<36;yrot++)
		{
			//////Y axis   angle=xrot*10*0.017453292f
			m_3dENormal[xrot*36+yrot][1]=sinf(xrot*0.17453292f);
            float xz;
			if(xrot==9)xz=0;
			else
			    xz=cosf(xrot*0.17453292f);
            //////X
			if(yrot==18)m_3dENormal[xrot*36+yrot][0]=0;
			else
			    m_3dENormal[xrot*36+yrot][0]=-xz*sinf(yrot*0.17453292f);
			//////Z
			if(yrot==9 || yrot==27)m_3dENormal[xrot*36+yrot][2]=0;
			else
    			m_3dENormal[xrot*36+yrot][2]=-xz*cosf(yrot*0.17453292f);

		}
}

CNormal::~CNormal()
{

}
