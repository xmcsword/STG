// PlantManager.cpp: implementation of the CPlantManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PlantManager.h"
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlantManager::CPlantManager()
{
}

CPlantManager::~CPlantManager()
{
}
bool CPlantManager::InitPlantManager()
{
	if(!m_cTree1.Init3DTree(1,1.2f))
	{
		MessageBox(0, "Init house failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cTree2.Init3DTree(2,1.0f))
	{
		MessageBox(0, "Init house failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cBush1.InitBush(1))
	{
		MessageBox(0, "Init house failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cPine.InitPine(1,2.0f))
	{
		MessageBox(0, "Init house failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}

	return true;
}
void CPlantManager::RenderPlant()
{
	int tx,tz; // in terrain map
	int cx,cz; // in cover map
	int type;
	VERTEX pos;

	for(int x=108;x<148; x++)
	{
	    for(int z= 108;z<148; z++)
		{
			if(m_cHmap.m_cFrustumCull.IsInFrustum(x,z))
			{
			    tx=m_cHmap.m_pMovemap[z*256+x].xpos;
			    tz=m_cHmap.m_pMovemap[z*256+x].zpos;
				pos=m_cHmap.ConvertToWorld(x,z);

				cx=tx/4;
				cz=tz/4;

				type=m_cHmap.m_pCovermap[cz*64+cx];
				if(type!=0)
				{
			    	pos.xpos+=m_cHmap.m_pCoverBias[cz*64+cx].xbias;
		    		pos.zpos+=m_cHmap.m_pCoverBias[cz*64+cx].zbias;
					if(type>130)
				        pos.ypos=m_cHmap.GetHeight(pos.xpos,pos.zpos)-2;
					else
				        pos.ypos=m_cHmap.GetHeight(pos.xpos,pos.zpos)-1;
					if(type==64)
			       	    m_cBush1.RenderBush(pos);
					if(type==128)
			       	    m_cPine.RenderPine(pos);
					if(type==192)
			       	    m_cTree1.Render3DTree(pos);
					if(type==255)
			       	    m_cTree2.Render3DTree(pos);
					
				}
			}
		}
	}

}

