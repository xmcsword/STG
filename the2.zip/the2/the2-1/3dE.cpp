// 3dE.cpp: implementation of the C3dE class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "3dE.h"
#include "heightmap.h"
#include "math.h"
#include "audio.h"
#include "imgtext.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
C3dE::C3dE()
{
	m_bAttacked=false;
    m_bAttacking=false;

	m_Height=8;
	m_baseHeight=255;
    m_eyePos=VERTEX(0,0,0);

	m_RotX=0;
	m_RotY=180;
	m_RotZ=0;

	m_RunVector=NORMAL(0,0,0);
	m_JumpSpeed=0.4f;
	m_Acceleration=0.8f;
	m_MaxRunSpeed=1.5f;
    m_Decrease=0.8f;
    m_AirDecrease=0.0001f;
	m_Gravity=0.02f;
	m_bFlying=false;
	m_maxDifferent=2;

    m_YBiasAngle=0;
	m_YBias=0;
    m_ZBiasAngle=0;
	m_bBiasLeft=true;

	m_gunYBias=0;
	m_gunZBias=0;
	m_gunState=0;

	m_maxFOVAngle=60;
	m_minFOVAngle=15;
	m_curFOVAngle=60;
	m_orgFOVAngle=60;
	m_bZoomed=false;
	m_bZoomOut=false;
	m_iZoomAngle=1;

	m_mouseSpeed=0.1f;
}

C3dE::~C3dE()
{

}
bool C3dE::Init3dExplorer()
{
    Reset3dExplorerPos();
	return true;
}
void C3dE::Reset3dExplorerPos()
{
    m_eyePos.xpos=m_cGS.m_fViewerPosX;
    m_eyePos.zpos=m_cGS.m_fViewerPosZ;
    m_eyePos.ypos=m_cHmap.GetHeight(m_eyePos.xpos,m_eyePos.zpos)+m_Height;

	m_baseHeight=m_eyePos.ypos-m_Height;
    m_RotY=m_cGS.m_fViewerRotY;
	m_RotX=0;
	m_cHmap.m_myHealth=1;
	m_bAttacking=false;

	m_curFOVAngle=60;
	m_orgFOVAngle=60;
	m_bZoomed=false;
	m_bZoomOut=false;
	m_iZoomAngle=10;

    ChangeFOVAngle();
    UpdateHeightmap();
}
void C3dE::ProcessInput()
{
	if(m_cHmap.m_myHealth<=0)
	{
		m_RotX=0;
		m_RotY+=0.2f;
    	UpdateHeightmap();

        if(m_cHmap.m_myHealth!=-10)
		{
            m_cHmap.m_myHealth=-10;
			m_iZoomAngle=60;
			ChangeFOVAngle();
			m_bAttacking=false;
	    	int sound=SOUND_DEATH_1+rand()%3;
			CAudio::SetSoundPos(sound,&m_eyePos);
			CAudio::Play(sound,1,false,false);
		}
        return;
	}
    //////////////////////////////////////////////////////////
	/////////////// mouse rotate /////////////////////////////
    m_RotY+=(400-m_cInput.m_mousePosX)*m_mouseSpeed;// /mouse Speed
    m_RotX-=(300-m_cInput.m_mousePosY)*m_mouseSpeed;
	// Center mouse
	SetCursorPos(400,300);
	///////////////////////////////////////////////////////////
	///////////////  Run //////////////////////////////////////
	// Keyboard input
	if (m_cInput.m_keys[m_cGS.m_iKeyForward] && (!m_bFlying))
	{
        m_RunVector.nz-=m_Acceleration;
		if(m_RunVector.nz<-m_MaxRunSpeed)m_RunVector.nz=-m_MaxRunSpeed;
		////////////////Y bias
    	if (m_YBiasAngle >= 359)		
	    	m_YBiasAngle = 0;		
    	else						
	    	 m_YBiasAngle+= 8;
		m_YBias=sinf(m_YBiasAngle*0.0174533f )/4.0f;
	}
	else
	{
		if(! m_cInput.m_keys[m_cGS.m_iKeyBackward] && m_RunVector.nz<0 )
		{
			if(m_bFlying) m_RunVector.nz+=m_AirDecrease;
			else  m_RunVector.nz+=m_Decrease;
		    if(m_RunVector.nz>0)m_RunVector.nz=0;
    
		}
	}

	if (m_cInput.m_keys[m_cGS.m_iKeyBackward] && (!m_bFlying))
	{
        m_RunVector.nz+=m_Acceleration;
		if(m_RunVector.nz>m_MaxRunSpeed)m_RunVector.nz=m_MaxRunSpeed;
	}
	else
	{
	    if (! m_cInput.m_keys[m_cGS.m_iKeyForward] && m_RunVector.nz>0)
		{
			if(m_bFlying) m_RunVector.nz-=m_AirDecrease;
			else  m_RunVector.nz-=m_Decrease;
		    if(m_RunVector.nz<0)m_RunVector.nz=0;
		}
	}

	if (m_cInput.m_keys[m_cGS.m_iKeyLeft]&& (!m_bFlying))
	{

        m_RunVector.nx-=m_Acceleration;
		if(m_RunVector.nx<-m_MaxRunSpeed)m_RunVector.nx=-m_MaxRunSpeed;
	}
	else
	{
    	if (!m_cInput.m_keys[m_cGS.m_iKeyRight] && m_RunVector.nx<0)
		{
            m_RunVector.nx+=m_Decrease;
	    	if(m_RunVector.nx>0)m_RunVector.nx=0;
		}
	}
	if (m_cInput.m_keys[m_cGS.m_iKeyRight]&& (!m_bFlying) )
	{

        m_RunVector.nx+=m_Acceleration;
		if(m_RunVector.nx>m_MaxRunSpeed)m_RunVector.nx=m_MaxRunSpeed;
	}
	else
	{
	    if (! m_cInput.m_keys[m_cGS.m_iKeyLeft] && m_RunVector.nx>0)
		{
            m_RunVector.nx-=m_Decrease;
	    	if(m_RunVector.nx<0)m_RunVector.nx=0;
		}
	}
    /////////////////////////////////////////////////////////////////
	//////////////////// Jump  //////////////////////////////////////
	if (m_cInput.m_keys[m_cGS.m_iKeyJump] && (!m_bFlying))
	{
        m_RunVector.ny=m_JumpSpeed;
        m_bFlying=true;
	}
	/////////////////////////////////////////////////////////////////
	//////////////////// Fire ///////////////////////////////////////
	static int  mouseStick=0;
	static bool bContinue=false;
    if(m_cInput.m_keys[m_cGS.m_iKeyFire] )
	{
		m_bAttacking=true;
		m_gunState=1;
        m_gunZBias+=60;

        mouseStick++;
	}
	else 
	{
		m_bAttacking=false;
		m_gunYBias+=4;
		if(mouseStick>0 && mouseStick<5)
		{
			CAudio::Play(SOUND_GUN_SINGLE,1,false);
		}
		mouseStick=0;
		bContinue=false;
	}
	if(mouseStick>=5)
		bContinue=true;

    if(bContinue)
	    CAudio::Play(SOUND_GUN_MULTI,1,false);
	/////////////////////////////////////////////////////////////////
	///////////////////// Zoom //////////////////////////////////////
	if(m_cInput.m_keys[m_cGS.m_iKeyZoom])
	{
		m_cInput.m_keys[m_cGS.m_iKeyZoom]=false;
        if(m_curFOVAngle==m_minFOVAngle)
		{
			m_iZoomAngle=10;
			m_orgFOVAngle=m_maxFOVAngle;
		}
        if(m_curFOVAngle==m_maxFOVAngle)
		{
			m_iZoomAngle=-15;
			m_orgFOVAngle=m_minFOVAngle;
		}
	}
	/////////////////////////////////////////////////////////////////
	////////////////////
	if (m_cInput.m_keys[VK_NEXT])
	{
		m_Height+=1;
	}

	if (m_cInput.m_keys[VK_PRIOR])
	{
		m_Height-=1;
	}

    //////////// backup my position
	VERTEX oldPos=m_eyePos;
	///////////////////////////////////////////
	/////// Now , Update eyePos
	///////////////////////////////////////////
    m_eyePos.xpos +=m_RunVector.nz*sinf(m_RotY*0.0174533f)+m_RunVector.nx*cosf(m_RotY*0.0174533f);
	m_eyePos.ypos +=m_RunVector.ny + m_YBias;
	m_eyePos.zpos +=m_RunVector.nz*cosf(m_RotY*0.0174533f)-m_RunVector.nx*sinf(m_RotY*0.0174533f);
    //////// check new position

	m_baseHeight=m_eyePos.ypos-m_Height;

    float  newHeight=m_cHmap.GetHeight(&m_eyePos);

	if(m_bFlying)
	{
        m_RunVector.ny-=m_Gravity;
		if(m_baseHeight<newHeight)
		{
            m_baseHeight=newHeight;
			m_eyePos.ypos=newHeight+m_Height;	
			m_RunVector.ny=0;
            m_bFlying=false;
		}
		return;
	}
	m_baseHeight=newHeight;
    m_eyePos.ypos=m_baseHeight+m_Height;


	///////////////////////////
	static int index=0;
	static int step=0;
    
	if(! m_cHmap.CollideBuilding(&oldPos,&m_eyePos))
	    m_cHmap.CollideTreeBody(&m_eyePos) ;

	if(m_eyePos.xpos !=oldPos.xpos  || m_eyePos.zpos !=oldPos.zpos) 
	{
		if(index==0)CAudio::Play(SOUND_RUN_0+step,1,true);
		if(m_bZoomed )m_iZoomAngle=15;	
	}
	else
	{
//		if(m_orgFOVAngle==m_minFOVAngle && !m_bZoomed)m_iZoomAngle=-10;	//need ?//????????????
	}

	index++;
	if(index>20)
	{
		index=0; 
		step++;
		if(step==4)step=0;
	}


    //////////////////////////////
	CAudio::SetListenerPos(&m_eyePos,m_RotY);
	ChangeFOVAngle();
	UpdateHeightmap();

}
void C3dE::TransformWorld(int step)
{
	//////////////////////////////////////////
	if(step==0)
	{
		glRotatef(float(m_RotX), 1.0f, 0.0f, 0.0f);	 
   	    glRotatef(float(m_ZBiasAngle), 0.0f, 0.0f, 1.0f);	
        glRotatef(360.0f - m_RotY, 0.0f, 1.0f, 0.0f);
		glTranslated(0,  0, 0);
	}
	else
	{
     		glTranslated(-m_eyePos.xpos, -m_eyePos.ypos, -m_eyePos.zpos);
	}

}
void C3dE::UpdateHeightmap()
{
	m_cHmap.m_ViewPos.xpos=m_eyePos.xpos;
	m_cHmap.m_ViewPos.ypos=m_eyePos.ypos;
	m_cHmap.m_ViewPos.zpos=m_eyePos.zpos;
	if(m_RotX>=360)m_RotX-=360;
	if(m_RotY>=360)m_RotY-=360;
	if(m_RotX<0)m_RotX+=360;
	if(m_RotY<0)m_RotY+=360;
	m_cHmap.m_ViewRotX    =m_RotX;
	m_cHmap.m_ViewRotY    =m_RotY;

	m_cHmap.m_bAttack=m_bAttacking;

    m_cHmap.UpdateHeightmap();
}
void C3dE::ChangeFOVAngle()
{
	if(m_iZoomAngle==0)return;
    m_curFOVAngle+=m_iZoomAngle;

	if(m_curFOVAngle>m_maxFOVAngle)
	{
		m_curFOVAngle=m_maxFOVAngle;
		m_iZoomAngle=0;
		m_mouseSpeed=0.1f;
		m_bZoomed=false;
	}
	if(m_curFOVAngle<m_minFOVAngle)
	{
		m_curFOVAngle=m_minFOVAngle;
		m_iZoomAngle=0;
		m_mouseSpeed=0.02f;
		m_bZoomed=true;
	}

	glViewport(0, 0, CGameSetting::m_iScrWidth, CGameSetting::m_iScrHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(m_curFOVAngle,float(CGameSetting::m_iScrWidth)/CGameSetting::m_iScrHeight, 0.5f, 100000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	CImgText::SetViewFOVAngle(m_curFOVAngle/2);
}