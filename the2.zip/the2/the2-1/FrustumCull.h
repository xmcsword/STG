// FrustumCull.h: interface for the CFrustumCull class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRUSTUMCULL_H__FBDF93B4_E439_11D5_812C_5254AB37CDC9__INCLUDED_)
#define AFX_FRUSTUMCULL_H__FBDF93B4_E439_11D5_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFrustumCull  
{
public:
	CFrustumCull();
	virtual ~CFrustumCull();

	void   InitFrustumCull(int halfFOV,int distance);
	void   UpdateFrustumCull();
	///////
	bool   IsInFrustum(int X,int Z);

    int             m_upPos,m_downPos;
  	unsigned char   m_LeftArray[256];  
	unsigned char   m_RightArray[256]; 
	float           m_ViewerRotate;
    //Left_back , right_back, right_front,focus_front,left_front
	POINT           m_pos[5]; 

protected:
    void   FillArray(int startx,int startz,int endx,int endz,
		                 unsigned char *pArray,bool bLeft); 

    int    m_HalfFOV;
	int    m_ViewDistance;


};

#endif // !defined(AFX_FRUSTUMCULL_H__FBDF93B4_E439_11D5_812C_5254AB37CDC9__INCLUDED_)
