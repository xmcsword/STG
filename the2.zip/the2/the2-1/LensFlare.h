// LensFlare.h: interface for the CLensFlare class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LENSFLARE_H__83296961_4ADF_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_LENSFLARE_H__83296961_4ADF_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "cmath.h"
#include "heightmap.h"
class CLensFlare  
{
public:
	CLensFlare();
	virtual ~CLensFlare();
	bool InitLensFlare();
    void RenderLensFlare();
protected:
    bool CheckLightVisible();

    CHeightmap m_cHmap;
	CMath      m_math;

	VERTEX     m_LightPos;
	float      sx,sy;

	unsigned int m_texFlare[7];
};

#endif // !defined(AFX_LENSFLARE_H__83296961_4ADF_11D6_812C_5254AB37CDC9__INCLUDED_)
