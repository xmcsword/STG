// CreditSheet.cpp: implementation of the CCreditSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CreditSheet.h"
#include "texmanager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CCreditSheet::CCreditSheet()
{
}
CCreditSheet::~CCreditSheet()
{
}
bool CCreditSheet::InitSheet()
{
	RECT rect;
	rect.top=555;
	rect.bottom=585;
	rect.left=300;
	rect.right=500;
    m_cBackButton.SetButton(rect,"Back");
	/////////////////////photo bar
   	rect.top=60;
	rect.bottom=265;
	rect.left=20;
	rect.right=215;

	unsigned int texid[4];
	CTexManager cTexManager;
	texid[0]=cTexManager.GetTextureID(TEX_MY_PHOTO_0);
	texid[1]=cTexManager.GetTextureID(TEX_MY_PHOTO_1);
	texid[2]=cTexManager.GetTextureID(TEX_MY_PHOTO_2);

	m_texDoc=cTexManager.GetTextureID(TEX_DOCUMENT);
	
	m_cPhotoBar.SetChangeBar(rect,texid,3,0);
	///////////// processbar
	m_iSelect=-1;
    m_bActive=false;
	//////////////
	return true;
}
int CCreditSheet::RenderSheet()
{
	if(!m_bActive)return -1;
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		m_iSelect=0;
		return 0;
	}
	if(CInput::m_keys[13]) // key enter pressed
	{
		CInput::m_keys[13]=false;
		m_iSelect=0;
		return 0;
	}
	DrawBackGround();

    m_cBackButton.RenderButton();
    if(m_cBackButton.m_bSelected)
	{
		m_cBackButton.m_bSelected=false;
		m_iSelect=0;
		return 0;
	}
	m_cPhotoBar.RenderChangeBar();

	/////////////////////////////
	glColor3f(1,1,1);
    glBindTexture(GL_TEXTURE_2D,m_texDoc);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
		glTexCoord2f(0,0);
	    glVertex3f(-165, -225 ,-520);
		glTexCoord2f(1,0);
	    glVertex3f(375, -225 ,-520);
		glTexCoord2f(1,1);
	    glVertex3f(375, 235 ,-520);
		glTexCoord2f(0,1);
	    glVertex3f(-165, 235 ,-520);
	glEnd();
    
	/////////////////////////////

	return -1;
}
void  CCreditSheet::DrawBackGround()
{
	///////////////////title and rectangle
	CImgText cText;
	glColor3f(1,1,0);
	cText.PrintString(20,14,"Make Friends",0,24,0);

	glColor3f(0.8f,0.8f,0);
	cText.PrintString(240,60,"Who am I",0,18,0);

    cText.PrintString(20,295,"My Information",0,18,0);
	glColor3f(0.4f,0.8f,0);
	int y=340;
	int dy=62;
    cText.PrintString(20,y     ,"Name:",0,16,0);
    cText.PrintString(20,y+dy  ,"E-Mail:",0,16,0);
    cText.PrintString(20,y+dy*2,"Birth Day:",0,16,0);

	glColor3f(0.0f,1.0f,0);
    y=365;
    cText.PrintString(45,y     ,"Wu Xue Ping",0,16,0);
    cText.PrintString(45,y+dy  ,"Hunter3d@263.net",0,16,0);
    cText.PrintString(45,y+dy*2,"1978.12.12",0,16,0);


	glColor3f(0,0.7f,0);
	////////////////
	int x0=10,x1=800-x0;
	int y0=50,y1=540;
    DrawRectangle( x0, x1, y0, y1);  //  All
    x0=13;  x1=225;
	y0=53;  y1=275;
    DrawRectangle( x0, x1, y0, y1);  // left top
	y0=278;  y1=537;
    DrawRectangle( x0, x1, y0, y1);  // left bottom
	x0=228;  x1=787;
	y0=53, y1=537;
    DrawRectangle( x0, x1, y0, y1);  // right 


	glColor3f(1,1,1);
}
void CCreditSheet::DrawRectangle(int x0,int x1,int y0,int y1)
{
	glBegin(GL_LINE_LOOP);
		glVertex3i(x0-400,300-y0,-520);
		glVertex3i(x1-400,300-y0,-520);
		glVertex3i(x1-400,300-y1,-520);
		glVertex3i(x0-400,300-y1,-520);
    glEnd();
}



