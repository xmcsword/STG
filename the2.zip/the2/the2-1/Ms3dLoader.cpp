// CMs3dLoader.cpp: implementation of the CMs3dLoader2 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Ms3dLoader.h"
#include "stdio.h"
#include "cmath.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// File header

/////////////////////////////////////////////
CMs3dLoader::CMs3dLoader()
{
	m_numMeshes = 0;
	m_pMeshes = NULL;
	m_numTriangles = 0;
	m_pTriangles = NULL;
	m_numVertices = 0;
	m_pVertices = NULL;

}

CMs3dLoader::~CMs3dLoader()
{
	unsigned short i;
	for ( i = 0; i < m_numMeshes; i++ )
		delete[] m_pMeshes[i].m_pTriangleIndices;

	m_numMeshes = 0;
	if ( m_pMeshes != NULL )
	{
		delete[] m_pMeshes;
		m_pMeshes = NULL;
	}

	m_numTriangles = 0;
	if ( m_pTriangles != NULL )
	{
		delete [] m_pTriangles;
		m_pTriangles = NULL;
	}

	m_numVertices = 0;
	if ( m_pVertices != NULL )
	{
		delete [] m_pVertices;
		m_pVertices = NULL;
	}

}

bool CMs3dLoader::Load( const char *filename,float scale )
{
	FILE* file;
	//Open the .ms3d model file
	if((file= fopen(filename, "rb"))==NULL)
		return false;
		
	MS3DHeader Header ;
	fread(&Header.m_ID, sizeof(char), 10, file);
	fread(&Header.m_version, sizeof(int), 1, file);
	if ( strncmp( Header.m_ID, "MS3D000000", 10 ) != 0 )
	{ 
		MessageBox(NULL,"id error","ERROR",MB_OK|MB_ICONEXCLAMATION);
		fclose(file);
		return false; // "Not a valid Milkshape3D model file."
	}
	if ( Header.m_version < 3 ||Header.m_version > 4 )
	{
		MessageBox(NULL,"version error","ERROR",MB_OK|MB_ICONEXCLAMATION);
		fclose(file);
		return false; // "Unhandled file version. Only Milkshape3D Version 1.3 and 1.4 is supported." );
	}

	fread(&m_numVertices, sizeof(unsigned short), 1, file);

	m_pVertices = new Vertex[m_numVertices];
	MS3DVertex ms3dVertex;
	for (unsigned short i = 0; i < m_numVertices; i++ )
	{
        fread( &ms3dVertex.m_flags,    sizeof(unsigned char),1,file);
        fread(  ms3dVertex.m_vertex,   sizeof(float),        3,file);
        fread( &ms3dVertex.m_refCount, sizeof(unsigned char),1,file);
        fread( &ms3dVertex.m_boneID,   sizeof(char),         1,file);
        /////////////data copy
		m_pVertices[i].m_location[0]=ms3dVertex.m_vertex[0];
		m_pVertices[i].m_location[1]=ms3dVertex.m_vertex[1];
		m_pVertices[i].m_location[2]=ms3dVertex.m_vertex[2];
		///////////////zoom
		m_pVertices[i].m_location[0] *=scale;
		m_pVertices[i].m_location[1] *=scale;
		m_pVertices[i].m_location[2] *=scale;
/*
 		if(m_pVertices[i].m_location[0]>m_boundary.maxx)m_boundary.maxx=m_pVertices[i].m_location[0];
		if(m_pVertices[i].m_location[0]<m_boundary.minx)m_boundary.minx=m_pVertices[i].m_location[0];
		if(m_pVertices[i].m_location[1]>m_boundary.maxy)m_boundary.maxy=m_pVertices[i].m_location[1];
		if(m_pVertices[i].m_location[1]<m_boundary.miny)m_boundary.miny=m_pVertices[i].m_location[1];
		if(m_pVertices[i].m_location[2]>m_boundary.maxz)m_boundary.maxz=m_pVertices[i].m_location[2];
		if(m_pVertices[i].m_location[2]<m_boundary.minz)m_boundary.minz=m_pVertices[i].m_location[2];
*/
	}
    ///////////read Triangles///////////////////////////
    fread(&m_numTriangles, sizeof(unsigned short), 1, file);
	m_pTriangles = new Triangle[m_numTriangles];
    MS3DTriangle ms3dTriangle;
	CMath  cmath;
	for ( i = 0; i < m_numTriangles; i++ )
	{
        fread(&ms3dTriangle.m_flags,            sizeof(unsigned short),   1, file);
        fread( ms3dTriangle.m_vertexIndices,    sizeof(unsigned short),   3, file);
        fread( ms3dTriangle.m_vertexNormals[0], sizeof(float), 3, file);
        fread( ms3dTriangle.m_vertexNormals[1], sizeof(float), 3, file);
        fread( ms3dTriangle.m_vertexNormals[2], sizeof(float), 3, file);

        fread( ms3dTriangle.m_u,                sizeof(float), 3, file);
        fread( ms3dTriangle.m_v,                sizeof(float), 3, file);
  
        fread(&ms3dTriangle.m_smoothingGroup,   sizeof(unsigned char), 1, file);
        fread(&ms3dTriangle.m_groupIndex  ,     sizeof(unsigned char), 1, file);

        //////////////////////////////////////////////////////////////////////
		int v1,v2,v3;
		v1=ms3dTriangle.m_vertexIndices[0];
		v2=ms3dTriangle.m_vertexIndices[1];
		v3=ms3dTriangle.m_vertexIndices[2];

        NORMAL normal=cmath.GetNormal(m_pVertices[v1].m_location,
			                          m_pVertices[v2].m_location,
						              m_pVertices[v3].m_location);

		m_pTriangles[i].m_normal[0]=normal.nx;
		m_pTriangles[i].m_normal[1]=normal.ny;
		m_pTriangles[i].m_normal[2]=normal.nz;

		memcpy( m_pTriangles[i].m_u, ms3dTriangle.m_u, sizeof( float )*3 );
		memcpy( m_pTriangles[i].m_v, ms3dTriangle.m_v, sizeof( float )*3 );
		memcpy( m_pTriangles[i].m_vertexIndices, ms3dTriangle.m_vertexIndices, sizeof(unsigned short )*3 );

	}
    //////////////read Meshes/////////////
    fread(&m_numMeshes, sizeof(unsigned short), 1, file);
	m_pMeshes = new Mesh[m_numMeshes];

	MS3DMesh ms3dMesh ;
	////////////allocate maximum memory : m_numTriangles
	ms3dMesh.m_TriangleIndices = new unsigned short [m_numTriangles];

	for ( i = 0; i < m_numMeshes; i++ )
	{
		fread(&ms3dMesh.m_flags,        sizeof(unsigned char), 1,  file);
		fread( ms3dMesh.m_name,         sizeof(char),          32, file);
		fread(&ms3dMesh.m_numTriangles, sizeof(unsigned short ),           1,  file);

		fread( ms3dMesh.m_TriangleIndices, sizeof(unsigned short), ms3dMesh.m_numTriangles, file);
		fread(&ms3dMesh.m_MaterialIndex, sizeof(char),  1, file);
        //////////////////////copy data
		m_pMeshes[i].m_pTriangleIndices=new unsigned short [ms3dMesh.m_numTriangles];
		memcpy( m_pMeshes[i].m_pTriangleIndices,ms3dMesh.m_TriangleIndices, sizeof( unsigned short )*ms3dMesh.m_numTriangles );

	    m_pMeshes[i].m_textureIndex=ms3dMesh.m_MaterialIndex;
	    m_pMeshes[i].m_numTriangles=ms3dMesh.m_numTriangles;
	}
	delete [] ms3dMesh.m_TriangleIndices;

    ////////////////read texture/////////////
    fclose(file);

	Process();
    
	return true;
}
void CMs3dLoader::Process()
{

	float bias[3]={m_pVertices[51].m_location[0],
		           m_pVertices[51].m_location[1],
                   m_pVertices[51].m_location[2]};

	for (unsigned short i = 0; i < m_numVertices; i++ )
	{
		m_pVertices[i].m_location[0] -= bias[0];
		m_pVertices[i].m_location[1] -= bias[1];
		m_pVertices[i].m_location[2] -= bias[2];
	}
	for ( i = 0; i < m_numVertices; i++ )
	{
 		if(m_pVertices[i].m_location[0]>m_boundary.maxx)m_boundary.maxx=m_pVertices[i].m_location[0];
		if(m_pVertices[i].m_location[0]<m_boundary.minx)m_boundary.minx=m_pVertices[i].m_location[0];
		if(m_pVertices[i].m_location[1]>m_boundary.maxy)m_boundary.maxy=m_pVertices[i].m_location[1];
		if(m_pVertices[i].m_location[1]<m_boundary.miny)m_boundary.miny=m_pVertices[i].m_location[1];
		if(m_pVertices[i].m_location[2]>m_boundary.maxz)m_boundary.maxz=m_pVertices[i].m_location[2];
		if(m_pVertices[i].m_location[2]<m_boundary.minz)m_boundary.minz=m_pVertices[i].m_location[2];
	}
	/*
 	m_boundary.maxx=m_pVertices[65].m_location[0];
	m_boundary.minx=m_pVertices[51].m_location[0];

	m_boundary.maxy=m_pVertices[48].m_location[1];
	m_boundary.miny=m_pVertices[51].m_location[1];

	m_boundary.maxz=m_pVertices[71].m_location[2];
	m_boundary.minz=m_pVertices[51].m_location[2];
*/
}
VERTEX CMs3dLoader::GetVertex(int number)
{
	if(number<0 || number>(m_numVertices-1) )number=0;

	return VERTEX(m_pVertices[number].m_location[0],
		          m_pVertices[number].m_location[1],
				  m_pVertices[number].m_location[2]);

}
void CMs3dLoader::Render() 
{	
	for ( int i = 0; i < m_numMeshes; i++ )
	{
		glBegin( GL_TRIANGLES );
		{
			for ( int j = 0; j < m_pMeshes[i].m_numTriangles; j++ )
			{
				int triangleIndex = m_pMeshes[i].m_pTriangleIndices[j];
			    for ( int k = 0; k < 3; k++ )
				{
				    	int index = m_pTriangles[triangleIndex].m_vertexIndices[k];
					    glNormal3fv( m_pTriangles[triangleIndex].m_normal );
					    glTexCoord2f( m_pTriangles[triangleIndex].m_u[k], m_pTriangles[triangleIndex].m_v[k] );
					    glVertex3fv( m_pVertices[index].m_location );
				}
			}
		}
		glEnd();
	}

//  DrawBoundary();
}
void CMs3dLoader::DrawBoundary()
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(1,1,1);
	glBegin(GL_LINE_STRIP);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.minz);

	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.minz);
	glEnd();
	glBegin(GL_LINES);
	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.minz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.minz);

	    glVertex3f(m_boundary.maxx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.maxx,m_boundary.maxy,m_boundary.maxz);

	    glVertex3f(m_boundary.minx,m_boundary.miny,m_boundary.maxz);
	    glVertex3f(m_boundary.minx,m_boundary.maxy,m_boundary.maxz);
	glEnd();
	glColor3f(1,1,1);
}
