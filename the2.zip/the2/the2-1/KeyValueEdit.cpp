// KeyValueEdit.cpp: implementation of the CKeyValueEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "KeyValueEdit.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CKeyValueEdit::CKeyValueEdit()
{
	m_bEditting=false;
}
CKeyValueEdit::~CKeyValueEdit()
{
}
void  CKeyValueEdit::SetKeyValueEdit(RECT rect,int value)
{
	char sText[32];
    TranslateValueToString(value,sText);
	CGraphButton::SetButton(rect,sText);
	m_iKeyValue=value;

}
void CKeyValueEdit::SetKeyValue(int value)
{
	char sText[32];
    TranslateValueToString(value,sText);
	CGraphButton::SetButtonText(sText);
	m_iKeyValue=value;
}
void  CKeyValueEdit::RenderKeyValueEdit()
{
    UpdateKeyValueEdit();
    if(m_iKeyValue==0)
		CGraphButton::SetNormalColor(0.5f,0,0);
	else 
		CGraphButton::SetNormalColor(0,0.4f,0);

	CGraphButton::RenderButton();
}

void  CKeyValueEdit::UpdateKeyValueEdit()
{
    if(m_bSelected)
	{
		m_bSelected=false;
        strcpy(m_sText,"_");
		m_bEditting=true;
	}
	if(m_bEditting)
	{
		static int flicker=0;
    	flicker++;
    	if(flicker>50)flicker=0;
	    if(flicker<25)CGraphButton::SetButtonText("_");
	    else CGraphButton::SetButtonText(" ");
		//////////// mouse cling
//		SetCursorPos((m_rect.left+m_rect.right)/2,(m_rect.top+m_rect.bottom)/2+30);
        char str[32];
		if(m_cInput.m_keys[MOUSE_0])
		{
			m_cInput.m_keys[MOUSE_0]=false;
			if(m_iState==BUTTON_NORMAL)
			    TranslateValueToString(m_iKeyValue,str);
			else
			{
                TranslateValueToString(MOUSE_0,str);
         		m_iKeyValue=MOUSE_0;
			}
        	FinishInput();
			CGraphButton::SetButtonText(str);
	
			return;
		}
		if(m_cInput.m_keys[MOUSE_1])
		{
			m_cInput.m_keys[MOUSE_1]=false;
			if(m_iState==BUTTON_NORMAL)
			    TranslateValueToString(m_iKeyValue,str);
			else
			{
			    TranslateValueToString(MOUSE_1,str);
    			m_iKeyValue=MOUSE_1;
			}
            FinishInput();
			CGraphButton::SetButtonText(str);
			return;
		}
		for(int i=0;i<256;i++)
		{	
			if(m_cInput.m_keys[i])
			{
				if(TranslateValueToString(i,str))
				{
                    FinishInput();
					CGraphButton::SetButtonText(str);
					m_iKeyValue=i;
					return;
				}
			}
		}

	}
}
void  CKeyValueEdit::FinishInput()
{
	m_bEditting=false;
	m_bValueChanged=true;
}
bool CKeyValueEdit::IsValueChanged()
{
	if(m_bValueChanged)
	{
		m_bValueChanged=false;
		return true;
	}
	return false;
}
int   CKeyValueEdit::GetKeyValue()
{
    return m_iKeyValue;
}
bool  CKeyValueEdit::TranslateValueToString(int value, char *str)
{
	if( (value>64 && value<91) || ( value>47 && value <58) )
	{
		str[0]=value;
		str[1]=NULL;
		return true;
	}
    if(value>95 && value<106 )
	{
		char s[20];
		wsprintf(s,"Pad num :%d",value-96);
		strcpy(str,s);
		return true;
	}
	if(value>111 && value<124)
	{
		char s[20];
		wsprintf(s,"F%d",value-111);
		strcpy(str,s);
		return true;
	}
	if(value==37)
	{
		char s[20];
		wsprintf(s,"Left");
		strcpy(str,s);
		return true;
	}
	if(value==38)
	{
		char s[20];
		wsprintf(s,"Up");
		strcpy(str,s);
		return true;
	}
	if(value==39)
	{
		char s[20];
		wsprintf(s,"Right");
		strcpy(str,s);
		return true;
	}
	if(value==40)
	{
		char s[20];
		wsprintf(s,"Down");
		strcpy(str,s);
		return true;
	}
	if(value==33)
	{
		char s[20];
		wsprintf(s,"Page Up");
		strcpy(str,s);
		return true;
	}
	if(value==34)
	{
		char s[20];
		wsprintf(s,"Page Down");
		strcpy(str,s);
		return true;
	}
	if(value==35)
	{
		char s[20];
		wsprintf(s,"End");
		strcpy(str,s);
		return true;
	}
		if(value==36)
	{
		char s[20];
		wsprintf(s,"Home");
		strcpy(str,s);
		return true;
	}
	if(value==45)
	{
		char s[20];
		wsprintf(s,"Insert");
		strcpy(str,s);
		return true;
	}
	if(value==46)
	{
		char s[20];
		wsprintf(s,"Delete");
		strcpy(str,s);
		return true;
	}
	if(value==110)
	{
		char s[20];
		wsprintf(s,"Del");
		strcpy(str,s);
		return true;
	}
	if(value==111)
	{
		char s[20];
		wsprintf(s,"/");
		strcpy(str,s);
		return true;
	}
	if(value==106)
	{
		char s[20];
		wsprintf(s,"*");
		strcpy(str,s);
		return true;
	}
	if(value==109)
	{
		char s[20];
		wsprintf(s,"-");
		strcpy(str,s);
		return true;
	}
	if(value==107)
	{
		char s[20];
		wsprintf(s,"+");
		strcpy(str,s);
		return true;
	}
	if(value==13)
	{
		char s[20];
		wsprintf(s,"Enter");
		strcpy(str,s);
		return true;
	}
	if(value==32)
	{
		char s[20];
		wsprintf(s,"Space");
		strcpy(str,s);
		return true;
	}
	if(value==16)
	{
		char s[20];
		wsprintf(s,"Shift");
		strcpy(str,s);
		return true;
	}
	if(value==17)
	{
		char s[20];
		wsprintf(s,"Ctrl");
		strcpy(str,s);
		return true;
	}
	if(value==27)
	{
		char s[20];
		wsprintf(s,"Escape");
		strcpy(str,s);
		return true;
	}
	if(value==MOUSE_0)
	{
		char s[20];
		wsprintf(s,"Mouse1");
		strcpy(str,s);
		return true;
	}
	if(value==MOUSE_1)
	{
		char s[20];
		wsprintf(s,"Mouse2");
		strcpy(str,s);
		return true;
	}
	if(value==0)
	{
		char s[20];
		wsprintf(s,"No Key");
		strcpy(str,s);
		return true;
	}
	return false;
}










