// NewGameSheet.cpp: implementation of the CNewGameSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NewGameSheet.h"
#include "texmanager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNewGameSheet::CNewGameSheet()
{
}
CNewGameSheet::~CNewGameSheet()
{
}
bool CNewGameSheet::InitSheet()
{
	/////////////////Button
	RECT rect;
	rect.top=555;
	rect.bottom=585;
	for(int i=0;i<3;i++)
	{
		rect.left=50+i*250;
		rect.right=250+i*250;
	    m_cButton[i].SetButtonRect(rect);
	}
    m_cButton[0].SetButtonText("Back");
	m_cButton[1].SetButtonText("Game Setting");
	m_cButton[2].SetButtonText("Start Game");

	//////////////////// m_cMissionListBox
	rect.left=30;
	rect.right=380;
	rect.top=70;
	rect.bottom=200;
	m_cMissionSelectBox.SetSelectBox(rect,"mission/missionlist.txt");

	///////////////// sketch view
	rect.left=35;
	rect.right=375;
	rect.top=245;
	rect.bottom=495;

	unsigned int texid[6];
	CTexManager cTexManager;
	texid[0]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_0);
	texid[1]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_1);
	texid[2]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_2);
	texid[3]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_3);
	texid[4]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_4);
	texid[5]=cTexManager.GetTextureID(TEX_MISSION_SKETCH_5);
	
	m_cSketchBar.SetChangeBar(rect,texid,6,0);
    
	/////////////////// m_cMissionViewBox
	rect.left=405;
	rect.right=770;
	rect.top=70;
	rect.bottom=520;

	m_cMissionViewBox.SetViewBox(rect,"Mission/missionScript1.txt");

	///////////////////////////////////

    m_bActive=false;
	m_iSelect=-1;
	return true;
}
int  CNewGameSheet::RenderSheet()
{
	if(!m_bActive)return -1;

	UpdateSheet();

	DrawBackground();

	for(int i=0;i<3;i++)
	{
	    m_cButton[i].RenderButton();
	}
	/////////////////////////////
	m_cMissionSelectBox.RenderSelectBox();
	m_cSketchBar.RenderChangeBar();
	m_cMissionViewBox.RenderViewBox();

	for(i=0;i<3;i++)
	{
	    if(m_cButton[i].m_bSelected)
		{
			m_cButton[i].m_bSelected=false;
			m_iSelect=i;
			return i;
		}
	} 
	return -1;
}

void CNewGameSheet::UpdateSheet()
{
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		m_iSelect=0;
		return ;
	}
	if(CInput::m_keys[13]) // key enter pressed
	{
		CInput::m_keys[13]=false;
		m_iSelect=2;
		return ;
	}
	if(m_cMissionSelectBox.m_bValueChanged)
	{
		int select=m_cMissionSelectBox.GetSelect();
		m_cSketchBar.SetItem((select*2)%m_cSketchBar.GetTotalItemNumber());
	    char filename[64];
		wsprintf(filename,"Mission/missionScript%d.txt",select+1);
		m_cMissionViewBox.SetText(filename);
	}
}
int CNewGameSheet::GetMissionSelect()
{
    return m_cMissionSelectBox.GetSelect();
}
void CNewGameSheet::DrawBackground()
{
	CImgText cText;
	glColor3f(1,1,0);
	cText.PrintString(20,20,"Mission Select",0,24,0);

	glColor3f(0,0.7f,0);
	////////////////
	int x0=10,x1=800-x0;
	int y0=50,y1=540;
    DrawRectangle( x0, x1, y0, y1);  //  All

    x0=30;  x1=380;
	y0=220;  y1=520;
    DrawRectangle( x0, x1, y0, y1);  //  down
}
void CNewGameSheet::DrawRectangle(int x0,int x1,int y0,int y1)
{
	glBegin(GL_LINE_LOOP);
		glVertex3i(x0-400,300-y0,-520);
		glVertex3i(x1-400,300-y0,-520);
		glVertex3i(x1-400,300-y1,-520);
		glVertex3i(x0-400,300-y1,-520);
    glEnd();
}