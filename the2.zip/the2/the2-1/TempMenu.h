// TempMenu.h: interface for the CTempMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEMPMENU_H__5BE0DB84_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
#define AFX_TEMPMENU_H__5BE0DB84_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "TempSheet.h"
#include "optionssheet.h"

class CTempMenu  
{
public:
	CTempMenu();
	virtual ~CTempMenu();

	void  RenderMenu();
    bool  LoadMenu();
    void  DeleteMenu();

private:
	void   UpdateMenu();
	void   DrawCursor();
	void   DrawBackGround();

    CTempSheet      *m_cTempSheet;
	COptionsSheet   *m_cOptionsSheet;

	bool   m_bActivate;
	bool   m_bResource;

	unsigned int        m_texCursor;
	unsigned int        m_texBkg;
    CInput              m_cInput;
};

#endif // !defined(AFX_TEMPMENU_H__5BE0DB84_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
