// PlantManager.h: interface for the CPlantManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLANTMANAGER_H__82047981_9E72_11D6_813F_5254AB37CDC9__INCLUDED_)
#define AFX_PLANTMANAGER_H__82047981_9E72_11D6_813F_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "heightmap.h"
#include "bush.h"
#include "grass.h"
#include "3dtree.h"
#include "pine.h"

class CPlantManager  
{
public:
	CPlantManager();
	virtual ~CPlantManager();

	bool InitPlantManager();
	void RenderPlant();

private:


	CHeightmap  m_cHmap;
	CBush       m_cBush1;
	C3DTree     m_cTree1;
	C3DTree     m_cTree2;
	CPine       m_cPine;
};

#endif // !defined(AFX_PLANTMANAGER_H__82047981_9E72_11D6_813F_5254AB37CDC9__INCLUDED_)
