// ListBox.h: interface for the CListBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTBOX_H__3DE48AC1_AAEC_11D6_8153_5254AB37CDC9__INCLUDED_)
#define AFX_LISTBOX_H__3DE48AC1_AAEC_11D6_8153_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphedit.h"

class CListBox  
{
public:
	CListBox();
	virtual ~CListBox();
	
	void SetListBox(RECT rect,int numItem,char *titleFile,int curItem=0);
    void SetSelect(int iItem);
	void ClearCurrentItem();
	void SetCurrentItemEnableEdit();
	int  GetSelect();
	void SaveItemTitle(char *titleFile);

	void RenderListBox();

	bool m_bValueChanged;
private:
	void  UpdateListBox();
	RECT  m_rect;
	int   m_iMaxItem;
    int   m_iSelect;

	CGraphEdit  *m_pEdit;
};

#endif // !defined(AFX_LISTBOX_H__3DE48AC1_AAEC_11D6_8153_5254AB37CDC9__INCLUDED_)
