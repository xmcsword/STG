// GraphButton.h: interface for the CGraphButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHBUTTON_H__66701B21_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_GRAPHBUTTON_H__66701B21_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define   BUTTON_DEAD     -1
#define   BUTTON_NORMAL    0
#define   BUTTON_ACTIVATE  1
#define   BUTTON_PUSHED    2

#define   TEXT_ALIGN_LEFT  -1
#define   TEXT_ALIGN_CENTER 0
#define   TEXT_ALIGN_RIGHT  1


#include "input.h"
#include "imgtext.h"

class CGraphButton  
{
public:
	CGraphButton();
	virtual ~CGraphButton();
	void   RenderButton();
	void   SetButton(RECT rect,char sText[],int state=BUTTON_NORMAL,int iTextAlign=TEXT_ALIGN_CENTER);
	void   SetButton(RECT rect,unsigned int texID,int state=BUTTON_NORMAL);
	void   SetButtonRect(RECT rect);
	void   SetButtonText(char sText[],int iTextAlign=TEXT_ALIGN_CENTER);	
	void   SetButtonPicture(unsigned int texID);
	void   SetButtonState(int state);
	void   SetActivateColor(float r,float g,float b);
	void   SetNormalColor(float r,float g,float b);
	void   SetRectangleColor(float r,float g,float b);

	void   UpdateButton();
	void   DrawButton();

    bool     m_bSelected;
	RECT     m_rect;
	int      m_iState;
	bool     m_bShowPicture;
	char     m_sText[32];
	CInput   m_cInput;
private:
	bool     IsInRect();

	unsigned int m_texID;
	CImgText     m_cText;
	int          m_iTextAlign;

	float    m_crNormal[3];
	float    m_crActivate[3];
    float    m_crRect[3];
};

#endif // !defined(AFX_GRAPHBUTTON_H__66701B21_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_)
