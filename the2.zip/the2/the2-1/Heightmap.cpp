// Heightmap.cpp: implementation of the CHeightmap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Heightmap.h"
#include "stdio.h"
#include "GameSetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
MOVE_VERTEX    * CHeightmap::m_pMovemap=NULL;
unsigned char  * CHeightmap::m_pTmap=NULL;
CFrustumCull     CHeightmap::m_cFrustumCull=CFrustumCull();

unsigned char  * CHeightmap::m_pCovermap=NULL;
GRID_BIAS      * CHeightmap::m_pCoverBias=NULL;

VERTEX           CHeightmap::m_ViewPos=VERTEX(0,0,0);
float            CHeightmap::m_ViewRotX=0;
float            CHeightmap::m_ViewRotY=0;

int              CHeightmap::m_numUser=0;
int              CHeightmap::m_ViewOffsetX=0;
int              CHeightmap::m_ViewOffsetZ=0;

//////////////focus
double           CHeightmap::m_focusPosX=0;
double           CHeightmap::m_focusPosY=0;
double           CHeightmap::m_focusPosZ=0;
double           CHeightmap::m_distFromFocus=0;
int              CHeightmap::m_focusState=FOCUS_GROUND;
bool             CHeightmap::m_bAttack=false;
float            CHeightmap::m_myHealth=1;

//////////building
int              CHeightmap::m_numBuilding=0;
VERTEX          *CHeightmap::m_buildingPos=NULL;
BOUNDARY_3D    **CHeightmap::m_bigBndyBuilding=NULL;
BOUNDARY_3D    **CHeightmap::m_smallBndyBuilding=NULL;

/////////////sprite
int              CHeightmap::m_numSoldier=0;
VERTEX          *CHeightmap::m_soldierPos=NULL;
float           *CHeightmap::m_soldierRot=NULL;
float           *CHeightmap::m_soldierHealth=NULL;

int              CHeightmap::m_numTriangles=0;

CHeightmap::CHeightmap()
{
	if(m_numUser==0)
	{
		/////////read terrain map
    	if(!ReadTerrainmapFile())
		{
		    MessageBox(0, "read heightmap failed", "Error", MB_OK | MB_ICONERROR);
		    return ;
		}
    	if(!ReadPlantmapFile())
		{
		    MessageBox(0, "read plantmap failed", "Error", MB_OK | MB_ICONERROR);
		    return ;
		}
		GetMissionSetting();

		m_pMovemap =new MOVE_VERTEX [256*256];

	}
	m_numUser++;
}

CHeightmap::~CHeightmap()
{
	m_numUser--;
	if(m_numUser==0)
	{
		if(m_pTmap!=NULL)
		{
		    delete [] m_pTmap;
    		m_pTmap=NULL;
		}
		if(m_pCovermap!=NULL)
		{
			delete [] m_pCovermap;
	    	m_pCovermap=NULL;
		}
		if(m_pCoverBias!=NULL)
		{
			delete [] m_pCoverBias;
            m_pCoverBias=NULL;
		}
		if(m_pMovemap!=NULL)
		{
			delete [] m_pMovemap;
	    	m_pMovemap=NULL;
		}
		if(m_bigBndyBuilding!=NULL)
		{
			///// only release pointers
			delete [] m_bigBndyBuilding;
	    	m_bigBndyBuilding=NULL;
		}
		if(m_smallBndyBuilding!=NULL)
		{
			///// only release pointers
			delete [] m_smallBndyBuilding;
	    	m_smallBndyBuilding=NULL;
		}
		if(m_buildingPos!=NULL)
		{
			///// only release pointers
			delete [] m_buildingPos;
	    	m_buildingPos=NULL;
		}
		if(m_soldierPos!=NULL)
		{
			///// only release pointers
			delete [] m_soldierPos;
	    	m_soldierPos=NULL;
		}
		if(m_soldierRot!=NULL)
		{
			///// only release pointers
			delete [] m_soldierRot;
	    	m_soldierRot=NULL;
		}	
		if(m_soldierHealth!=NULL)
		{
			///// only release pointers
			delete [] m_soldierHealth;
	    	m_soldierHealth=NULL;
		}	
	}
}
bool CHeightmap::GetMissionSetting()
{
	char missionName[64];
	char sINIPath[MAX_PATH];
	wsprintf(missionName,"mission/mission%d.ini",CGameSetting::m_iMissionSelect);
	MakeModulePath(missionName, sINIPath);

	m_numBuilding = GetPrivateProfileInt("Building", "HouseNumber", 1, sINIPath);
    m_buildingPos = new VERTEX[m_numBuilding];
    m_bigBndyBuilding   = new BOUNDARY_3D* [m_numBuilding];
    m_smallBndyBuilding = new BOUNDARY_3D* [m_numBuilding];

	char keyName[64];
	for(int i=0;i<m_numBuilding;i++)
	{
		wsprintf(keyName,"House%dX",i+1);
		m_buildingPos[i].xpos=(float)GetPrivateProfileInt("Building", keyName, 1000, sINIPath);
		wsprintf(keyName,"House%dZ",i+1);
		m_buildingPos[i].zpos=(float)GetPrivateProfileInt("Building", keyName, 1000, sINIPath);
	}


	m_numSoldier = GetPrivateProfileInt("Sprite", "SpriteNumber", 1, sINIPath);
    m_soldierPos = new VERTEX[m_numSoldier];
    m_soldierRot = new float [m_numSoldier];
	m_soldierHealth=new float [m_numSoldier];

	for( i=0;i<m_numSoldier;i++)
	{
		wsprintf(keyName,"Sprite%dX",i+1);
		m_soldierPos[i].xpos=(float)GetPrivateProfileInt("Sprite", keyName, 1000, sINIPath);
		wsprintf(keyName,"Sprite%dZ",i+1);
		m_soldierPos[i].zpos=(float)GetPrivateProfileInt("Sprite", keyName, 1000, sINIPath);
		wsprintf(keyName,"Sprite%dRot",i+1);
		m_soldierRot[i]     =(float)GetPrivateProfileInt("Sprite", keyName, 0, sINIPath);
        m_soldierHealth[i]=1;
	}
	return true;
}
void CHeightmap::UpdateHeightmap()
{
	m_cFrustumCull.m_ViewerRotate=m_ViewRotY;

	m_cFrustumCull.UpdateFrustumCull();
     
/*  m_rect.minz=m_cFrustumCull.m_pos[m_upPos].y-2;
    m_rect.maxz=m_cFrustumCull.m_pos[m_downPos].y+2;
    m_rect.minx=m_cFrustumCull.m_pos[minx].x-2;
    m_rect.maxx=m_cFrustumCull.m_pos[maxx].x+2;
*/
	int offsetx,offsetz;
	offsetx=int(m_ViewPos.xpos*0.025f);
	if(offsetx<0)offsetx-=1;

	offsetz=int(m_ViewPos.zpos*0.025f);
	if(offsetz<0)offsetz-=1;
	////////////////////////////////////////////////
	int x,z;
	int startx;
	int xpos,zpos;

	int uppos=m_cFrustumCull.m_upPos;
	int downpos=m_cFrustumCull.m_downPos;

	for(z=(m_cFrustumCull.m_pos[uppos].y-2);z<(m_cFrustumCull.m_pos[downpos].y+3);z++)
	{
	    zpos=((z-128+offsetz)*4)%256;
	    if(zpos<0)zpos=256+zpos;

        startx=((  (m_cFrustumCull.m_LeftArray[z]-2)  -128+offsetx)*4)%256;
	    if(startx<0)startx=256+startx;

		xpos=startx;

		for(x=(m_cFrustumCull.m_LeftArray[z]-2);x<(m_cFrustumCull.m_RightArray[z]+3);x++)
		{
			m_pMovemap[z*256+x].xpos=xpos;
			m_pMovemap[z*256+x].zpos=zpos;
    
			xpos+=4;
			if(xpos>252)xpos=0;
		}
	}
    ////////////////////////////////////////////////
	m_ViewOffsetX=offsetx*40;
	m_ViewOffsetZ=offsetz*40;

    m_numTriangles=0;
}
float CHeightmap::GetHeight(VERTEX *checked)
{
	POINT point=ConvertToHeightmap(checked);
	float Xpos,Zpos;

	if(checked->xpos<0)
	    Xpos=1+checked->xpos*0.1f-int(checked->xpos*0.1f);
	else
	    Xpos=checked->xpos*0.1f-int(checked->xpos*0.1f);
	if(checked->zpos<0)
	    Zpos=1+checked->zpos*0.1f-int(checked->zpos*0.1f);
	else 
		Zpos=checked->zpos*0.1f-int(checked->zpos*0.1f);

    ///////////////////////
	float ypos;
	float h11,h12,h22,h21;
	float ha,hb;
	//////////check Xpos and Zpos
	////////////////////////////
	int addx=point.x+1;
	int addy=point.y+1;
	if(addx==256)addx=0;
	if(addy==256)addy=0;

    h11=float(m_pTmap[256*(point.y+0) + (point.x+0)]);
    h12=float(m_pTmap[256*(addy) + (point.x+0)]);
    h21=float(m_pTmap[256*(point.y+0) + addx]);
    h22=float(m_pTmap[256*(addy) + addx]);

	ha=h11+Xpos*(h21-h11);
	hb=h12+Xpos*(h22-h12);	

    ypos=ha +Zpos*(hb-ha);

	return ypos;

}
float CHeightmap::GetHeight(float xpos,float zpos)
{
   VERTEX temp=VERTEX(xpos,0,zpos);
   float ypos=GetHeight(&temp);
   return ypos;
}

bool CHeightmap::CollideCheck(VERTEX startPos,VERTEX endPos,float step)
{
    if(CheckTerrainCollide(startPos,endPos,step))return true;
    if(CheckBuildingCollide(startPos,endPos))return true;
    if(CheckTreeCollide(startPos,endPos))return true;

	return false;
}
bool CHeightmap::CheckTerrainCollide(VERTEX viewPos,VERTEX objPos,float step)
{
	if(step<1)step=1;

	float dy=viewPos.ypos-objPos.ypos;
	float dx=viewPos.xpos-objPos.xpos;
	float dz=viewPos.zpos-objPos.zpos;

	int signx,signy,signz;
	if(dx<0)
	{dx=-dx; signx=-1;}
	else
        signx=1;
	if(dy<0)
	{dy=-dy; signy=-1;}
	else
        signy=1;
	if(dz<0)
	{dz=-dz; signz=-1;}
	else
        signz=1;

	float terrainHeight=GetHeight(&viewPos);
	float CurLineHeight=viewPos.ypos;
	
	float CurZ=viewPos.zpos;
	float CurX=viewPos.xpos;

    VERTEX vertCur;
 	if(dz>dx)
	{
		int times=int(dz/step);
		float deltaH=dy/times;
		float deltax=signx*dx/times;
		times++;
        for(int i=0;i<times;i++)
		{
			vertCur.xpos=CurX;
			vertCur.zpos=CurZ;
			vertCur.ypos=CurLineHeight;

			if(vertCur.ypos<GetHeight(vertCur.xpos,vertCur.zpos) ) return true;

            CurLineHeight -= signy*deltaH;
			CurX-=deltax;
			CurZ-=signz*step;

		}
	}
	else
	{
		int times=int(dx/step);

		float deltaH=dy/times;
		float deltaz=signz*dz/times;
		times++;
        for(int i=0;i<times;i++)
		{
			vertCur.xpos=CurX;
			vertCur.zpos=CurZ;
			vertCur.ypos=CurLineHeight;

			if(vertCur.ypos<GetHeight(vertCur.xpos,vertCur.zpos) ) return true;

            CurLineHeight -= signy*deltaH;
			CurZ-=deltaz;
			CurX-=signx*step;
		}
	}
    return false;
}
bool CHeightmap::CheckTreeCollide(VERTEX viewPos,VERTEX objPos)
{

	float dy=viewPos.ypos-objPos.ypos;
	float dx=viewPos.xpos-objPos.xpos;
	float dz=viewPos.zpos-objPos.zpos;

	int signx,signy,signz;
	if(dx<0)
	{dx=-dx; signx=-1;}
	else
        signx=1;
	if(dy<0)
	{dy=-dy; signy=-1;}
	else
        signy=1;
	if(dz<0)
	{dz=-dz; signz=-1;}
	else
        signz=1;

    POINT point;
	int   type;
	float distance;

 	if(dz>dx)
	{
		float CurZ=float(int(viewPos.zpos)/40)*40;
    	if(viewPos.zpos<0)CurZ -=40;
	    float CurX=viewPos.xpos+(CurZ-viewPos.zpos)*(viewPos.xpos-objPos.xpos)/(viewPos.zpos-objPos.zpos);
	    float gridX;
		float deltax=signx*dx*40/dz;
		do
		{
			point=ConvertToPlantmap(CurX,CurZ);
			type=GetPlantType(point.x,point.y);
			if(type>64)
			{
				gridX=float(int(CurX)/40)*40;
				if(CurX<0)gridX-=40;
				distance=m_cMath.GetPointToLineDist2D(viewPos,objPos,
					                    VERTEX(gridX+m_pCoverBias[64*point.y+point.x].xbias,0,
										CurZ+m_pCoverBias[64*point.y+point.x].zbias));

                if(type==128 && distance<2)return true;
                if(type==192 && distance<1.2f)return true;
                if(type==255 && distance<1)return true;
			}
	    	CurX-=deltax;
		    CurZ-=signz*40;
			if(signz>0 )
			{
				if(CurZ<objPos.zpos)return false;
			}
			else
			{
				if(CurZ>objPos.zpos)return false;
			}

		}while(1);

	}
	else
	{
		float CurX=float(int(viewPos.xpos)/40)*40;
    	if(viewPos.xpos<0)CurX -=40;
	    float CurZ=viewPos.zpos+(CurX-viewPos.xpos)*(viewPos.zpos-objPos.zpos)/(viewPos.xpos-objPos.xpos);
	    float gridZ;

		float deltaz=signz*dz*40/dx;
		do
		{
			point=ConvertToPlantmap(CurX,CurZ);
			type=GetPlantType(point.x,point.y);
			if(type>64)
			{
				gridZ=float(int(CurZ)/40)*40;
				if(CurZ<0)gridZ-=40;
				distance=m_cMath.GetPointToLineDist2D(viewPos,objPos,
					                    VERTEX(CurX+m_pCoverBias[64*point.y+point.x].xbias,0,
										gridZ+m_pCoverBias[64*point.y+point.x].zbias));

				if(type==128 && distance<2)return true;
                if(type==192 && distance<1.2f)return true;
                if(type==255 && distance<1)return true;


			}
	    	CurZ-=deltaz;
		    CurX-=signx*40;
			if(signx>0 )
			{
				if(CurX<objPos.xpos)return false;
			}
			else
			{
				if(CurX>objPos.xpos)return false;
			}

		}while(1);
	}

    return false;
}
bool CHeightmap::CheckBuildingCollide(VERTEX startPos,VERTEX endPos)
{
	for(int i=0;i<m_numBuilding;i++)
	{
		if(m_cMath.IsLineSegmentCutBy3DBoundary(&startPos,&endPos,m_smallBndyBuilding[i]))
			return true;
	}

	return false;
}
bool CHeightmap::CollideTreeBody(VERTEX *check)
{
	POINT point=ConvertToMovemap(*check);
	int tx,tz;
	tx=m_pMovemap[point.y*256+point.x].xpos;
	tz=m_pMovemap[point.y*256+point.x].zpos;

	if(m_pCovermap[tz*16+tx/4]<65)return false;

	float treex,treez;
	treex=float(m_ViewOffsetX + (point.x-128)*40 + m_pCoverBias[tz*16+tx/4].xbias);
	treez=float(m_ViewOffsetZ + (point.y-128)*40 + m_pCoverBias[tz*16+tx/4].zbias);

	float deltaX=(treex>check->xpos)?(treex-check->xpos):(check->xpos-treex);
	float deltaZ=(treez>check->zpos)?(treez-check->zpos):(check->zpos-treez);
	if(deltaX<4 && deltaZ<4)
	{
		if(deltaX>deltaZ)
		{
			if(treex>check->xpos)check->xpos=treex-4;
			else check->xpos=treex+4;
		}
		else
		{
			if(treez>check->zpos)check->zpos=treez-4;
			else check->zpos=treez+4;
		}
		return true;
	}
	return false;
}
bool CHeightmap::CollideBuilding(VERTEX *oldPos,VERTEX *newPos)
{
	for(int i=0;i<m_numBuilding;i++)
	{
		if(IsInBoundary3D(newPos,m_bigBndyBuilding[i]))
		{
			VERTEX temp=VERTEX(newPos->xpos,newPos->ypos,newPos->zpos);

			newPos->zpos=oldPos->zpos;
			if(!IsInBoundary3D(newPos,m_bigBndyBuilding[i]))
                return true;
			newPos->zpos=temp.zpos;
			newPos->xpos=oldPos->xpos;
			if(!IsInBoundary3D(newPos,m_bigBndyBuilding[i]))
                return true;

			oldPos->zpos=oldPos->zpos;
			return true;
		}
	}
	return false;
}
bool CHeightmap::IsInFrustum(VERTEX *checked)
{
	POINT point=ConvertToMovemap(*checked);
	return m_cFrustumCull.IsInFrustum(point.x,point.y);
}
bool CHeightmap::IsInFrustum(float x,float z)
{
	POINT point=ConvertToMovemap(VERTEX(x,255,z));
	return m_cFrustumCull.IsInFrustum(point.x,point.y);
}
bool CHeightmap::IsInFrustum(BOUNDARY_3D *pBoundary)
{

	if(IsInFrustum(pBoundary->minx,pBoundary->minz))return true;
	if(IsInFrustum(pBoundary->maxx,pBoundary->minz))return true;
	if(IsInFrustum(pBoundary->maxx,pBoundary->maxz))return true;
	if(IsInFrustum(pBoundary->minx,pBoundary->maxz))return true;

	return false;
}

VERTEX CHeightmap::ConvertToWorld(int movemapXPos,int movemapZPos)
{
	VERTEX position;
	position.xpos=float(m_ViewOffsetX + (movemapXPos-128)*40);
	position.zpos=float(m_ViewOffsetZ + (movemapZPos-128)*40);

	POINT point ; //point in terrain map
	point.x=m_pMovemap[movemapZPos*256+movemapXPos].xpos;
	point.y=m_pMovemap[movemapZPos*256+movemapXPos].zpos;

	position.ypos=m_pTmap[256*point.y + point.x];

	return position;

}
POINT CHeightmap::ConvertToHeightmap(VERTEX *pos)
{
	POINT point;
	if(pos->xpos<0)
	    point.x=255+int(pos->xpos*0.1f)%256;
	else
		point.x=int(pos->xpos*0.1f)%256;
	if(pos->zpos<0)
	    point.y=255+int(pos->zpos*0.1f)%256;
	else 
		point.y=int(pos->zpos*0.1f)%256;

	return point;
}
POINT CHeightmap::ConvertToMovemap(VERTEX pos)
{
 	POINT point;
    if(pos.xpos < m_ViewOffsetX)
	    point.x=int((pos.xpos-m_ViewOffsetX)*0.025f)+127;
	else
	    point.x=int((pos.xpos-m_ViewOffsetX)*0.025f)+128;
	if(pos.zpos<m_ViewOffsetZ)
	    point.y=int((pos.zpos-m_ViewOffsetZ)*0.025f)+127;
	else
        point.y=int((pos.zpos-m_ViewOffsetZ)*0.025f)+128;

	if(point.x<0 || point.x>255 )
	{   
		POINT p;
	    p.x=p.y=0;
		return p;
	}
	if(point.y<0 || point.y>255 )
	{   
		POINT p;
	    p.x=p.y=0;
		return p;
	}
 
	return point;
}
POINT CHeightmap::ConvertToPlantmap(float worldX,float worldZ)
{
	POINT point;
	if(worldX<0)
	    point.x=63+int(worldX*0.025f)%64;
	else
		point.x=int(worldX*0.025f)%64;
	if(worldZ<0)
	    point.y=63+int(worldZ*0.025f)%64;
	else 
		point.y=int(worldZ*0.025f)%64;
    
    return point;
}
void CHeightmap::GetFocusPos()
{
    //////////////// calcau
	float depth[2];
    int xpos=CGameSetting::m_iScrWidth/2;
	int ypos=CGameSetting::m_iScrHeight/2;
	glReadPixels(xpos,ypos,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);

    GLdouble ModelMatrix[16], ProjMatrix[16];
    glGetDoublev(GL_MODELVIEW_MATRIX,  ModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, ProjMatrix);

    GLint    Viewport[4]={0,0,CGameSetting::m_iScrWidth,CGameSetting::m_iScrHeight};
    gluUnProject(xpos,ypos, depth[0], 
		         ModelMatrix, ProjMatrix, Viewport,
				 &m_focusPosX, &m_focusPosY, &m_focusPosZ);

	double dx=m_ViewPos.xpos-m_focusPosX;
	double dy=m_ViewPos.ypos-m_focusPosY;
	double dz=m_ViewPos.zpos-m_focusPosZ;

	m_distFromFocus= dx*dx+dy*dy+dz*dz;
}
bool CHeightmap::IsInBoundary3D(VERTEX *pos, BOUNDARY_3D *boundary)
{
	if(pos->xpos > boundary->maxx || pos->xpos < boundary->minx )return false;
	if(pos->ypos > boundary->maxy || pos->ypos < boundary->miny )return false;
	if(pos->zpos > boundary->maxz || pos->zpos < boundary->minz )return false;

	return true;
}
///////////////////////////////////////////////
//////////////////////////////////////////////
bool CHeightmap::ReadTerrainmapFile()
{
    m_pTmap=new unsigned char[256*256];
	if(m_pTmap==NULL)return false;


	FILE *fp;
	fp=fopen(CGameSetting::m_strHeightmap,"rb");
	if(!fp)return false;

	BITMAPFILEHEADER fileheader;
	fread(&fileheader,sizeof(BITMAPFILEHEADER),1,fp);
	if(fileheader.bfType!=19778)return false;

    fseek(fp,1078,SEEK_SET);
	for(int z=255;z>-1;z--)
		for(int x=0;x<256;x++)
		{
			fread(&m_pTmap[256*z+x],sizeof(unsigned char),1,fp);	
		}	

	fclose(fp);
    return true;
}
bool CHeightmap::ReadPlantmapFile()
{
    m_pCovermap =new unsigned char[64*64];
	m_pCoverBias=new GRID_BIAS[64*64];

	if(m_pCovermap==NULL)return false;
	if(m_pCoverBias==NULL)return false;
	
	FILE *fp;
	fp=fopen(CGameSetting::m_strPlantIndex,"rb");
	if(!fp)return false;

	BITMAPFILEHEADER fileheader;
	fread(&fileheader,sizeof(BITMAPFILEHEADER),1,fp);
	if(fileheader.bfType!=19778)return false;


    fseek(fp,1078,SEEK_SET);
	for(int z=63;z>-1;z--)
		for(int x=0;x<64;x++)
		{
			fread(&m_pCovermap[64*z+x],sizeof(unsigned char),1,fp);	
		}	
	fclose(fp);

	/////construct plant position
	for( z=0;z<64;z++)
		for(int x=0;x<64;x++)
		{
			m_pCoverBias[64*z+x].xbias=5+(rand()%30);
			m_pCoverBias[64*z+x].zbias=5+(rand()%30);
		}	
	/////////////////////////////
    return true;
}
int  CHeightmap::GetPosInMovemap(int x,int z)
{
    return m_pMovemap[(128+z)*256+128+x].zpos*256+m_pMovemap[(128+z)*256+128+x].xpos;
}
int CHeightmap::GetPlantType(int mapx,int mapz)
{
    return m_pCovermap[mapz*64+mapx];
}
void CHeightmap::MakeModulePath(char filename[], char sINIPath[])
{
	// Add the path of the executable to the passed INI filename		
	// Buffer to hold the filename
	char sModuleFileName[MAX_PATH];
	// Pass NULL to get the handle of the current module
	HMODULE hModule = GetModuleHandle(NULL);
	// Fill the path into sModuleFileName and get the number of returned chars
	int iNumChars = GetModuleFileName(hModule, sModuleFileName, MAX_PATH);

	// If the path was received
	if (iNumChars)
	{
		// Loop from the last to the first char
		for (int iCurChar=iNumChars-1; iCurChar>=0; iCurChar--)
		{
			// If the current char is a backslash
			if (sModuleFileName[iCurChar] == char('\\'))
			{
				// Terminate the the string behind the backslash and
				sModuleFileName[iCurChar+1] = char('\0');
				break;
			}
		}
		// Append INI filename at the end of the path
		strcat(sModuleFileName, filename);
		// Copy the full path into the destibation
		strcpy(sINIPath, sModuleFileName);
	}
}