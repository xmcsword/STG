// CheckBox.h: interface for the CCheckBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHECKBOX_H__4C097261_A10D_11D2_814E_5254AB37CDC9__INCLUDED_)
#define AFX_CHECKBOX_H__4C097261_A10D_11D2_814E_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphbutton.h"

class CCheckBox  : public CGraphButton
{
public:
	CCheckBox();
	virtual ~CCheckBox();
    
	void SetCheckBox(RECT rect,bool bState=true);
	void SetState(bool bState);
    void SetEnable(bool bEnable);
    void RenderCheckBox();
	
	bool m_bChecked;
	bool m_bValueChanged;
private:
	void UpdateCheckBox();
    bool m_bEnable;
};

#endif // !defined(AFX_CHECKBOX_H__4C097261_A10D_11D2_814E_5254AB37CDC9__INCLUDED_)
