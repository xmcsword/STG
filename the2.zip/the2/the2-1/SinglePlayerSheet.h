// SinglePlayerSheet.h: interface for the CSinglePlayerSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SINGLEPLAYERSHEET_H__902ED7E1_A628_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_SINGLEPLAYERSHEET_H__902ED7E1_A628_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "changeBar.h"
#include "ViewBox.h"
#include "listbox.h"
#define  SP_ITEM_NUM  3
#define  PLAYER_NAME  4

class CSinglePlayerSheet  
{
public:
	CSinglePlayerSheet();
	virtual ~CSinglePlayerSheet();

	bool InitSheet();
	int  RenderSheet();
    void SavePlayerInfo();
	int    m_iSelect;
	bool   m_bActive;
private:
	void   UpdateSinglePlayer();
	void   DrawBackGround();
	void   DrawRectangle(int x0,int x1,int y0,int y1);

	CGraphButton  m_cButton[SP_ITEM_NUM];
	CGraphButton  m_cModifyButton;
	CGraphButton  m_cDeleteButton;
	CChangeBar    m_cHero;
    CViewBox      m_cScript;

	CListBox      m_cPlayerList;

};

#endif // !defined(AFX_SINGLEPLAYERSHEET_H__902ED7E1_A628_11D6_814C_5254AB37CDC9__INCLUDED_)
