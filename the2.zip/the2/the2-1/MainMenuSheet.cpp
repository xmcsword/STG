// MainMennSheet.cpp: implementation of the CMainMenuSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MainMenuSheet.h"
#include "imgtext.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMainMenuSheet::CMainMenuSheet()
{
}
CMainMenuSheet::~CMainMenuSheet()
{
}
bool CMainMenuSheet::InitSheet()
{
	RECT rect;
	rect.left=280;
	rect.right=520;
	for(int i=0;i<ITEM_NUM;i++)
	{
		rect.top=150+67*i;
		rect.bottom=180+67*i;
	    m_cButton[i].SetButtonRect(rect);
	}
   	m_cButton[0].SetButtonText("Single Player");
   	m_cButton[1].SetButtonText("Multi Player");
   	m_cButton[2].SetButtonText("Game Setting");
   	m_cButton[3].SetButtonText("Credit");
   	m_cButton[4].SetButtonText("Exit to Window");

	m_cButton[1].SetButtonState(BUTTON_DEAD);

    m_bActive=false;
	m_iSelect=-1;
	return true;
}
int CMainMenuSheet::RenderSheet()
{
	if(!m_bActive)return -1;
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		m_iSelect=4;
		return 0;
	}
	if(CInput::m_keys[13]) // key enter pressed
	{
		CInput::m_keys[13]=false;
		m_iSelect=0;
		return 0;
	}
	for(int i=0;i<ITEM_NUM;i++)
	{
	    m_cButton[i].RenderButton();
	}
	for(i=0;i<ITEM_NUM;i++)
	{
	    if(m_cButton[i].m_bSelected)
		{
			m_cButton[i].m_bSelected=false;
			m_iSelect=i;
			return i;
		}
	}
	glColor3f(0.5f,0.5f,0.5f);
	CImgText::PrintString(10,10,"Base on 3dExplorer Engine (new) !");  
	CImgText::PrintString(670,560,"Version 1.0");  
	CImgText::PrintString(670,580,"2002.8");  
	return -1;
}