// SpriteManager.cpp: implementation of the CSpriteManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SpriteManager.h"
#include "texmanager.h"
#include "gamesetting.h"
#include "input.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSpriteManager::CSpriteManager()
{
	m_numSoldier=0;
	m_cSprite=NULL;

	m_bFreeze=false;
    m_bNoVisible=false;
	m_bNoHarm=false;

}
CSpriteManager::~CSpriteManager()
{
	if(m_cSprite!=NULL)
	{
		delete [] m_cSprite;
		m_cSprite=NULL;

	}
}
bool CSpriteManager::InitSpriteManager()
{
	CTexManager cTex;
	//////// model
	if(!m_cSoldier.InitSMFLoader("model/soldier/soldier.smf",cTex.GetTextureID(TEX_SOILDER),1))
	{
	    MessageBox(0, "loader soilder error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
    }
	if(!m_cWeapon.InitSMFLoader("model/soldier/weapon.smf",cTex.GetTextureID(TEX_WEAPON),1))
	{
	    MessageBox(0, "loader weapon error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
    }

	m_numSoldier=m_cHmap.m_numSoldier;
	m_cSprite=new CSprite [m_numSoldier];
	for(int i=0;i<m_numSoldier;i++)
	{
	    m_cSprite[i].InitSprite(i,m_cHmap.m_soldierPos[i],m_cHmap.m_soldierRot[i], &m_cSoldier,&m_cWeapon);
	}
	return true;
}
void  CSpriteManager::RenderSprites()
{
    UpdateSpriteManager();

	unsigned char oldColor[4];
	unsigned char color[4];
	int scrX=CGameSetting::m_iScrWidth/2;
	int scrY=CGameSetting::m_iScrHeight/2;

	glReadPixels(scrX,scrY,1,1,GL_RGB,GL_UNSIGNED_BYTE,oldColor);

	m_cHmap.m_focusState=FOCUS_GROUND;

	int dieID=-1;
	for(int i=0;i<m_numSoldier;i++)
	{
    	m_cSprite[i].RenderSprite(m_bNoHarm);
		if(dieID == -1 && m_cHmap.m_bAttack)
		{
	        glReadPixels(scrX,scrY,1,1,GL_RGB,GL_UNSIGNED_BYTE,color);
		    if(oldColor[0]!=color[0]|| oldColor[1]!=color[1] || oldColor[2]!=color[2] )
			{
			    m_cHmap.m_focusState=FOCUS_BODY;
			    dieID=i;
                m_cSprite[i].Injure();  
			}
		}
		m_cSprite[i].UpdateSprite(m_bFreeze,m_bNoVisible);
	}

	m_cHmap.GetFocusPos();

}
void CSpriteManager::UpdateSpriteManager()
{
	for(int i=0;i<m_numSoldier;i++)
	{
    	m_cHmap.m_soldierRot[i]=m_cSprite[i].m_Camera.m_CamRotY;
		m_cHmap.m_soldierHealth[i]=m_cSprite[i].m_Health;
	}

	if(CInput::m_keys['F'])
	{
		CInput::m_keys['F']=false;
	    m_bFreeze=!m_bFreeze;
	}
	if(CInput::m_keys['V'])
	{
		CInput::m_keys['V']=false;
	    m_bNoVisible=!m_bNoVisible;
	}
	if(CInput::m_keys['N'])
	{
		CInput::m_keys['N']=false;
	    m_bNoHarm=!m_bNoHarm;
	}

}
void  CSpriteManager::ResetAllSprite()
{
	for(int i=0;i<m_numSoldier;i++)
	{
	    m_cSprite[i].ResetSpriteState();
	}
}
bool CSpriteManager::IsAllDeath()
{
	for(int i=0;i<m_numSoldier;i++)
	{
    	if(m_cSprite[i].m_Health>0)return false;
	}
	return true;
}








