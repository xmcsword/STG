// Grass.cpp: implementation of the CGrass class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Grass.h"
#include "Texmanager.h"
#include "math.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGrass::CGrass()
{
	m_size=8.0f;
    m_height=m_size*0.8f;
}

CGrass::~CGrass()
{

}
bool CGrass::InitGrass(int type)
{
	 m_type=type;
	 CTexManager cTexManager;
	 //////////////read blend skin texture
	 if(type==1)
		 texGrass=cTexManager.GetTextureID(TEX_GRASS_0);
	 else
		 texGrass=cTexManager.GetTextureID(TEX_GRASS_1);

     return true;
}
void CGrass::RenderGrass(VERTEX pos)
{
    glPushMatrix();	
	glTranslatef(pos.xpos,pos.ypos,pos.zpos);

   	glAlphaFunc(GL_GREATER,0.10f);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
    glEnable(GL_ALPHA_TEST);
	glDisable(GL_CULL_FACE);
	////////////////////////////////////
	if(m_type==1)
        DrawGrassStrip();
	else
		DrawGrassStar();
   ///////////////////////////////////////////
    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND); 

    glPopMatrix();
}
void CGrass::DrawGrassStrip()
{
    //////////////////////////////////////////

 	glBindTexture(GL_TEXTURE_2D, texGrass);
	glEnable(GL_TEXTURE_2D);
    ///////////////////////////////////////////
	glBegin(GL_QUAD_STRIP);

	    glTexCoord2f(1,0);
	    glVertex3f(m_size*0.3f,0,-m_size*0.5f);
	    glTexCoord2f(1,1);
	    glVertex3f(m_size*0.3f,m_height*1.4f,-m_size*0.5f);

	    glTexCoord2f(0,0);
	    glVertex3f(0,0,0);
	    glTexCoord2f(0,1);
	    glVertex3f(0,m_height*1.5f,0);

	    glTexCoord2f(1,0);
	    glVertex3f(m_size,0,0);
	    glTexCoord2f(1,1);
	    glVertex3f(m_size,m_height*1.5f,0);

	    glTexCoord2f(0,0);
	    glVertex3f(m_size*1.1f,0,-m_size*0.4f);
	    glTexCoord2f(0,1);
	    glVertex3f(m_size*1.1f,m_height*1.3f,-m_size*0.4f);

	    glTexCoord2f(1,0);
	    glVertex3f(m_size*0.2f,0,-m_size*1.2f);
	    glTexCoord2f(1,1);
	    glVertex3f(m_size*0.2f,m_height*1.3f,-m_size*1.2f);

	    glTexCoord2f(0,0);
	    glVertex3f(-m_size*0.3f,0,-m_size*0.6f);
	    glTexCoord2f(0,1);
	    glVertex3f(-m_size*0.3f,m_height*1.2f,-m_size*0.6f);
    
	    glTexCoord2f(1,0);
	    glVertex3f(-m_size*0.2f,0,m_size*0.2f);
	    glTexCoord2f(1,1);
	    glVertex3f(-m_size*0.2f,m_height*1.2f,m_size*0.2f);

	    glTexCoord2f(0,0);
	    glVertex3f(m_size*0.9f,0,m_size*0.4f);
	    glTexCoord2f(0,1);
	    glVertex3f(m_size*0.9f,m_height*1.2f,m_size*0.4f);

	    glTexCoord2f(1,0);
	    glVertex3f(m_size*1.5f,0,-m_size*0.1f);
	    glTexCoord2f(1,1);
	    glVertex3f(m_size*1.5f,m_height*1.3f,-m_size*0.1f);

	    glTexCoord2f(0,0);
	    glVertex3f(m_size*1.2f,0,-m_size*1.0f);
	    glTexCoord2f(0,1);
	    glVertex3f(m_size*1.2f,m_height*1.1f,-m_size*1.0f);

	    glTexCoord2f(1,0);
	    glVertex3f(m_size*0.1f,0,-m_size*1.1f);
	    glTexCoord2f(1,1);
	    glVertex3f(m_size*0.1f,m_height*1.4f,-m_size*1.1f);

	glEnd();

}
void CGrass::DrawGrassStar()
{
 	glBindTexture(GL_TEXTURE_2D, texGrass);
	DrawCross(60);
}
void CGrass::DrawCross(int angle)
{
	int num=180/angle;

	glBegin(GL_QUADS);
	int curAngle=0;
	for(int i=0;i<num;i++)
	{
		curAngle=angle*i;

	    glTexCoord2f(0,0);
	    glVertex3f(m_size*cosf(0.0174533f*curAngle),0,m_size*sinf(0.0174533f*curAngle));	   
		
		glTexCoord2f(1,0);
	    glVertex3f(m_size*cosf(0.0174533f*(curAngle+180)),0,m_size*sinf(0.0174533f*(curAngle+180)));	   

  	    glTexCoord2f(1,1);
	    glVertex3f(m_size*cosf(0.0174533f*(curAngle+180)),m_height,m_size*sinf(0.0174533f*(curAngle+180)));	   
	
		glTexCoord2f(0,1);
	    glVertex3f(m_size*cosf(0.0174533f*curAngle),m_height,m_size*sinf(0.0174533f*curAngle));	   
	}
    glEnd();
}








