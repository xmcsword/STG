// AudioManager.h: interface for the CAudioManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUDIOMANAGER_H__F503EB61_B02D_11D6_815D_5254AB37CDC9__INCLUDED_)
#define AFX_AUDIOMANAGER_H__F503EB61_B02D_11D6_815D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Audio.h"

class CAudioManager  
{
public:
	CAudioManager();
	virtual ~CAudioManager();
	void          InitCheck();
	bool          CreateMenuResource();
	bool          CreateMissionResource();
	void          DeleteMenuResource();
	void          DeleteMissionResource();
};

#endif // !defined(AFX_AUDIOMANAGER_H__F503EB61_B02D_11D6_815D_5254AB37CDC9__INCLUDED_)
