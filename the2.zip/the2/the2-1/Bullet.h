// Bullet.h: interface for the CBullet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BULLET_H__BF8648A1_3F5F_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_BULLET_H__BF8648A1_3F5F_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "heightmap.h"
#include "particle.h"
class CBullet  
{
public:
	CBullet();
	virtual ~CBullet();
	int      m_bulletType;
	float    m_Speed;
	VERTEX   m_oldPos;
	VERTEX   m_CurPos;

	NORMAL   m_direction;
	float    m_rotX,m_rotY,m_rotZ;
	float    m_life;

	bool     InitBullet(VERTEX  startPos,float rotx,float roty ,NORMAL direction,unsigned int *texResource ,int type=1);
	bool     InitBullet(VERTEX  startPos,float rotx,float roty,unsigned int *texResource,int type=1);

    void     UpdateBullet();
	   
private:
	
	void     DrawM16Bullet();   
	void     DrawRifleBullet();
	void     DrawRocketBullet();
	void     DrawGunFire();
    void     DrawExplosion();
	CHeightmap   m_cHmap; 
	CParticle    m_rocket;
	CParticle    m_gunShot;
	CParticle    m_explosion;

    unsigned int  *m_pTexResource; 

};

#endif // !defined(AFX_BULLET_H__BF8648A1_3F5F_11D6_812C_5254AB37CDC9__INCLUDED_)
