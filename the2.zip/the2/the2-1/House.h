// House.h: interface for the CHouse class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOUSE_H__E6E520A1_6369_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_HOUSE_H__E6E520A1_6369_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ms3dLoader.h"
#include "smokeParticle.h"
#include "cmath.h"
#include "heightmap.h"
class CHouse  
{
public:
	CHouse();
	virtual ~CHouse();

	bool InitHouse(CMs3dLoader *pModel,CSmokeParticle *pSmoke,
		           VERTEX position,float rotateY,unsigned int texid,bool bSmoking);
	void DrawHouse();
	void DrawSmoke();
    void SetSmoking(bool bSomking);
	BOUNDARY_3D      m_bigBoundary;
	BOUNDARY_3D      m_smallBoundary;
private:
	CMs3dLoader     *m_pModel;
	CSmokeParticle  *m_pSmoke;
	CHeightmap       m_cHmap;
	VERTEX           m_position;
	VERTEX           m_somkePos;
	float            m_roty;
    CMath            m_cMath;

	VERTEX           m_chimneyPos;
	unsigned int     m_texID;
	bool             m_bSomking;

};

#endif // !defined(AFX_HOUSE_H__E6E520A1_6369_11D6_812C_5254AB37CDC9__INCLUDED_)
