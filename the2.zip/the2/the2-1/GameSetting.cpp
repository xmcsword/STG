// GameSetting.cpp: implementation of the CGameSetting class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameSetting.h"

////////// Resolution
int   CGameSetting::m_iScrWidth  = 800;
int   CGameSetting::m_iScrHeight = 600;
int   CGameSetting::m_iColorDepth= 16;
////////// Render
int   CGameSetting::m_iGamma = 70;
int   CGameSetting::m_iModelDetail=MEDIUM;
int   CGameSetting::m_iTexQuality=MEDIUM;
int   CGameSetting::m_iVisibleDist=50;
int   CGameSetting::m_iForestDensity=LOW;
int   CGameSetting::m_iFogDensity=45;
////////// Audio
bool  CGameSetting::m_bAudioEnable = 1;
bool  CGameSetting::m_bSound = 1;
bool  CGameSetting::m_bMusic = 1;
int   CGameSetting::m_iSoundVolume = 60;
int   CGameSetting::m_iMusicVolume = 60;

////////// Control
//mouse 
int   CGameSetting::m_iKeyFire = 0;
int   CGameSetting::m_iKeyZoom = 1;
//keyboard
int   CGameSetting::m_iKeyHelp     = VK_F1;
int   CGameSetting::m_iKeyJump     = VK_SPACE;
int   CGameSetting::m_iKeyForward  = VK_UP;
int   CGameSetting::m_iKeyBackward = VK_DOWN;
int   CGameSetting::m_iKeyLeft     = VK_LEFT;
int   CGameSetting::m_iKeyRight    = VK_RIGHT;
int   CGameSetting::m_iKeyDrawFPS  = VK_F2;
int   CGameSetting::m_iKeyMute     = 'M';

//////////// Mouse
bool  CGameSetting::m_bMouseInvert=false;
int   CGameSetting::m_iMouseSens=60;

////////// Game Activate
int   CGameSetting::m_iGameState=GAME_MAIN_MENU;

/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
/////////// Mission 
int   CGameSetting::m_iMissionSelect=0;
///sky
char *CGameSetting::m_strSkyDir =NULL;
bool  CGameSetting::m_bLensFlare =true;
///plants
char *CGameSetting::m_strPlantsDir =NULL;
char *CGameSetting::m_strPlantIndex=NULL;
///Viewer
float CGameSetting::m_fViewerPosX=0;
float CGameSetting::m_fViewerPosZ=0;
float CGameSetting::m_fViewerRotY=0;
char *CGameSetting::m_strViewerWeapon=NULL;;
char *CGameSetting::m_strViewerWeaponSkin=NULL;
///Terrain
int   CGameSetting::m_iTextureType=0;
char *CGameSetting::m_strHeightmap=NULL;
char *CGameSetting::m_strTerrainSkinDir=NULL;
char *CGameSetting::m_strTextureIndex=NULL;
char *CGameSetting::m_strLODmap=NULL;
//////////////////////////////////////////////
int   CGameSetting::m_numUser=0;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CGameSetting::CGameSetting()
{
	if(m_numUser==0)
	{
		////sky
        m_strSkyDir = new char [STRING_LENGTH];
		///plants
		m_strPlantsDir = new char [STRING_LENGTH];
        m_strPlantIndex     = new char [STRING_LENGTH];
        ///Viewer
        m_strViewerWeapon     = new char [STRING_LENGTH];
        m_strViewerWeaponSkin = new char [STRING_LENGTH];
        ///Terrain
        m_strHeightmap      = new char [STRING_LENGTH];
        m_strTerrainSkinDir = new char [STRING_LENGTH];
        m_strTextureIndex   = new char [STRING_LENGTH];
        m_strLODmap         = new char [STRING_LENGTH];
	}
	m_numUser++;
}
CGameSetting::~CGameSetting()
{
	m_numUser--;
	if(m_numUser==0)
	{
		////sky
        if(m_strSkyDir !=NULL)delete [] m_strSkyDir ;
		////plants
        if(m_strPlantsDir !=NULL)delete [] m_strPlantsDir ;
        if(m_strPlantIndex     !=NULL)delete [] m_strPlantIndex ;
        ///Viewer

        if(m_strViewerWeapon     !=NULL)delete [] m_strViewerWeapon ;
        if(m_strViewerWeaponSkin !=NULL)delete [] m_strViewerWeaponSkin ;
        ///Terrain

        if(m_strHeightmap      !=NULL)delete [] m_strHeightmap ;
        if(m_strTerrainSkinDir !=NULL)delete [] m_strTerrainSkinDir ;
        if(m_strTextureIndex   !=NULL)delete [] m_strTextureIndex ;
        if(m_strLODmap         !=NULL)delete [] m_strLODmap ;
	}
}
///////////////////////////////////////////////////////
void CGameSetting::LoadDefaultSetting()
{
    ReadSettingFromFile("default.ini");
}
void CGameSetting::LoadSetting()
{
    ReadSettingFromFile("config.ini");
}

///////////////////////////////////////////////////////
void CGameSetting::ReadSettingFromFile(char filename[])
{
	// Convert the INI filename into a full pathname
	char sINIPath[MAX_PATH];
	MakeModulePath(filename, sINIPath);

	////////// Resolution
	m_iScrWidth      = GetPrivateProfileInt("Resolution", "ScrWidth", 800, sINIPath);
	m_iScrHeight     = GetPrivateProfileInt("Resolution", "ScrHeight",600, sINIPath);
    m_iColorDepth    = GetPrivateProfileInt("Resolution", "ColorDepth",16, sINIPath);
	////////// Render
    m_iGamma         = GetPrivateProfileInt("Render", "Gamma",70,sINIPath);
    m_iModelDetail   = GetPrivateProfileInt("Render", "ModelDetail",MEDIUM,sINIPath);
    m_iTexQuality    = GetPrivateProfileInt("Render", "TexQuality",MEDIUM,sINIPath);
    m_iVisibleDist   = GetPrivateProfileInt("Render", "VisibleDist",50,sINIPath);
    m_iForestDensity = GetPrivateProfileInt("Render", "ForestDensity",LOW,sINIPath);
    m_iFogDensity    = GetPrivateProfileInt("Render", "FogDensity",45,sINIPath);
	////////// Audio
	int temp;
	temp             = GetPrivateProfileInt("Audio", "Sound",      1, sINIPath);
	if(temp==0)      m_bSound= false;
	else             m_bSound= true;
    temp             = GetPrivateProfileInt("Audio", "Music",      1, sINIPath);
	if(temp==0)      m_bMusic= false;
	else             m_bMusic= true;
	m_iSoundVolume   = GetPrivateProfileInt("Audio", "SoundVolume",60,sINIPath);
	m_iMusicVolume   = GetPrivateProfileInt("Audio", "MusicVolume",60,sINIPath);

	////////// Control
    //mouse 
    m_iKeyFire       = GetPrivateProfileInt("Control", "Fire",0,sINIPath);
    m_iKeyZoom       = GetPrivateProfileInt("Control", "Zoom",1,sINIPath);
    //keyboard
    m_iKeyHelp       = GetPrivateProfileInt("Control", "Help",    VK_F1,   sINIPath);
    m_iKeyJump       = GetPrivateProfileInt("Control", "Jump",    VK_SPACE,sINIPath);
    m_iKeyForward    = GetPrivateProfileInt("Control", "Forward", VK_UP,   sINIPath);
    m_iKeyBackward   = GetPrivateProfileInt("Control", "Backward",VK_DOWN, sINIPath);
    m_iKeyLeft       = GetPrivateProfileInt("Control", "Left",    VK_LEFT, sINIPath);
    m_iKeyRight      = GetPrivateProfileInt("Control", "Right",   VK_RIGHT,sINIPath);
    m_iKeyDrawFPS    = GetPrivateProfileInt("Control", "DrawFPS", VK_F2,   sINIPath);
    m_iKeyMute       = GetPrivateProfileInt("Control", "Mute",    'M',     sINIPath);

	////////// Mouse
	temp             = GetPrivateProfileInt("Mouse", "MouseInvert",0,sINIPath);
	if(temp==0)      m_bMouseInvert= false;
	else             m_bMouseInvert= true;
    m_iMouseSens     = GetPrivateProfileInt("Mouse", "MouseSens",60,sINIPath);
	//////////////// Safe Check Parameters/////////
    SafeCheck();

}
///////////////////////////////////////////////////////
void CGameSetting::SaveSetting()
{
	// Convert the INI filename into a full pathname
	char sINIPath[MAX_PATH];
	MakeModulePath("config.ini", sINIPath);

	//////////////// Safe Check Parameters/////////
    SafeCheck();

	////////// Resolution
	SaveSettingItem("Resolution", "ScrWidth", m_iScrWidth ,   sINIPath);
	SaveSettingItem("Resolution", "ScrHeight",m_iScrHeight,   sINIPath);
	SaveSettingItem("Resolution", "ColorDepth",m_iColorDepth, sINIPath);

	////////// Render
    SaveSettingItem("Render", "Gamma",         m_iGamma,        sINIPath);
    SaveSettingItem("Render", "ModelDetail",   m_iModelDetail,  sINIPath);
    SaveSettingItem("Render", "TexQuality",    m_iTexQuality,   sINIPath);
    SaveSettingItem("Render", "VisibleDist",   m_iVisibleDist,  sINIPath);
    SaveSettingItem("Render", "ForestDensity", m_iForestDensity,sINIPath);
    SaveSettingItem("Render", "FogDensity",    m_iFogDensity,   sINIPath);

	////////// Audio
	SaveSettingItem("Audio", "Sound",      (int)m_bSound    ,   sINIPath);
	SaveSettingItem("Audio", "Music",      (int)m_bMusic   ,    sINIPath);
	SaveSettingItem("Audio", "SoundVolume",m_iSoundVolume,      sINIPath);
	SaveSettingItem("Audio", "MusicVolume",m_iMusicVolume,      sINIPath);

	////////// Control
    //mouse 
    SaveSettingItem("Control", "Fire",m_iKeyFire,sINIPath);
    SaveSettingItem("Control", "Zoom",m_iKeyZoom,sINIPath);
    //keyboard
    SaveSettingItem("Control", "Help",    m_iKeyHelp ,   sINIPath);
    SaveSettingItem("Control", "Jump",    m_iKeyJump  ,  sINIPath);
    SaveSettingItem("Control", "Forward", m_iKeyForward ,sINIPath);
    SaveSettingItem("Control", "Backward",m_iKeyBackward,sINIPath);
    SaveSettingItem("Control", "Left",    m_iKeyLeft ,   sINIPath);
    SaveSettingItem("Control", "Right",   m_iKeyRight ,  sINIPath);
    SaveSettingItem("Control", "DrawFPS", m_iKeyDrawFPS ,sINIPath);
    SaveSettingItem("Control", "Mute",    m_iKeyMute ,   sINIPath);

	///////// Mouse 
    SaveSettingItem("Mouse", "MouseInvert",(int)m_bMouseInvert ,sINIPath);
    SaveSettingItem("Mouse", "MouseSens",  m_iMouseSens ,       sINIPath);

	///////////////////////

}
void CGameSetting::SaveSettingItem(char SectionName[],char KeyName[],
								   int KeyValue,char sINIPath[])
{
	char strValue[16];
	wsprintf(strValue,"%d",KeyValue);
    WritePrivateProfileString(SectionName, KeyName, strValue, sINIPath);
}
void CGameSetting::SafeCheck()
{
	////////// Check Resolution 
	switch(m_iScrWidth)
	{
	case 640:
		m_iScrHeight=480;
		break;
	case 800:
		m_iScrHeight=600;
		break;
	case 1024:
		m_iScrHeight=768;
		break;
	case 1280:
		m_iScrHeight=960;
		break;
	default:
		m_iScrWidth=800;
        m_iScrHeight=600;
		break;
	}
	//Check color depth
	if(m_iColorDepth!=16 && m_iColorDepth!=32 ) m_iColorDepth=16;

}

void CGameSetting::LoadMissionConfig()
{
	// Convert the INI filename into a full pathname
	char missionName[64];
	char sINIPath[MAX_PATH];
	wsprintf(missionName,"mission/mission%d.ini",m_iMissionSelect);
	MakeModulePath(missionName, sINIPath);

    ///sky
	GetPrivateProfileString("Sky","SkyDir","sky/",m_strSkyDir,STRING_LENGTH,sINIPath);
 	int temp;
	temp  = GetPrivateProfileInt("Sky", "LensFlare", 1, sINIPath);
	if(temp==1)m_bLensFlare=true;
	else m_bLensFlare=false;
	///plants
	GetPrivateProfileString("Plants","PlantsDir","Plants/summer/",m_strPlantsDir,STRING_LENGTH,sINIPath);
	GetPrivateProfileString("Plants","PlantIndex",    "plants/plantmap.bmp",m_strPlantIndex,STRING_LENGTH,sINIPath);
    ///Viewer
	m_fViewerPosX = (float)GetPrivateProfileInt("3dExplorer", "XPos", 800, sINIPath);
	m_fViewerPosZ = (float)GetPrivateProfileInt("3dExplorer", "ZPos", 800, sINIPath);
	m_fViewerRotY = (float)GetPrivateProfileInt("3dExplorer", "YRot", 0,   sINIPath);
	GetPrivateProfileString("3dExplorer","Weapon",    "model/mygun.md2",m_strViewerWeapon,STRING_LENGTH,sINIPath);
	GetPrivateProfileString("3dExplorer","WeaponSkin","model/mygun.bmp",m_strViewerWeaponSkin,STRING_LENGTH,sINIPath);
    ///Terrain
    m_iTextureType = GetPrivateProfileInt("Terrain",   "TextureType", 0, sINIPath);
	GetPrivateProfileString("Terrain","Heightmap",     "terrains/ter256.bmp",  m_strHeightmap,STRING_LENGTH,sINIPath);
	GetPrivateProfileString("Terrain","TerrainSkinDir","terrains/terrainSkin/",m_strTerrainSkinDir,STRING_LENGTH,sINIPath);
	GetPrivateProfileString("Terrain","TextureIndex",  "terrains/64_index.BMP",m_strTextureIndex,STRING_LENGTH,sINIPath);
    if( m_iModelDetail== LOW)   wsprintf(m_strLODmap,"Terrains/lodmap0.lod");
    if( m_iModelDetail== MEDIUM)wsprintf(m_strLODmap,"Terrains/lodmap0.lod");
    if( m_iModelDetail== HEIGHT)wsprintf(m_strLODmap,"Terrains/lodmap0.lod");

}
void CGameSetting::SaveMissionConfig()
{

}
///////////////////////////////////////////////////////
void CGameSetting::MakeModulePath(char filename[], char sINIPath[])
{
	// Add the path of the executable to the passed INI filename		
	// Buffer to hold the filename
	char sModuleFileName[MAX_PATH];
	// Pass NULL to get the handle of the current module
	HMODULE hModule = GetModuleHandle(NULL);
	// Fill the path into sModuleFileName and get the number of returned chars
	int iNumChars = GetModuleFileName(hModule, sModuleFileName, MAX_PATH);

	// If the path was received
	if (iNumChars)
	{
		// Loop from the last to the first char
		for (int iCurChar=iNumChars-1; iCurChar>=0; iCurChar--)
		{
			// If the current char is a backslash
			if (sModuleFileName[iCurChar] == char('\\'))
			{
				// Terminate the the string behind the backslash and
				sModuleFileName[iCurChar+1] = char('\0');
				break;
			}
		}
		// Append INI filename at the end of the path
		strcat(sModuleFileName, filename);
		// Copy the full path into the destibation
		strcpy(sINIPath, sModuleFileName);
	}
}