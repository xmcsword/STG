// FrustumCull.cpp: implementation of the CFrustumCull class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FrustumCull.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CFrustumCull::CFrustumCull()
{  
	m_HalfFOV=40;
	m_ViewerRotate=0;
	m_ViewDistance=50;

	for(int i=0;i<5;i++)
	{
		m_pos[i].x=m_pos[i].y=0;
	}
	m_upPos=m_downPos=0;
	
	for( i=0;i<256;i++)
	{
		m_LeftArray[i]=0;
		m_RightArray[i]=0;
	}

}
void CFrustumCull::InitFrustumCull(int halfFOV,int distance)
{
	m_HalfFOV=halfFOV;
	m_ViewDistance=distance;
	if(m_ViewDistance>125)m_ViewDistance=125;
}
CFrustumCull::~CFrustumCull()
{
}
void CFrustumCull::UpdateFrustumCull()
{
	///////////////get view back,left and right
    m_pos[0].x =128-int(4*sinf((m_ViewerRotate+150)*0.01745329f));
    m_pos[0].y =128-int(4*cosf((m_ViewerRotate+150)*0.01745329f));

    m_pos[1].x =128-int(4*sinf((m_ViewerRotate-150)*0.01745329f));
    m_pos[1].y =128-int(4*cosf((m_ViewerRotate-150)*0.01745329f));

    m_pos[3].x =128-int(m_ViewDistance*sinf(m_ViewerRotate*0.01745329f));
	m_pos[3].y =128-int(m_ViewDistance*cosf(m_ViewerRotate*0.01745329f));

    m_pos[4].x =128-int(m_ViewDistance*sinf((m_ViewerRotate+m_HalfFOV)*0.01745329f));
    m_pos[4].y =128-int(m_ViewDistance*cosf((m_ViewerRotate+m_HalfFOV)*0.01745329f));

    m_pos[2].x =128-int(m_ViewDistance*sinf((m_ViewerRotate-m_HalfFOV)*0.01745329f));
    m_pos[2].y =128-int(m_ViewDistance*cosf((m_ViewerRotate-m_HalfFOV)*0.01745329f));
    ////////////////////////////////////////////////////////////////
	////////////////get up and down point 

	m_upPos=m_downPos=0;
	int minx=0,maxx=0;
	for(int i=1;i<5;i++)
	{
		if( m_pos[i].y > m_pos[m_downPos].y ) m_downPos=i; 
		if( m_pos[i].y < m_pos[m_upPos].y   ) m_upPos  =i; 

		if( m_pos[i].x > m_pos[maxx].x ) maxx=i; 
		if( m_pos[i].x < m_pos[minx].x ) minx=i; 
	}

	/////////////////Fill  array//////////////////////////////
	int num=0;
	int cur=m_upPos;
	int next;
	/////////////////left array/////////////////////
	do{
		next=cur+1;
        if(next==5)next=0;
		FillArray(m_pos[cur].x,m_pos[cur].y,m_pos[next].x,m_pos[next].y,
			      m_LeftArray,true);

		cur++;
		if(cur==5)cur=0;
		num++;
	}while(cur!=m_downPos && num<5);
	/////////////////right array////////////////////
	num=0;
	cur=m_downPos;
	do{
		next=cur+1;
        if(next==5)next=0;
		FillArray(m_pos[cur].x,m_pos[cur].y,m_pos[next].x,m_pos[next].y,
			      m_RightArray,false);

		cur++;
		if(cur==5)cur=0;
		num++;
	}while(cur!=m_upPos && num<5);


}
void CFrustumCull::FillArray(int startx,int startz,int endx,int endz, 
							 unsigned char *pArray,bool bLeft)
{
    if(startz==endz)
	{
		int max,min;
        max=(startx>=endx)?startx:endx;
		min=(startx<=endx)?startx:endx;
		if(bLeft)
			pArray[startz]=min;
		else
			pArray[startz]=max;

		return;
	}
    ///////////////////////////////////////////////////////
    if(startz>endz)
	{
		int temp;
		temp=startz;
		startz=endz;
		endz=temp;

		temp=startx;
		startx=endx;
		endx=temp;
	}


	float deltax=float(endx-startx)/(endz-startz);
    int j=0;
	for(int i=startz;i<(endz+1);i++)
	{
		pArray[i]=unsigned char(startx+deltax*j);
		j++;
	}
}
bool CFrustumCull::IsInFrustum(int X,int Z)
{
	if(Z>m_pos[m_downPos].y || Z<m_pos[m_upPos].y)return false;

	if(X>m_RightArray[Z] || X<m_LeftArray[Z])return false;
 
	return true;
}
/*
    if(m_pos[4].x>m_MaxX)m_MaxX=m_pos[4].x;
    if(m_pos[4].y>m_MaxZ)m_MaxZ=m_pos[4].y;
    if(m_pos[2].x>m_MaxX)m_MaxX=m_pos[2].x;
    if(m_pos[2].y>m_MaxZ)m_MaxZ=m_pos[2].y;
    if(m_pos[3].x>m_MaxX)m_MaxX=m_pos[3].x;
    if(m_pos[3].y>m_MaxZ)m_MaxZ=m_pos[3].y;
    if(m_pos[0].x>m_MaxX)m_MaxX=m_pos[0].x;
    if(m_pos[0].y>m_MaxZ)m_MaxZ=m_pos[0].y;
    if(m_pos[1].x>m_MaxX)m_MaxX=m_pos[1].x;
    if(m_pos[1].y>m_MaxZ)m_MaxZ=m_pos[1].y;

    if(m_pos[4].x<m_MinX)m_MinX=m_pos[4].x;
    if(m_pos[4].y<m_MinZ)m_MinZ=m_pos[4].y;
    if(m_pos[2].x<m_MinX)m_MinX=m_pos[2].x;
    if(m_pos[2].y<m_MinZ)m_MinZ=m_pos[2].y;
    if(m_pos[3].x<m_MinX)m_MinX=m_pos[3].x;
    if(m_pos[3].y<m_MinZ)m_MinZ=m_pos[3].y;
    if(m_pos[0].x<m_MinX)m_MinX=m_pos[0].x;
    if(m_pos[0].y<m_MinZ)m_MinZ=m_pos[0].y;
    if(m_pos[1].x<m_MinX)m_MinX=m_pos[1].x;
    if(m_pos[1].y<m_MinZ)m_MinZ=m_pos[1].y;
*/