// TexManager.cpp: implementation of the CTexManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TexManager.h"
#include "texture.h"
#include "gamesetting.h"
#include "imgText.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
unsigned int *CTexManager::m_texList=NULL;
int           CTexManager::m_numUser=0;
CTexManager::CTexManager()
{
	if(m_numUser==0)
	{
		m_texList=new unsigned int [MAX_TEXTURE_NUM];
		for(int i=0;i<MAX_TEXTURE_NUM;i++)
			m_texList[i]=0;
	}
	m_numUser++;
}
CTexManager::~CTexManager()
{
	m_numUser--;
	if(m_numUser==0 && m_texList!=NULL)
	{
		delete [] m_texList;
	}
}
//////////////////////////////////////////////////
bool CTexManager::CreateMenuResource()
{
    CTexture cTex;
	int  error=0;
	//////////// imgtext
	if(!cTex.MakeTextureBind("texture/myfont.BMP",&m_texList[TEX_IMAGE_TEXT],0,0))error++;
	CImgText::m_texFont=m_texList[TEX_IMAGE_TEXT];
    //////////// bkg
	if(!cTex.MakeTextureBind("texture/bkg.BMP",&m_texList[TEX_MENU_BKG],0,0))error++;
	///////////// cursor
	if(!cTex.MakeAlphaTextureBind("texture/cur16.BMP","texture/cur16Alpha.bmp",&m_texList[TEX_MENU_CURSOR]))error++;
	////////////My Photos
	if(!cTex.MakeTextureBind("model/soldier/hpts/a.hpt",&m_texList[TEX_MY_PHOTO_0],1,0))error++;
	if(!cTex.MakeTextureBind("model/soldier/hpts/b.hpt",&m_texList[TEX_MY_PHOTO_1],1,0))error++;
	if(!cTex.MakeTextureBind("model/soldier/hpts/c.hpt",&m_texList[TEX_MY_PHOTO_2],1,0))error++;
	////////////Hero Photos
	if(!cTex.MakeTextureBind("model/soldier/hpts/hero0.hpt",&m_texList[TEX_HERO_PHOTO_0],1,0))error++;
	if(!cTex.MakeTextureBind("model/soldier/hpts/hero1.hpt",&m_texList[TEX_HERO_PHOTO_1],1,0))error++;
	if(!cTex.MakeTextureBind("model/soldier/hpts/hero2.hpt",&m_texList[TEX_HERO_PHOTO_2],1,0))error++;
	if(!cTex.MakeTextureBind("model/soldier/hpts/hero3.hpt",&m_texList[TEX_HERO_PHOTO_3],1,0))error++;
	////////////Sketch
	if(!cTex.MakeTextureBind("texture/sketch/sketch00.bmp",&m_texList[TEX_MISSION_SKETCH_0],1,0))error++;
	if(!cTex.MakeTextureBind("texture/sketch/sketch01.bmp",&m_texList[TEX_MISSION_SKETCH_1],1,0))error++;
	if(!cTex.MakeTextureBind("texture/sketch/sketch02.bmp",&m_texList[TEX_MISSION_SKETCH_2],1,0))error++;
	if(!cTex.MakeTextureBind("texture/sketch/sketch03.bmp",&m_texList[TEX_MISSION_SKETCH_3],1,0))error++;
	if(!cTex.MakeTextureBind("texture/sketch/sketch04.bmp",&m_texList[TEX_MISSION_SKETCH_4],1,0))error++;
	if(!cTex.MakeTextureBind("texture/sketch/sketch05.bmp",&m_texList[TEX_MISSION_SKETCH_5],1,0))error++;

	/////doc
	if(!cTex.MakeTextureBind("script/doc.bmp",&m_texList[TEX_DOCUMENT],1,0))error++;
	

	if(error==0)return true;
	else return false;

}
void  CTexManager::DeleteMenuResource()
{
	glDeleteTextures(1,&m_texList[TEX_IMAGE_TEXT]);

	glDeleteTextures(1,&m_texList[TEX_MENU_BKG]);
	glDeleteTextures(1,&m_texList[TEX_MENU_CURSOR]);

	glDeleteTextures(1,&m_texList[TEX_MY_PHOTO_0]);
	glDeleteTextures(1,&m_texList[TEX_MY_PHOTO_1]);
	glDeleteTextures(1,&m_texList[TEX_MY_PHOTO_2]);

	glDeleteTextures(1,&m_texList[TEX_HERO_PHOTO_0]);
	glDeleteTextures(1,&m_texList[TEX_HERO_PHOTO_1]);
	glDeleteTextures(1,&m_texList[TEX_HERO_PHOTO_2]);
	glDeleteTextures(1,&m_texList[TEX_HERO_PHOTO_3]);

	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_0]);
	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_1]);
	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_2]);
	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_3]);
	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_4]);
	glDeleteTextures(1,&m_texList[TEX_MISSION_SKETCH_5]);

	glDeleteTextures(1,&m_texList[TEX_DOCUMENT]);

}
////////////////////////////////////////////////////
bool CTexManager::CreateMissionResource()
{
    CTexture cTex;
	int  error=0;
	char filename[96];
	int  dirlen;
	///////////////////image text
 	if(!cTex.MakeTextureBind("texture/myfont.BMP",&m_texList[TEX_IMAGE_TEXT],0,0))error++;
	CImgText::m_texFont=m_texList[TEX_IMAGE_TEXT]; 
	//////////sky
	strcpy(filename,CGameSetting::m_strSkyDir);
    dirlen=strlen(filename);

    strcpy(filename+dirlen,"skyb0.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_SKY_0],1,0))error++;
    strcpy(filename+dirlen,"skyb1.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_SKY_1],1,0))error++;
    strcpy(filename+dirlen,"skyb2.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_SKY_2],1,0))error++;
    strcpy(filename+dirlen,"skyb3.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_SKY_3],1,0))error++;
    strcpy(filename+dirlen,"skyb4.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_SKY_4],1,0))error++;

	if(CGameSetting::m_bLensFlare)
	{
	//// LensFlare
	if(!cTex.MakeAlphaTextureBind("flare/flare0.bmp",&m_texList[TEX_LENSFLARE_0]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare1.bmp",&m_texList[TEX_LENSFLARE_1]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare2.bmp",&m_texList[TEX_LENSFLARE_2]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare3.bmp",&m_texList[TEX_LENSFLARE_3]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare4.bmp",&m_texList[TEX_LENSFLARE_4]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare5.bmp",&m_texList[TEX_LENSFLARE_5]))error++;
	if(!cTex.MakeAlphaTextureBind("flare/flare6.bmp",&m_texList[TEX_LENSFLARE_6]))error++;
	}
	//////////terrain
	strcpy(filename,CGameSetting::m_strTerrainSkinDir);
    dirlen=strlen(filename);
    
    strcpy(filename+dirlen,"a1.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_A1]))error++;
    strcpy(filename+dirlen,"a2.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_A2]))error++;
    strcpy(filename+dirlen,"a3.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_A3]))error++;

    strcpy(filename+dirlen,"b1.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_B1]))error++;
    strcpy(filename+dirlen,"b2.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_B2]))error++;
    strcpy(filename+dirlen,"b3.bmp");
	if(!cTex.MakeTextureBind(filename,&m_texList[TEX_TERRAIN_B3]))error++;

    strcpy(filename+dirlen,"TerSkin1.skn");
	if(!cTex.MakeSkinTextureBind(filename,&m_texList[TEX_TERRAIN_SKN1]))error++;
    strcpy(filename+dirlen,"TerSkin2.skn");
	if(!cTex.MakeSkinTextureBind(filename,&m_texList[TEX_TERRAIN_SKN2]))error++;
    strcpy(filename+dirlen,"TerSkin3.skn");
	if(!cTex.MakeSkinTextureBind(filename,&m_texList[TEX_TERRAIN_SKN3]))error++;
    strcpy(filename+dirlen,"TerSkin4.skn");
	if(!cTex.MakeSkinTextureBind(filename,&m_texList[TEX_TERRAIN_SKN4]))error++;
   
	///////////detail texture
//	if(!cTex.MakeTextureBind("terrains/detail2.bmp",&m_texList[TEX_TERRAIN_DETAIL_0]))error++;

	///////////////////Plants
	char alphaname[96];
	strcpy(filename, CGameSetting::m_strPlantsDir);
	strcpy(alphaname,CGameSetting::m_strPlantsDir);
    dirlen=strlen(filename);

   //tree body
	if(!cTex.MakeTextureBind("plants/treebody2.bmp",&m_texList[TEX_TREEBODY_0]))error++;
	if(!cTex.MakeTextureBind("plants/treebody1.bmp",&m_texList[TEX_TREEBODY_1]))error++;
    //branch
    strcpy(filename+dirlen,"branch2.bmp");
    strcpy(alphaname+dirlen,"branchAlpha2.bmp");
	if(!cTex.MakeAlphaTextureBind(filename,alphaname,&m_texList[TEX_BRANCH_0]))error++;
    strcpy(filename+dirlen,"branch1.bmp");
    strcpy(alphaname+dirlen,"branchAlpha1.bmp");
	if(!cTex.MakeAlphaTextureBind(filename,alphaname,&m_texList[TEX_BRANCH_1]))error++;
    strcpy(filename+dirlen,"branch3.bmp");
    strcpy(alphaname+dirlen,"branchAlpha3.bmp");
	if(!cTex.MakeAlphaTextureBind(filename,alphaname,&m_texList[TEX_BRANCH_2]))error++;
    // bush
    strcpy(filename+dirlen,"bush1.bmp");
    strcpy(alphaname+dirlen,"bushAlpha1.bmp");
	if(!cTex.MakeAlphaTextureBind(filename,alphaname,&m_texList[TEX_BUSH_0]))error++;

	///////////////// smf model
	if(!cTex.MakeTextureBind("model/soldier/soldier.bmp",&m_texList[TEX_SOILDER]))error++;
	if(!cTex.MakeTextureBind("model/soldier/weapon.bmp",&m_texList[TEX_WEAPON]))error++;
	if(!cTex.MakeTextureBind("model/soldier/mygun.bmp",&m_texList[TEX_MY_GUN]))error++;

//	if(!cTex.MakeAlphaTextureBind("texture/metal.bmp",&m_texList[TEX_METAL]))error++;

	///////////////// house
	if(!cTex.MakeTextureBind("model/ms3d/house0.bmp",&m_texList[TEX_HOUSE_0]))error++;
	if(!cTex.MakeTextureBind("model/ms3d/house1.bmp",&m_texList[TEX_HOUSE_1]))error++;
	if(!cTex.MakeTextureBind("model/ms3d/house2.bmp",&m_texList[TEX_HOUSE_2]))error++;

	///////////////// smoke
	if(!cTex.MakeAlphaTextureBind("texture/smoke1.bmp",&m_texList[TEX_SMOKE_0]))error++;
	if(!cTex.MakeAlphaTextureBind("texture/gunfire.bmp",&m_texList[TEX_GUN_FIRE]))error++;

	//////////////////TEX_NAVIGATOR
	if(!cTex.MakeTextureBind("Texture/navigator.bmp",&m_texList[TEX_NAVIGATOR],1,0))error++;
	if(!cTex.MakeTextureBind("Texture/help.bmp",&m_texList[TEX_HELP],1,0))error++;

	////////////////////////////
	if(error==0)return true;
	else 
		return false;
}
void  CTexManager::DeleteMissionResource()
{
	glDeleteTextures(1,&m_texList[TEX_IMAGE_TEXT]);
    //////////sky
	glDeleteTextures(1,&m_texList[TEX_SKY_0]);
	glDeleteTextures(1,&m_texList[TEX_SKY_1]);
	glDeleteTextures(1,&m_texList[TEX_SKY_2]);
	glDeleteTextures(1,&m_texList[TEX_SKY_3]);
	glDeleteTextures(1,&m_texList[TEX_SKY_4]);

	//////////terrain 
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_A1]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_A2]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_A3]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_A4]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_A5]);

	glDeleteTextures(1,&m_texList[TEX_TERRAIN_B1]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_B2]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_B3]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_B4]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_B5]);

	glDeleteTextures(1,&m_texList[TEX_TERRAIN_SKN1]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_SKN2]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_SKN3]);
	glDeleteTextures(1,&m_texList[TEX_TERRAIN_SKN4]);

//	glDeleteTextures(1,&m_texList[TEX_TERRAIN_DETAIL_0]);
	
	//// LensFlare
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_0]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_1]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_2]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_3]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_4]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_5]);
	glDeleteTextures(1,&m_texList[TEX_LENSFLARE_6]);

	///// plants
	glDeleteTextures(1,&m_texList[TEX_TREEBODY_0]);
	glDeleteTextures(1,&m_texList[TEX_TREEBODY_1]);

	glDeleteTextures(1,&m_texList[TEX_BRANCH_0]);
	glDeleteTextures(1,&m_texList[TEX_BRANCH_1]);
	glDeleteTextures(1,&m_texList[TEX_BRANCH_2]);

	glDeleteTextures(1,&m_texList[TEX_BUSH_0]);
	glDeleteTextures(1,&m_texList[TEX_BUSH_1]);

	/////////////model
	glDeleteTextures(1,&m_texList[TEX_SOILDER]);
	glDeleteTextures(1,&m_texList[TEX_WEAPON]);
	glDeleteTextures(1,&m_texList[TEX_MY_GUN]);
//	glDeleteTextures(1,&m_texList[TEX_METAL]);

	//////////house
	glDeleteTextures(1,&m_texList[TEX_HOUSE_0]);
	glDeleteTextures(1,&m_texList[TEX_HOUSE_1]);
	glDeleteTextures(1,&m_texList[TEX_HOUSE_2]);

	////////////smoke
	glDeleteTextures(1,&m_texList[TEX_SMOKE_0]);
	glDeleteTextures(1,&m_texList[TEX_GUN_FIRE]);

	/////////////navigaor
	glDeleteTextures(1,&m_texList[TEX_NAVIGATOR]);	
	glDeleteTextures(1,&m_texList[TEX_HELP]);
}	
//////////////////////////////////////////////////
bool  CTexManager::CreateTempMenuResource()
{
    CTexture cTex;
	int  error=0;
	///////////////////image text
// 	if(!cTex.MakeTextureBind("texture/myfont.BMP",&m_texList[TEX_IMAGE_TEXT],0,0))error++;
//	CImgText::m_texFont=m_texList[TEX_IMAGE_TEXT];
	///////////// cursor
	if(!cTex.MakeAlphaTextureBind("texture/cur16.BMP","texture/cur16Alpha.bmp",&m_texList[TEX_MENU_CURSOR]))error++;
    //////////// bkg
	if(!cTex.MakeScreenTextureBind(&m_texList[TEX_SCREEN_CAPTURE]))error++;

	if(error==0)return true;
	else 
		return false;
}
void  CTexManager::DeleteTempMenuResource()
{
//	glDeleteTextures(1,&m_texList[TEX_IMAGE_TEXT]);
	glDeleteTextures(1,&m_texList[TEX_MENU_CURSOR]);
	glDeleteTextures(1,&m_texList[TEX_SCREEN_CAPTURE]);

}
/////////////////////////////////////////////////////
unsigned int CTexManager::GetTextureID(int texDefineName)
{
	if(texDefineName>0 && texDefineName<MAX_TEXTURE_NUM)
        return m_texList[texDefineName];
	else
		return 0;
}





