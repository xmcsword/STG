// Pine.cpp: implementation of the CPine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Pine.h"
#include "Texmanager.h"
#include "math.h"
#include "heightmap.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPine::CPine()
{
	m_szTree=0.2f;
    m_height=m_szTree*60;
}

CPine::~CPine()
{

}
bool CPine::InitPine(int type,float size)
{
	 m_szTree = size;
	 m_height=m_szTree*60;

	 CTexManager cTexManager;
	 //////////////read blend skin texture
	 texTreeBody=cTexManager.GetTextureID(TEX_TREEBODY_1);
     texBranch=cTexManager.GetTextureID(TEX_BRANCH_2);

     return true;
}
void CPine::RenderPine(VERTEX pos)
{
    glPushMatrix();	
	glTranslatef(pos.xpos,pos.ypos,pos.zpos);

    DrawPine();

    glPopMatrix();

	CHeightmap::m_numTriangles += 92 ;
}
void CPine::DrawPine()
{
    ///////////////////////////////////
	//////////Draw Tree Body
    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND);
 	glBindTexture(GL_TEXTURE_2D, texTreeBody);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUAD_STRIP);
	    for(float i=0;i<8;i++)
		{
	        glTexCoord2f(i*0.3f,0);    
			glVertex3f(-m_szTree*sinf(i*45*0.0174533f),0,-m_szTree*cosf(i*45*0.0174533f));
	        glTexCoord2f(i*0.3f+0.3f,8);    
			glVertex3f(-m_szTree*sinf(i*45*0.0174533f)*0.1f,m_height,-m_szTree*cosf(i*45*0.0174533f)*0.1f);
		}
	    glTexCoord2f(2.4f,0);    
	    glVertex3f(0,0,-m_szTree);
	    glTexCoord2f(2.7f,8);    
		glVertex3f(0,m_height,-m_szTree*0.1f);
    glEnd();

    //////////////////////////////////////////
	///////////////// Draw Branch ////////////
   	glAlphaFunc(GL_GREATER,0.10f);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
    glEnable(GL_ALPHA_TEST);

 	glBindTexture(GL_TEXTURE_2D, texBranch);
	glEnable(GL_TEXTURE_2D);
    
    //////////////////////////////////
    glPushMatrix();	
    //////////////////////////////////
	glTranslatef(0,m_height*0.2f,0);
	glRotatef(0,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(170,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.35f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.38f);
  
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(130,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.38f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(170,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.32f);
  
	glTranslatef(0,m_height*0.04f,0);
	glRotatef(130,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f);
 
	glTranslatef(0,m_height*0.035f,0);
	glRotatef(200,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f);

	glTranslatef(0,m_height*0.035f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f);

	glTranslatef(0,m_height*0.05f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.28f);

	glTranslatef(0,m_height*0.055f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.28f);
 
	glTranslatef(0,m_height*0.055f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f);
 
	glTranslatef(0,m_height*0.035f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.18f);
 
	glTranslatef(0,m_height*0.05f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.25f);

	glTranslatef(0,m_height*0.05f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.22f);
 
	glTranslatef(0,m_height*0.055f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f);
 
	glTranslatef(0,m_height*0.045f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.18f);
 
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.1f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.14f);
  
	////////////////////////////
	glPopMatrix();
	////////////////////////////

    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND); 
}
void CPine::DrawBranch(float width)
{
	glBegin(GL_TRIANGLE_STRIP);
	    ////////// face 
	    glTexCoord2f(0,0);
	    glVertex3f(width*0.5f,-width*0.4f,0.7071f*width);

	    glTexCoord2f(0,1);
	    glVertex3f(width,-width*0.1f,0);

	    glTexCoord2f(1,0);
	    glVertex3f(0,0,0);

	    glTexCoord2f(1,1);
	    glVertex3f(width*0.5f,-width*0.4f,-0.7071f*width);

	glEnd();
}