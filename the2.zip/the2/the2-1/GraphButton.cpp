// GraphButton.cpp: implementation of the CGraphButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphButton.h"
#include "audio.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraphButton::CGraphButton()
{
	m_iState=0;
	m_bSelected=false;
	m_bShowPicture=false;
	m_crNormal[0]=m_crNormal[2]=0;
	m_crNormal[1]=0.4f;
	m_crActivate[0]=m_crActivate[2]=0;
	m_crActivate[1]=0.6f;
	m_crRect[0]=m_crRect[2]=0;
	m_crRect[1]=0.6f;
}
CGraphButton::~CGraphButton()
{
}

void CGraphButton::SetButton(RECT rect,char sText[],int state,int iTextAlign)
{
	SetButtonText(sText,iTextAlign);
	SetButtonRect(rect);  
	m_iState=state;

}
void CGraphButton::SetButton(RECT rect,unsigned int texID,int state)
{
	SetButtonRect(rect);
	SetButtonPicture(texID);  
	m_iState=state;
}
void CGraphButton::SetButtonRect(RECT rect)
{
	m_rect=rect;
}
void CGraphButton::SetButtonText(char sText[],int iTextAlign)
{
	int len=strlen(sText);
	if(len>31)
	    sText[31]=NULL;
	strcpy(m_sText, sText);
	m_bShowPicture=false;
	m_iTextAlign=iTextAlign;
}
void CGraphButton::SetButtonPicture(unsigned int texID)
{
	m_texID=texID;
	m_bShowPicture=true;
}
void CGraphButton::SetButtonState(int state)
{
	m_iState=state;
}
void CGraphButton::RenderButton()
{
    UpdateButton();
	DrawButton();

}
void CGraphButton::UpdateButton()
{
	int old=m_iState;
	if(m_iState==BUTTON_DEAD)return;
	if(IsInRect())
	{
		if(m_cInput.m_keys[MOUSE_0])
			m_iState=BUTTON_PUSHED;
		else
		{
			if(m_iState==BUTTON_PUSHED)m_bSelected=true;
			m_iState=BUTTON_ACTIVATE;
		}
	}
	else
	{
		m_iState=BUTTON_NORMAL;
		m_bSelected=false;
	}
	if(old!=m_iState)
	{
//		if(m_iState==BUTTON_ACTIVATE)audio.Play(MENU_SOUND_ONITEM,1,false);
		if(m_iState==BUTTON_PUSHED)CAudio::Play(MENU_SOUND_CLICK,1,false);
	}
}
void CGraphButton::DrawButton()
{
	if(m_bShowPicture)
	{
 	    glBindTexture(GL_TEXTURE_2D, m_texID);
	    glEnable(GL_TEXTURE_2D);
		if(m_iState==BUTTON_DEAD)glColor3f(0.3f,0.3f,0.3f);
		else glColor3f(1,1,1);
 	    glBegin(GL_QUADS);
     	    glTexCoord2f(0,1);    
	        glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	        glTexCoord2f(1,1);   
	        glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
		    glTexCoord2f(1,0);   
	        glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
		    glTexCoord2f(0,0);    
	        glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	    glEnd();
	    glDisable(GL_TEXTURE_2D);
	}
	else
	{
	    glDisable(GL_TEXTURE_2D);
//    	glBlendFunc(GL_ONE,GL_SRC_COLOR);
//    	glEnable(GL_BLEND);
		/////// set color
		if(m_iState==BUTTON_NORMAL)glColor3fv(m_crNormal);
		else if(m_iState==BUTTON_ACTIVATE)glColor3fv(m_crActivate);
		else if(m_iState==BUTTON_PUSHED)glColor3fv(m_crActivate);//(0.4f,0.6f,0);
        else glColor3f(0.35f,0.35f,0.35f);
		glBegin(GL_QUADS);
		    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
		    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    	glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
		    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
		glEnd();
//    	glDisable(GL_BLEND);

	}
	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3fv(m_crRect);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(m_crRect[0]*2,m_crRect[1]*2,m_crRect[2]*2);
	else if(m_iState==BUTTON_PUSHED)glColor3f(0.8f,1.0f,0);
    else glColor3f(0.6f,0.6f,0.6f);
	/////// draw rectangle
	glBegin(GL_LINE_LOOP);
	    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
	    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	glEnd();

	if(m_bShowPicture)return;

	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3f(0.7f,0.7f,0.3f);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(1,0.5f,0);
	else if(m_iState==BUTTON_PUSHED)glColor3f(1,0.5f,0);
    else glColor3f(0.4f,0.4f,0.4f);
	/////// draw text
    if(m_iTextAlign==TEXT_ALIGN_CENTER)
		m_cText.PrintString((m_rect.left+m_rect.right)/2,
		                    (m_rect.bottom+m_rect.top)/2,
						     m_sText,true,16,0);
	else if(m_iTextAlign==TEXT_ALIGN_LEFT)
		m_cText.PrintString(m_rect.left+2,m_rect.top+2,
						    m_sText,false,16,0);

	glColor3f(1,1,1);
}
void   CGraphButton::SetActivateColor(float r,float g,float b)
{
	m_crActivate[0]=r;
	m_crActivate[1]=g;
	m_crActivate[2]=b;
}
void   CGraphButton::SetNormalColor(float r,float g,float b)
{
	m_crNormal[0]=r;
	m_crNormal[1]=g;
	m_crNormal[2]=b;
}
void  CGraphButton::SetRectangleColor(float r,float g,float b)
{
	m_crRect[0]=r;
	m_crRect[1]=g;
	m_crRect[2]=b;

}
bool CGraphButton::IsInRect()
{
	if(m_cInput.m_mousePosX<(m_rect.left) || m_cInput.m_mousePosX>(m_rect.right) )
		return false;
	if(m_cInput.m_mousePosY<(m_rect.top) || m_cInput.m_mousePosY>(m_rect.bottom) )
		return false;
    return true;
}