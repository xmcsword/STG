// MediaPlayer.h: interface for the CMediaPlayer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MEDIAPLAYER_H__CE823E88_A923_11D6_8151_5254AB37CDC9__INCLUDED_)
#define AFX_MEDIAPLAYER_H__CE823E88_A923_11D6_8151_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <dshow.h>
#include "audiodef.h"

class CMediaPlayer  
{
public:
	CMediaPlayer();
	virtual ~CMediaPlayer();

	static bool  CreateMusic(char *filename);
	static void  SetVolume(int volume);
	static int   GetRemainTime();
	static bool  IsMediaEnable();
	static void  SetMediaActive(bool IsMediaActive);
	static bool  IsMediaActive();
	static void  Play();
	static void  Pause();
	static void  Stop();

private:
    static bool   Init();

    static LPDIRECTSHOWGRAPHBUILDER   m_pGraph;
    static LPDIRECTSHOWMEDIACONTROL   m_pMediaControl;
    static LPDIRECTSHOWMEDIAPOSITION  m_pMediaPosition;

	static int       m_musicState;
	static bool      m_bActive;
	static REFTIME   m_tmDuration;
	static int       m_numUser;
};

#endif // !defined(AFX_MEDIAPLAYER_H__CE823E88_A923_11D6_8151_5254AB37CDC9__INCLUDED_)
