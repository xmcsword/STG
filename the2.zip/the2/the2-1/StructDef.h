/////////////////structdef.h/////////////

#if !defined(__STRUCT__DEFINE__)
#define __STRUCT__DEFINE__
//////////////////////////////////////////
#define  UNKNOW        -2
#define  IN_BACK_OF    -1
#define  COINCIDENT     0
#define  IN_FRONT_OF    1
#define  SPANNING       2
 
#define  REVERSE        3
#define  PERPENDICULAR  4
#define  SHARP_ANGLE    5
#define  OBTUSE_ANGLE   6 

#define  OUT_POLYGON   -1
#define  ON_BORDER      0
#define  IN_POLYGON     1
//////// Ammo define
#define  M16            1
#define  RIFLE          2
#define  ROCKET         3

#define  RIFLE_P        1
#define  EXPLOSION_P    2
#define  ROCKET_P       3  
#define  SMOKE_P        4
//////////////////////////////////////////
//////////////////////////////////////////
struct VERTEX
{
	VERTEX(){}
	VERTEX(float x,float y,float z){   xpos=x; ypos=y; zpos=z;} 
	float xpos;
	float ypos;
	float zpos;
};
struct NORMAL
{
	NORMAL(){}
	NORMAL(float x,float y,float z){   nx=x; ny=y; nz=z;} 
	float nx;
	float ny;
	float nz;
};
struct TRIANGLE
{
	TRIANGLE(){}
	TRIANGLE(VERTEX iv1,VERTEX iv2,VERTEX iv3){V1=iv1;V2=iv2;V3=iv3;}
	VERTEX V1;
	VERTEX V2;
	VERTEX V3;
};


struct TEXCOORD
{
	TEXCOORD(){}
	TEXCOORD(float iu,float iv){u=iu;v=iv;}
	float u;
	float v;
};
struct PLANE
{
	PLANE(){}
	PLANE(float a,float b,float c,float d){A=a;B=b;C=c;D=d;}
	float A;
	float B;
	float C;
	float D;
};
struct QUAD
{
	QUAD(){}
	QUAD(VERTEX iv1,VERTEX iv2,VERTEX iv3,VERTEX iv4){V0=iv1;V1=iv2;V2=iv3;V3=iv4;}
	VERTEX V0;
	VERTEX V1;
	VERTEX V2;
	VERTEX V3;
	PLANE  plane;
};
struct CUBE
{
	CUBE(){}
	CUBE(VERTEX iv1,VERTEX iv2,VERTEX iv3,VERTEX iv4,
		 VERTEX iv5,VERTEX iv6,VERTEX iv7,VERTEX iv8)
	{V0=iv1;V1=iv2;V2=iv3;V3=iv4;
	 V4=iv5;V5=iv6;V6=iv7;V7=iv8;}
	CUBE(float radius,VERTEX vCenter)
	{
		V0=VERTEX(vCenter.xpos-radius,vCenter.ypos-radius,vCenter.zpos+radius);
		V1=VERTEX(vCenter.xpos+radius,vCenter.ypos-radius,vCenter.zpos+radius);
		V2=VERTEX(vCenter.xpos+radius,vCenter.ypos-radius,vCenter.zpos-radius);
		V3=VERTEX(vCenter.xpos-radius,vCenter.ypos-radius,vCenter.zpos-radius);
		V4=VERTEX(vCenter.xpos-radius,vCenter.ypos+radius,vCenter.zpos+radius);
		V5=VERTEX(vCenter.xpos+radius,vCenter.ypos+radius,vCenter.zpos+radius);
		V6=VERTEX(vCenter.xpos+radius,vCenter.ypos+radius,vCenter.zpos-radius);
		V7=VERTEX(vCenter.xpos-radius,vCenter.ypos+radius,vCenter.zpos-radius);
	}
	VERTEX V0;                       // Down_Front_Left
	VERTEX V1;                       // Down_Front_Right
	VERTEX V2;                       // Down_Back _Right
	VERTEX V3;                       // Down_Back _Left
	VERTEX V4;                       // Up  _Front_Left
	VERTEX V5;                       // Up  _Front_Right
	VERTEX V6;                       // Up  _Back _Right
	VERTEX V7;                       // Up  _Back _Left
};
struct TRI_FACE
{
	VERTEX v1;
	VERTEX v2;
	VERTEX v3;
	TEXCOORD tex1;
	TEXCOORD tex2;
	TEXCOORD tex3;
	NORMAL n;
	float  d;  // param about face 
	float  powABC; // the normal length=pow (a*a+b*b+c*c ,0.5)
	float  powBC;//the normal length=pow (b*b+c*c ,0.5)
};

struct TRI_TEX
{
    TEXCOORD uv1;
    TEXCOORD uv2;
    TEXCOORD uv3;
};
struct COLOR
{
	COLOR(){}
	COLOR(float red,float green,float blue){r=red;g=green;b=blue;}
	float r;
	float g;
	float b;
};
////////////////////////////////////////////////
struct LIGHT
{
	VERTEX          position;
	COLOR           color;
	unsigned char   brightness;
	unsigned char   attenuation;
	unsigned char   coefficient;
};
struct RLM_QUAD
{
	int   texid;
	PLANE plane;
	int   vertindex[4];
    TEXCOORD texcoord[4];
};
struct BOUNDARY_3D
{
    BOUNDARY_3D()
	{
		minx=miny=minz= 9999;
		maxx=maxy=maxz=-9999;
	} 
	float minx,maxx;
	float miny,maxy;
	float minz,maxz;
};
struct BOUNDARY_2D
{
    BOUNDARY_2D()
	{
		minx=minz= 9999;
		maxx=maxz=-9999;
	} 
    BOUNDARY_2D(int min_x,int max_x,int min_z,int max_z)
	{
		minx=min_x;
		maxx=max_x;
		minz=min_z;
		maxz=max_z;
	} 
	int minx,maxx;
	int minz,maxz;
};
struct TERRAIN_SKIN
{
	unsigned char TextureIndex;
	unsigned char TextureOrder; 
};
struct MOVE_VERTEX
{
	unsigned char xpos; 
	unsigned char zpos; 
};

struct PARTICLE
{
	float	    life;					// Particle Life
	float	    fade;					// Fade Speed
	float    	size;					// 
	VERTEX      pos;
    NORMAL      normal;
	float	    rotate;					// X Rotate
};
struct GRID_BIAS
{
	unsigned char xbias; 
	unsigned char zbias; 
};
////////////////////////////////////////////////
////////////////////////////////////////////////

////////////////////////////////////////////////
#endif 
 