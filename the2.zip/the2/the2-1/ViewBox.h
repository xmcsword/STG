// ViewBox.h: interface for the CViewBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VIEWBOX_H__C88584EB_AB82_11D6_8155_5254AB37CDC9__INCLUDED_)
#define AFX_VIEWBOX_H__C88584EB_AB82_11D6_8155_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "scrollbar.h"

class CViewBox  
{
public:
	CViewBox();
	virtual ~CViewBox();
	void SetViewBox(RECT rect,char *filename);
	void SetViewBox(RECT rect,unsigned int texID);
	void SetText(char *filename);
	void RenderViewBox();

private:
	void  UpdateViewBox();
	void  DrawBackground();
	int    m_iLineHeight; //ÿ�и�
	int    m_numLine;     //������
	int    m_iShowLine;   //������������
	bool   m_bText;       //ͼƬ�������֣�
	bool   m_bShowScroll;
	RECT   m_rect;
    int    m_iHead;       //��ʾ��һ�еĺ���
	int    m_iPos;
	char  *m_string;
	CScrollBar      m_cScrollBar;
};

#endif // !defined(AFX_VIEWBOX_H__C88584EB_AB82_11D6_8155_5254AB37CDC9__INCLUDED_)
