// ScrollBar.cpp: implementation of the CScrollBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScrollBar.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CScrollBar::CScrollBar()
{

}

CScrollBar::~CScrollBar()
{

}
void CScrollBar::SetScrollBar(RECT rect,bool bHorz,int iMaxValue,int iMinValue,int iCurValue)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	RECT rt=rect;
	if(bHorz)
	{
		rt.right=rect.left+height;
        m_cSpin[0].SetSpin(rt,true);
		rt.right=rect.right;
		rt.left=rect.right-height;
        m_cSpin[1].SetSpin(rt,false);
		rt.left=rect.left+int(height*1.2f);
		rt.right=rect.right-int(height*1.2f);
        m_cProcess.SetProcessBar(rt,iMaxValue,iMinValue,iCurValue);
	}
	else
	{
		rt.bottom=rt.top+width;
        m_cSpin[0].SetSpin(rt,true,false);
		rt.bottom=rect.bottom;
		rt.top=rt.bottom-width;
        m_cSpin[1].SetSpin(rt,false,false);
		rt.top=rect.top+int(width*1.2f);
		rt.bottom=rect.bottom-int(width*1.2f);
        m_cProcess.SetProcessBar(rt,iMaxValue,iMinValue,iCurValue,false);
	}
}
void CScrollBar::SetBlockWidth(int width)
{
    m_cProcess.SetBlockWidth(width);
}
void CScrollBar::SetMaxMinValue(int iMaxValue,int iMinValue)
{
    m_cProcess.SetMaxMinValue(iMaxValue,iMinValue);
}
void CScrollBar::SetScrollValue(int iValue)
{
    m_cProcess.m_iValue=iValue;
}
void CScrollBar::SetEnable(bool bState)
{
	m_bEnable=bState;
	if(m_bEnable)
	{
		m_cSpin[0].m_iState=BUTTON_NORMAL;
		m_cSpin[1].m_iState=BUTTON_NORMAL;
        m_cProcess.m_iState=BUTTON_NORMAL;
	}
	else
	{
		m_cSpin[0].m_iState=BUTTON_DEAD;
		m_cSpin[1].m_iState=BUTTON_DEAD;
        m_cProcess.m_iState=BUTTON_DEAD;
	}
}
void CScrollBar::RenderScrollBar()
{
	int oldValue=m_cProcess.m_iValue;

	UpdateScrollBar();
	m_cSpin[0].RenderSpin();
	m_cSpin[1].RenderSpin();
	m_cProcess.RenderProcessBar();

	if(oldValue!=m_cProcess.m_iValue)m_bValueChanged=true;
	else m_bValueChanged=false;
}
void CScrollBar::UpdateScrollBar()
{
	int v=m_cProcess.m_iValue;
	if(m_cSpin[0].m_bChangValue)
	{
		v--;
		m_cProcess.SetValue(v);
	}
	if(m_cSpin[1].m_bChangValue)
	{
		v++;
		m_cProcess.SetValue(v);
	}
}
int CScrollBar::GetValue()
{
    return m_cProcess.m_iValue;
}
void CScrollBar::SetValue(int value)
{
	if(value>m_cProcess.m_iMaxValue)value=m_cProcess.m_iMaxValue;
	if(value<m_cProcess.m_iMinValue)value=m_cProcess.m_iMinValue;
	m_cProcess.m_iValue=value;
}
