// Text.h: interface for the CText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXT_H__AE080081_DDA5_11D5_812C_5254AB37CDC9__INCLUDED_)
#define AFX_TEXT_H__AE080081_DDA5_11D5_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CText  
{
public:
	CText();
	virtual ~CText();
    void  PrintString(int x,int y,char* string,
		              bool bCenter=false,float size=1);
	void  PrintValue( int x,int y,float fValue,
		              bool bCenter=false,float size=1);
	void  PrintValue( int x,int y,int   iValue,
		              bool bCenter=false,float size=1);
private:

    static unsigned char *m_rasters;
	static int            m_numUser;
};

#endif // !defined(AFX_TEXT_H__AE080081_DDA5_11D5_812C_5254AB37CDC9__INCLUDED_)
