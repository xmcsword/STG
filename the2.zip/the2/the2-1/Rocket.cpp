// Rocket.cpp: implementation of the CRocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Rocket.h"
#include "math.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRocket::CRocket()
{
    m_life=0;	
	m_Speed=30.0f;
	listPos=0;
	m_bHit=false;
}

CRocket::~CRocket()
{

}
bool CRocket::InitRocket(VERTEX  startPos,float rotx,float roty,NORMAL direction,unsigned int texid )
{
	m_texid=texid;
    m_CurPos=startPos;
	m_oldPos=startPos;
	m_rotX=rotx;
	m_rotY=roty;
	m_rotZ=0;
    m_direction = direction;
	m_life=400;	
    m_bHit=false;
	for(int i=0;i<P_MAXNUM;i++)
		m_particle[i].life=0;
	///////////////////////////////////////


	return true;
}
void CRocket::UpdateRocket()
{
	if(m_bHit)return;
	m_oldPos=m_CurPos;
	m_CurPos.xpos+=m_direction.nx*m_Speed;
	m_CurPos.ypos+=m_direction.ny*m_Speed;
	m_CurPos.zpos+=m_direction.nz*m_Speed;
    if(m_cHmap.CollideCheck(m_oldPos,m_CurPos,0,1))
	{
		m_life=150;
		m_bHit=true;
	    m_ptcExplosion.InitParticle(EXPLOSION_P,m_oldPos);
	}
    else 
	{
		m_life--;
        Flamethrow();
	}

}
void  CRocket::DrawRocket()
{
	if(m_bHit)
	{
		DrawExplosion();
		m_life--;
	}
	else DrawSmokeTail();
}
void  CRocket::DrawExplosion()
{
    glPushMatrix();	
	glTranslatef(m_CurPos.xpos,m_CurPos.ypos,m_CurPos.zpos);
	glRotatef(*m_cHmap.m_pViewRotY,  0.0f,1.0f,0.0f);
	glRotatef(-*m_cHmap.m_pViewRotX,  1.0f,0.0f,0.0f);

        m_ptcExplosion.DrawParticles(m_CurPos);

    glPopMatrix();
}
void  CRocket::DrawSmokeTail()
{
    ////////here draw rocket
	glDisable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
 	glBindTexture(GL_TEXTURE_2D,m_texid);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
//	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
//	glEnable(GL_ALPHA_TEST);
	////////draw smoke
    for(int i=listPos;i>-1;i--)
	{
		if(m_particle[i].life>0)
		{
			glPushMatrix();
			glTranslatef(m_particle[i].pos.xpos, m_particle[i].pos.ypos, m_particle[i].pos.zpos);
            glRotated( m_rotY,0,1,0);
            glRotated(-m_rotX,1,0,0);
//	        glRotatef(*m_cHmap.m_pViewRotY,  0.0f,1.0f,0.0f);
//        	glRotatef(-*m_cHmap.m_pViewRotX,  1.0f,0.0f,0.0f);

			glColor4d(0.5f,0.5f,0.5f,m_particle[i].life);
			glBegin(GL_QUADS);
		        glTexCoord2d(0,0); 	     
			    glVertex3f(-m_particle[i].size,-m_particle[i].size,0);
		        glTexCoord2d(1,0); 
				glVertex3f( m_particle[i].size,-m_particle[i].size,0);
		        glTexCoord2d(1,1); 			    
				glVertex3f( m_particle[i].size, m_particle[i].size,0);
		        glTexCoord2d(0,1); 			    
				glVertex3f(-m_particle[i].size, m_particle[i].size,0);
            glEnd();
			glPopMatrix();
		}

	}
    for( i=P_MAXNUM;i>listPos;i--)
	{
		if(m_particle[i].life>0)
		{
			glPushMatrix();
			glTranslatef(m_particle[i].pos.xpos, m_particle[i].pos.ypos, m_particle[i].pos.zpos);
            glRotated( m_rotY,0,1,0);
            glRotated(-m_rotX,1,0,0);


			glColor4d(0.5f,0.5f,0.5f,m_particle[i].life);
			glBegin(GL_QUADS);
		        glTexCoord2d(0,0); 	     
			    glVertex3f(-m_particle[i].size,-m_particle[i].size,0);
		        glTexCoord2d(1,0); 
				glVertex3f( m_particle[i].size,-m_particle[i].size,0);
		        glTexCoord2d(1,1); 			    
				glVertex3f( m_particle[i].size, m_particle[i].size,0);
		        glTexCoord2d(0,1); 			    
				glVertex3f(-m_particle[i].size, m_particle[i].size,0);
            glEnd();
			glPopMatrix();
		}

	}
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_CULL_FACE);
	glColor3f(1,1,1);
	listPos++;
	if(listPos>(P_MAXNUM-1))listPos=0;
}
void CRocket::Flamethrow()
{
    for(int i=0;i<P_MAXNUM;i++)
	{
		if(m_particle[i].life>0)
		{
			m_particle[i].life-=0.1f;
			m_particle[i].size+=0.5f;
			//m_particle[i].pos.ypos+=(1-m_particle[i].life)*1.0f;
		}
	}
	m_particle[listPos].life = 1;
	m_particle[listPos].size = 1.5f;
	m_particle[listPos].pos  = m_CurPos; 


}
