// ViewBox.cpp: implementation of the CViewBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ViewBox.h"
#include "imgtext.h"
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CViewBox::CViewBox()
{
	m_bText=true;       //ͼƬ�������֣�
	m_iLineHeight=30; //ÿ�и�
	m_numLine=1;     //������
	m_iShowLine=1;   //������������
	m_string=NULL;
	m_iHead=0;

}
CViewBox::~CViewBox()
{
	if(m_string!=NULL)
		delete [] m_string;
}
void CViewBox::SetViewBox(RECT rect,char *filename)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	m_iLineHeight=30;
	m_iShowLine=height/m_iLineHeight;
	rect.bottom=rect.top+ m_iShowLine*m_iLineHeight;
	m_rect=rect;
    
	/////////////////// read file/////////
	FILE *file;
	file = fopen(filename, "rt");
    if(file==NULL)
	{
		m_string=new char [64];
		strcpy(m_string,"Open file \"");
		strcat(m_string,filename);
		strcat(m_string,"\" failed!");
		m_numLine=1;  
	}
	else
	{
        fseek(file,0,SEEK_END);
	    int size=ftell(file);
	    fseek(file,0,SEEK_SET);
		m_string=new char [size];

		int numLine=1;
 		for(int i=0;i<(size-1);i++)
		{
			m_string[i]=fgetc(file);
			if(m_string[i]==-1)m_string[i]=NULL;
			if(m_string[i]=='\n')numLine++;
		}

    	m_numLine= numLine;	
		fclose(file);

	}

 	////////// scroll bar   
	if(m_numLine>m_iShowLine)
	{
		m_bShowScroll=true;
    	rect.left=rect.right-22; // 25 is scrollbar's width
    	m_cScrollBar.SetScrollBar(rect,false,m_numLine-m_iShowLine,0);
    	m_cScrollBar.SetBlockWidth(16);
	}
	else
	{
        m_iShowLine=m_numLine;
		m_bShowScroll=false;
	}
	m_iHead=0;
	m_iPos=0;
	m_bText=true; 

}
void CViewBox::SetViewBox(RECT rect,unsigned int texID)
{
	///////////////////////////
	m_iHead=0;
	m_iPos=0;
	m_bText=false; 
}
void  CViewBox::RenderViewBox()
{
	UpdateViewBox();
	//////////////////////////background
	DrawBackground();

	///////////////////////Scroll
    if(m_bShowScroll)
	{
		m_cScrollBar.RenderScrollBar();
	}


	///////////////////////////////////////
	/////////// show text
    int pos=m_iPos;
	int textSize=16;
	int x=m_rect.left+10,y=m_rect.top+5;
	int xbias=10;
	glColor3f(0,1,0);
	for(int i=0;i<m_iShowLine;i++)
	{	
		x=m_rect.left+10;
	    while(m_string[pos]!='\n' && m_string[pos]!=NULL)
		{
			if(m_string[pos]=='~')
			{
				textSize=18;
				xbias=10;
			    glColor3f(1,1,0);
			}
			else if(m_string[pos]=='`')
			{
				textSize=16;
				xbias=9;
			    glColor3f(0,1,0);
			}
			else
			{
			    CImgText::PrintfChar(x,y,m_string[pos],0,textSize);
		    	x+=xbias;
			}
			pos++;

		};
		pos++;

        y+=m_iLineHeight;
	}


}
void  CViewBox::UpdateViewBox()
{
	//////////////////////////////
    if(!m_bShowScroll)return;
	if(m_iHead!=m_cScrollBar.GetValue()) //scroll bar had been changed
	{
		m_iHead=m_cScrollBar.GetValue();
		//////////find new position
		int index=0;
		m_iPos=0;
		int len =strlen(m_string);
		while(index<m_iHead && m_iPos<len )
		{
			if(m_string[m_iPos]=='\n')index++;
			m_iPos++;
		}
	}
}
void CViewBox::SetText(char *filename)
{
	if(m_string!=NULL)
		delete [] m_string;
	SetViewBox(m_rect,filename);
}
void CViewBox::DrawBackground()
{
	/////// draw back
//	glBlendFunc(GL_ONE,GL_ONE);
//	glEnable(GL_BLEND);
	glColor3f(0,0.3f,0);
    glBegin(GL_QUADS);
	    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
	    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	glEnd();
//	glDisable(GL_BLEND);

	//////////////////////////background
	/////// draw rectangle
	glColor3f(0,0.8f,0);
	glBegin(GL_LINE_LOOP);
	    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
	    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	glEnd();
}