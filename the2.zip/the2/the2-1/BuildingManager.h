// BuildingManager.h: interface for the CBuildingManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUILDINGMANAGER_H__468C54C1_B602_11D6_90D2_5254AB37CDC9__INCLUDED_)
#define AFX_BUILDINGMANAGER_H__468C54C1_B602_11D6_90D2_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ms3dLoader.h"
#include "SmokeParticle.h"
#include "house.h"
#include "heightmap.h"


class CBuildingManager  
{
public:
	CBuildingManager();
	virtual ~CBuildingManager();
	bool   InitBuilding();

    void   RenderBuilding();
	void   RenderSmoke();
private:
	CMs3dLoader    m_ms3dHouse;
	CSmokeParticle m_cSmoke;
	CHeightmap     m_cHmap;

	int         m_numHouse;
	CHouse     *m_cHouse;

};

#endif // !defined(AFX_BUILDINGMANAGER_H__468C54C1_B602_11D6_90D2_5254AB37CDC9__INCLUDED_)
