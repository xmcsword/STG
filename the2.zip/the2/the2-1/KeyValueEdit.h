// KeyValueEdit.h: interface for the CKeyValueEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KEYVALUEEDIT_H__4ADC9FC1_AB04_11D6_8154_5254AB37CDC9__INCLUDED_)
#define AFX_KEYVALUEEDIT_H__4ADC9FC1_AB04_11D6_8154_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphbutton.h"

class CKeyValueEdit  : public CGraphButton
{
public:
	CKeyValueEdit();
	virtual ~CKeyValueEdit();
	void  SetKeyValueEdit(RECT rect,int value);
	void  SetKeyValue(int value);
    void  RenderKeyValueEdit();
	bool  IsValueChanged();
	int   GetKeyValue();
private:
	void  UpdateKeyValueEdit();
	bool  TranslateValueToString(int value ,char *string);
	void  FinishInput();
	int   m_iKeyValue;
	bool  m_bEditting;
	bool  m_bValueChanged;
};

#endif // !defined(AFX_KEYVALUEEDIT_H__4ADC9FC1_AB04_11D6_8154_5254AB37CDC9__INCLUDED_)
