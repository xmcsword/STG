// CtrlSetBox.cpp: implementation of the CCtrlSetBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CtrlSetBox.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCtrlSetBox::CCtrlSetBox()
{
}
CCtrlSetBox::~CCtrlSetBox()
{
}
void CCtrlSetBox::SetCtrlSetBox(RECT rect)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	int itemH=30;
	m_numShow=height/itemH;
	rect.bottom=rect.top+ m_numShow*itemH;
	m_rectBox=rect;
    
 	////////// scroll bar   
	if((CTRL_ITEM-m_numShow)>0)
	{
		m_bShowScroll=true;
    	rect.left=rect.right-22; // 25 is scrollbar's width
    	m_cScrollBar.SetScrollBar(rect,false,CTRL_ITEM-m_numShow,0);
    	m_cScrollBar.SetBlockWidth(16);
	}
	else
	{
        m_numShow=CTRL_ITEM;
		m_bShowScroll=false;
	}

	m_iHead=0;
	////////// edit item

    rect.left=m_rectBox.left+int(width*0.45f);
    rect.right=m_rectBox.left+int(width*0.75f);
    rect.top=m_rectBox.top+5;
	rect.bottom=rect.top+20;

	CGameSetting cGSet;

	m_cEdit[0].SetKeyValueEdit(rect,cGSet.m_iKeyForward);
	m_cEdit[1].SetKeyValueEdit(rect,cGSet.m_iKeyBackward);
 	m_cEdit[2].SetKeyValueEdit(rect,cGSet.m_iKeyLeft);
 	m_cEdit[3].SetKeyValueEdit(rect,cGSet.m_iKeyRight);

	m_cEdit[4].SetKeyValueEdit(rect,cGSet.m_iKeyFire);
	m_cEdit[5].SetKeyValueEdit(rect,cGSet.m_iKeyJump);
	m_cEdit[6].SetKeyValueEdit(rect,cGSet.m_iKeyZoom);
	m_cEdit[7].SetKeyValueEdit(rect,cGSet.m_iKeyHelp);
 	m_cEdit[8].SetKeyValueEdit(rect,cGSet.m_iKeyDrawFPS);
	m_cEdit[9].SetKeyValueEdit(rect,cGSet.m_iKeyMute);

    /////////// m_sTitle[CTRL_ITEM][46]
	strcpy(m_sTitle[0],"Forward");
	strcpy(m_sTitle[1],"Backward");
	strcpy(m_sTitle[2],"Left");
	strcpy(m_sTitle[3],"Right");
	strcpy(m_sTitle[4],"Fire");
	strcpy(m_sTitle[5],"Jump");
	strcpy(m_sTitle[6],"Zoom");
	strcpy(m_sTitle[7],"Help");
	strcpy(m_sTitle[8],"Draw FPS");
	strcpy(m_sTitle[9],"Mute");



}
void CCtrlSetBox::RenderCtrlSetBox()
{
	UpdateCtrlSetBox();
    if(m_bShowScroll)
	{
		m_cScrollBar.RenderScrollBar();
	}
	int itemH=30;
	RECT rect=m_rectBox;
	rect.left=m_rectBox.left+int((m_rectBox.right-m_rectBox.left)*0.50f);
    rect.right=m_rectBox.left+int((m_rectBox.right-m_rectBox.left)*0.85f);
	rect.top=m_rectBox.top+5; 
   	rect.bottom=rect.top+20;

	for(int i=0;i<m_numShow;i++)
	{
		m_cEdit[m_iHead+i].SetButtonRect(rect);
        m_cEdit[m_iHead+i].RenderKeyValueEdit();
		glColor3f(0,1,0);
		CImgText::PrintString(m_rectBox.left+35,rect.top,m_sTitle[m_iHead+i]);

        rect.top += itemH;
		rect.bottom=rect.top +20;
	}
	//////////////////////////background
	/////// draw rectangle
	glBegin(GL_LINE_LOOP);
	    glVertex3i(m_rectBox.left-400 , 300-m_rectBox.top , -520);
	    glVertex3i(m_rectBox.right-400 , 300-m_rectBox.top , -520);
	    glVertex3i(m_rectBox.right-400 , 300-m_rectBox.bottom ,-520);
	    glVertex3i(m_rectBox.left-400 , 300-m_rectBox.bottom , -520);
	glEnd();
}
void CCtrlSetBox::UpdateCtrlSetBox()
{
	///////avoid share key
    for(int i=0;i<CTRL_ITEM;i++)
	{
		if(m_cEdit[i].IsValueChanged())
		{
			int value=m_cEdit[i].GetKeyValue();
			for(int k=0;k<CTRL_ITEM;k++)
			{
				if(k!=i && value==m_cEdit[k].GetKeyValue() )
					m_cEdit[k].SetKeyValue(0);
			}
		}
	}
	//////////////////////////////
    if(!m_bShowScroll)return;
	m_iHead=m_cScrollBar.GetValue();

}
void  CCtrlSetBox::LoadSetting()
{
	CGameSetting cGSet;

	m_cEdit[0].SetKeyValue(cGSet.m_iKeyForward);
	m_cEdit[1].SetKeyValue(cGSet.m_iKeyBackward);
 	m_cEdit[2].SetKeyValue(cGSet.m_iKeyLeft);
 	m_cEdit[3].SetKeyValue(cGSet.m_iKeyRight);

	m_cEdit[4].SetKeyValue(cGSet.m_iKeyFire);
	m_cEdit[5].SetKeyValue(cGSet.m_iKeyJump);
	m_cEdit[6].SetKeyValue(cGSet.m_iKeyZoom);
	m_cEdit[7].SetKeyValue(cGSet.m_iKeyHelp);
 	m_cEdit[8].SetKeyValue(cGSet.m_iKeyDrawFPS);
	m_cEdit[9].SetKeyValue(cGSet.m_iKeyMute);
}
void  CCtrlSetBox::SaveSetting()
{
	CGameSetting cGSet;

	cGSet.m_iKeyForward=m_cEdit[0].GetKeyValue();
	cGSet.m_iKeyBackward=m_cEdit[1].GetKeyValue();
 	cGSet.m_iKeyLeft=m_cEdit[2].GetKeyValue();
 	cGSet.m_iKeyRight=m_cEdit[3].GetKeyValue();

	cGSet.m_iKeyFire=m_cEdit[4].GetKeyValue();
	cGSet.m_iKeyJump=m_cEdit[5].GetKeyValue();
	cGSet.m_iKeyZoom=m_cEdit[6].GetKeyValue();
	cGSet.m_iKeyHelp=m_cEdit[7].GetKeyValue();
 	cGSet.m_iKeyDrawFPS=m_cEdit[8].GetKeyValue();
	cGSet.m_iKeyMute=m_cEdit[9].GetKeyValue();
}