// ChangeBar.h: interface for the CChangeBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHANGEBAR_H__886370E1_A111_11D2_814D_5254AB37CDC9__INCLUDED_)
#define AFX_CHANGEBAR_H__886370E1_A111_11D2_814D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphspin.h"

class CChangeBar  
{
public:
	CChangeBar();
	virtual ~CChangeBar();
    void SetChangeBar(RECT rect, char **sText,int numItem,int curItem);
    void SetChangeBar(RECT rect, unsigned int *texID,int numItem,int curItem);
    void SetEnable(bool bState);
	void SetItem(int iItem);
	int  GetSelected();
	int  GetTotalItemNumber();
	void RenderChangeBar();
	bool m_bValueChanged;
	bool m_bEnable;

private:
	void   UpdateChangeBar(); 
	void   UpdateButtonShow();

	int           m_iMaxItem;
	int  m_iSelect;
	unsigned int *m_texID;
	char        **m_sText;
	CGraphSpin    m_cSpin[2];
	CGraphButton  m_cButton;

 

};

#endif // !defined(AFX_CHANGEBAR_H__886370E1_A111_11D2_814D_5254AB37CDC9__INCLUDED_)
