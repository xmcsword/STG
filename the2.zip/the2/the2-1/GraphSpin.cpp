// GraphSpin.cpp: implementation of the CGraphSpin class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphSpin.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraphSpin::CGraphSpin()
{
    m_bHorz=true;
}

CGraphSpin::~CGraphSpin()
{

}
void CGraphSpin::SetSpin(RECT rect,bool bFirst,bool bHorizontal)
{
	CGraphButton::SetButtonRect(rect);
	m_bFirstSpin=bFirst;
	m_bHorz=bHorizontal;
}
void CGraphSpin::RenderSpin()
{
	CGraphButton::UpdateButton();
	UpdateSpin();

	int width=m_rect.right-m_rect.left;
	int height=m_rect.bottom-m_rect.top;
	//////// draw spin
	glDisable(GL_TEXTURE_2D);
	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3f(0.0f,0.4f,0.0f);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(0,0.6f,0);
	else if(m_iState==BUTTON_PUSHED)glColor3f(0.6f,0.6f,0);
    else glColor3f(0.35f,0.35f,0.35f);
	glBegin(GL_TRIANGLES);
	    if(m_bFirstSpin)
		{
			if(m_bHorz)
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.5f , -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top- height*0.1f, -520);
			}
			else
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.9f , -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.left+width*0.5f-400 , 300-m_rect.top- height*0.1f, -520);
			}
		}else
		{
			if(m_bHorz)
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.1f , -520);
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top-height*0.5f, -520);
			}
			else
			{
                glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.1f , -520);
	            glVertex3f(m_rect.left+width*0.5f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top-height*0.1f, -520);
			}
		}
	glEnd();
	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3f(0.0f,0.6f,0.0f);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(0,1.0f,0);
	else if(m_iState==BUTTON_PUSHED)glColor3f(1,1.0f,0);
    else glColor3f(0.6f,0.6f,0.6f);
	/////// draw rectangle
	glBegin(GL_LINE_LOOP);
	    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
	    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	glEnd();

	/////// draw triangle
	glBegin(GL_LINE_LOOP);
	    if(m_bFirstSpin)
		{
			if(m_bHorz)
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.5f , -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top- height*0.1f, -520);
			}
			else
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.9f , -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.left+width*0.5f-400 , 300-m_rect.top- height*0.1f, -520);
			}
		}else
		{
			if(m_bHorz)
			{
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.1f , -520);
	            glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top-height*0.5f, -520);
			}
			else
			{
                  glVertex3f(m_rect.left+width*0.1f-400 , 300-m_rect.top-height*0.1f , -520);
	            glVertex3f(m_rect.left+width*0.5f-400 , 300-m_rect.bottom+ height*0.1f, -520);
	            glVertex3f(m_rect.right-width*0.1f-400 , 300-m_rect.top-height*0.1f, -520);
			}
		}
	glEnd();

    glColor3f(1,1,1);

}
void CGraphSpin::UpdateSpin()
{
	if(m_iState==BUTTON_PUSHED)m_iPushedTime++;
	else m_iPushedTime=0;

    if(m_iPushedTime==1 || m_iPushedTime>30 )m_bChangValue=true;
	else m_bChangValue=false;
}
