// Rifle.h: interface for the CRifle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RIFLE_H__B99263E1_5EA2_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_RIFLE_H__B99263E1_5EA2_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "heightmap.h"
#include "particle.h"

class CRifle  
{
public:
	CRifle();
	virtual ~CRifle();

	VERTEX   m_bulletPos;
	bool     m_bHit;
	int      m_id;

	NORMAL   m_direction;
	float    m_rotX,m_rotY;

	bool     LunchBullet(int id,VERTEX  startPos,float rotx,float roty ,NORMAL direction);
	void     CalcDestinationPos();
	void     DrawRifleShot();
	CParticle   m_bltParticle;
private:
    CHeightmap   m_cHmap;

};

#endif // !defined(AFX_RIFLE_H__B99263E1_5EA2_11D6_812C_5254AB37CDC9__INCLUDED_)
