// ScrMasker.cpp: implementation of the CScrMasker class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScrMasker.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
int   CScrMasker::m_iGammaBackup=0;
int   CScrMasker::m_iTimer=0;
bool  CScrMasker::m_bFadeIn=false;
bool  CScrMasker::m_bFadeOut=false;
int   CScrMasker::m_iSprayBlood=false;

CScrMasker::CScrMasker()
{
}
CScrMasker::~CScrMasker()
{
}
void  CScrMasker::DrawMasker(float r,float g,float b)
{
	glColor3f(r,g,b);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	float size=1.45f;
	glBegin(GL_QUADS);
	    glVertex3f(-size,-size, -1.1f);
	    glVertex3f( size,-size, -1.1f);
	    glVertex3f( size, size, -1.1f);
	    glVertex3f(-size, size, -1.1f);
    glEnd();
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glColor3f(1,1,1);
}
void  CScrMasker::BrightnessCtrl()
{
	if(m_bFadeIn)
	{
		CGameSetting::m_iGamma++;
		if(CGameSetting::m_iGamma>m_iGammaBackup)
		{
            CGameSetting::m_iGamma=m_iGammaBackup;
			m_bFadeIn=false;
		}
	}
	if(m_bFadeOut)
	{
		CGameSetting::m_iGamma--;
		if(CGameSetting::m_iGamma<-120)
		{
            CGameSetting::m_iGamma=m_iGammaBackup;
			m_bFadeIn=false;
		}

	}

	float gamma=CGameSetting::m_iGamma*0.005f;
	if(gamma<0.01f && gamma>-0.01f)return;
	
	if(gamma>0)
	{
		glBlendFunc(GL_SRC_COLOR,GL_ONE);
		if(m_iSprayBlood>0)
		{
            DrawMasker(gamma,0,0);
			m_iSprayBlood--;
		}
		else
			DrawMasker(gamma,gamma,gamma);
	}
	else
	{
		glBlendFunc(GL_ZERO,GL_SRC_COLOR);
		if(m_iSprayBlood>0)
		{
            DrawMasker(1+gamma,0,0);
			m_iSprayBlood--;
		}
		else
            DrawMasker(1+gamma,1+gamma,1+gamma);
	}
}
void  CScrMasker::MaskScreen(float r,float g,float b,bool bEnhance)
{
	if(bEnhance)
		glBlendFunc(GL_SRC_COLOR,GL_ONE);
	else
		glBlendFunc(GL_ZERO,GL_SRC_COLOR);
	DrawMasker(r,g,b);

}
void  CScrMasker::SprayBlood()
{
    m_iSprayBlood=12;
}
void  CScrMasker::GrayScreen()
{
}
void  CScrMasker::ElideLine()
{
}
void  CScrMasker::FadeIn()
{
	m_iGammaBackup=CGameSetting::m_iGamma;
	CGameSetting::m_iGamma=-120;
    m_bFadeIn=true;
}
void  CScrMasker::FadeOut()
{
	m_iGammaBackup=CGameSetting::m_iGamma;
    m_bFadeOut=true;  
}