// CreditSheet.h: interface for the CCreditSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CREDITSHEET_H__78432221_A7F5_11D6_814F_5254AB37CDC9__INCLUDED_)
#define AFX_CREDITSHEET_H__78432221_A7F5_11D6_814F_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "changeBar.h"
#include "scrollbar.h"

class CCreditSheet  
{
public:
	CCreditSheet();
	virtual ~CCreditSheet();

	bool InitSheet();
	int  RenderSheet();

	int    m_iSelect;
	bool   m_bActive;
private:
	void   DrawBackGround();
	void   DrawRectangle(int x0,int x1,int y0,int y1);

	CGraphButton  m_cBackButton;
	CChangeBar    m_cPhotoBar;


};

#endif // !defined(AFX_CREDITSHEET_H__78432221_A7F5_11D6_814F_5254AB37CDC9__INCLUDED_)
