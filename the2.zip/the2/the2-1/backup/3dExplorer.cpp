// 3dExplorer.cpp : Defines the entry point for the application.
///////////////////////////////////////////////
#include "stdafx.h"
#include "CGL.h"
#include "Input.h"
#include "texmanager.h"
#include "stdio.h"
#include "FPSCounter.h"
#include "Audio.h"
#include "MediaPlayer.h"
#include "AudioManager.h"
#include "GameSetting.h"
#include "menu.h"
#include "tempmenu.h"
#include "imgtext.h"
#include "Scrmasker.h"
#include "mission.h"
///////////////////////////////////////////////
HWND		   hWnd=NULL;		
HINSTANCE	   hInstance;
CGL	           cGL;
CInput         cInput;
CImgText       cText;
CGameSetting   cGameSetting;
CAudio         cAudio;
CMediaPlayer   cMusic;
CAudioManager  cAudioManager;
CFPSCounter    cFPS;
CMenu          cMenu;
CTempMenu      cTempMenu;
CScrMasker     cScrMasker;
CTexManager    cTexManager;
CMission       cMission;

int            oldGameState=GAME_MAIN_MENU;

BOOL CreateGLWindow(int width, int height, int bits);
void KillGLWindow()	;
///////////////////////////////////////////////
bool InitEngine()
{
	///////check audio
 	cGameSetting.LoadSetting();

	cAudioManager.InitCheck(); 

    ///////////////////menu
	if(!cMenu.LoadMenu())
	{
		MessageBox(0, "menu error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	///////////////////////////
    oldGameState=cGameSetting.m_iGameState;

	////////////////////////////
	return true;
}
GLvoid PrepareRun()
{
 	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
	glLoadIdentity();
	glColor3f(1,1,1);

	////////////////////////////////////
	//////////// for test //////////////
    if(cInput.m_keys['L'] && cGameSetting.m_iGameState==GAME_MISSION)
	{
        cInput.m_keys['L']=false;
		int mode[4];
		glGetIntegerv(GL_POLYGON_MODE,mode);
		if( mode[0] == GL_FILL)
		    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
		else
            glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	}

	///////////// end test //////////////
	///////////////////////////////////
	if(oldGameState!=cGameSetting.m_iGameState)
	{
		if(oldGameState==GAME_MAIN_MENU)
		{
			if(cGameSetting.m_iGameState==GAME_MISSION)
			{
				cMenu.DeleteMenu();
                if(cGameSetting.m_iScrWidth !=800)
				{
                    KillGLWindow();				
				    CreateGLWindow(cGameSetting.m_iScrWidth,cGameSetting.m_iScrHeight,cGameSetting.m_iColorDepth);
				}
				cGL.SetGLMissionState();
				cMission.LoadMission();
			}
		}
		else if(oldGameState==GAME_MISSION)
		{
			if(cGameSetting.m_iGameState==GAME_TEMP_MENU)
			{
				cMission.PauseMission();
				cGL.SetGLMenuState();
				cTempMenu.LoadMenu();
			}
			if(cGameSetting.m_iGameState==GAME_MAIN_MENU)
			{
				cMission.DeleteMission();
                if(cGameSetting.m_iScrWidth !=800)
				{
                    KillGLWindow();				
				    CreateGLWindow(800,600,16);
				}
				cGL.SetGLMenuState();
				cMenu.LoadMenu();
			}
		}
		else if(oldGameState==GAME_TEMP_MENU)
		{
			if(cGameSetting.m_iGameState==GAME_MAIN_MENU)
			{
				cMission.DeleteMission();
				cTempMenu.DeleteMenu();
                if(cGameSetting.m_iScrWidth !=800)
				{
                    KillGLWindow();				
				    CreateGLWindow(800,600,16);
				}
				cGL.SetGLMenuState();
				cMenu.LoadMenu();
			}
			if(cGameSetting.m_iGameState==GAME_MISSION)
			{
			    cTempMenu.DeleteMenu();
				cGL.SetGLMissionState();
				cMission.ResumeMission();
			}
		}
		oldGameState=cGameSetting.m_iGameState;
	}	

}
LRESULT CALLBACK WndProc(	HWND	hWnd,
							UINT	message,
							WPARAM	wParam,
							LPARAM	lParam)
{
	// Used later on to get the size of the window
	// Tells Windows we want to check the message
	switch (message)
	{
		case WM_CLOSE:										// Windows being closed
			cGL.DestroyGL();								// Shutown GL
			ShowCursor(TRUE);								// Show mouse
			PostQuitMessage(0);								// Quit the program
			break;
    	case WM_KILLFOCUS:	
			ShowCursor(true);
			if(cGameSetting.m_iGameState==GAME_MISSION)cMission.PauseMission();
			break;
		case WM_SETFOCUS:	
			ShowCursor(false);
			if(cGameSetting.m_iGameState==GAME_MISSION)cMission.ResumeMission();
			break;


		case WM_KEYDOWN:									// Key Being Held Down
			cInput.GetInput(wParam,true);					// Make That Keys Cell True
			break;

		case WM_KEYUP:										// Key Is Released
			cInput.GetInput(wParam,false);					// Make That Keys Cell False
			break;

		case WM_LBUTTONDOWN:								// Left mouse button is pressed
			cInput.m_keys[MOUSE_0]=true;
			break;

		case WM_LBUTTONUP:								// Left mouse button is pressed
			cInput.m_keys[MOUSE_0]=false;
			break;

		case WM_RBUTTONDOWN:								// Right mouse button is pressed
			cInput.m_keys[MOUSE_1]=true;
			break;

		case WM_RBUTTONUP:								// Right mouse button is pressed
			cInput.m_keys[MOUSE_1]=false;
			break;

		case WM_MOUSEMOVE:
			cInput.m_mousePosX = LOWORD(lParam);			// Position of the cursor 
			cInput.m_mousePosY = HIWORD(lParam);
			break;
		case WM_SIZE:										// Resizing the screen
			cGL.Resize(LOWORD(lParam),HIWORD(lParam));		
			break;

		default:
			// Pass windows messages
			return (DefWindowProc(hWnd, message, wParam, lParam));
	}
	return (0);
}
void KillGLWindow()	
{
	ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
	cGL.DestroyGL();
	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}
	if (!UnregisterClass("3dExplorer",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}	
	ShowCursor(TRUE);								// Show Mouse Pointer
}
BOOL CreateGLWindow(int width, int height, int bits)
{
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "3dExplorer";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	////////////////////////////////////////////////////////////////////////////////
	///////// Change Resoultion

		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
		
		}

		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"3dExplorer",							// Class Name
								"3dExplorer",								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	cGL.InitGL(hWnd,bits);
    
	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	cGL.Resize(width, height);					// Set Up Our Perspective GL Screen
 
	ShowCursor(FALSE);
    return true;
}
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	MSG			msg;		// Windows message structure
    
	CreateGLWindow(800,600,16);
	cGL.SetGLMenuState();
	    		
    if(!InitEngine())
	{
		MessageBox(0, "InitEngine error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
//	cScrMasker.FadeIn();
	while (1)
	{
		// Process All Messages
		while (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (GetMessage(&msg, NULL, 0, 0))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
			else
			{
				return TRUE;
			}
		}

		PrepareRun();  

		cMenu.RenderMenu();  
		cTempMenu.RenderMenu();
		cMission.RunMission();

    	cFPS.ShowFPS(700,10);

		cScrMasker.BrightnessCtrl();
		cGL.SwapBuffers();

		if (cGameSetting.m_iGameState==GAME_DEAD)
			SendMessage(hWnd, WM_CLOSE, 0, 0);
	}

	KillGLWindow()	;
	return 0;
}
