// CGL.cpp: implementation of the CGL class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CGL.h"
#include "GameSetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGL::CGL()
{
	m_hRC=NULL;	// Permanent rendering context
	m_hDC=NULL;		// Private GDI device context
	m_hWnd=NULL;	// Window to wich the RC is attached
	m_fov=60;
}

CGL::~CGL()
{
}
bool CGL::SetGLMenuState()
{
	glClearColor(0,0,0,1);	
	glShadeModel(GL_SMOOTH);							// Enables Smooth Color Shading
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST );	// Really Nice Perspective Calculations
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

	glDisable(GL_CULL_FACE);
	glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glDepthFunc(GL_LEQUAL);	
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1,1,1);
	glReadBuffer(GL_FRONT);
	return true;
}
bool CGL::SetGLMissionState()
{
    glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);
    /////////fog
    glFogf(GL_FOG_MODE,GL_LINEAR);
	GLfloat fogcolor[]={0.77f,0.77f,0.77f,1};
    glFogfv(GL_FOG_COLOR,fogcolor);
	glFogf(GL_FOG_DENSITY,0.2f);

    glFogi(GL_FOG_START,2000-20*CGameSetting.m_iFogDensity);
    glFogi(GL_FOG_END,2000-10*CGameSetting.m_iFogDensity);
	glEnable(GL_FOG);
	GLfloat mat_ambient[]={1,1,1,1.0f};
	GLfloat mat_diffuse[]={1,1,1,1.0f};
//	GLfloat mat_emission[]={0.0f,0.0f,0.0f,1.0f};
	GLfloat mat_shininess[]={0.0f};
	GLfloat mat_specular[]={0.0f,0.0f,0.0f,1.0f};
	/*********************************************/
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mat_ambient);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mat_diffuse);
//	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,mat_emission);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,mat_shininess);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,mat_specular);
	GLfloat light0_diffuse[]={0.75f,0.6f,0.5f,1.0f};
	GLfloat light0_ambient[]={0.5f,0.5f,0.5f,1.0f};
	GLfloat light0_emission[]={0.0f,0.0f,0.0f,0.0f};
//	GLfloat light0_position[]={1500.0f,150.0f,1500.0f,1.0f};

	glLightfv(GL_LIGHT0,GL_DIFFUSE,light0_diffuse);
	glLightfv(GL_LIGHT0,GL_AMBIENT,light0_ambient);
	glLightfv(GL_LIGHT0,GL_EMISSION,light0_emission);
 	glEnable(GL_LIGHT0);
//	glEnable(GL_LIGHTING);

//	glLightf(GL_LIGHT1,GL_CONSTANT_ATTENUATION,1);
//	glLightf(GL_LIGHT1,GL_LINEAR_ATTENUATION,0.1f);
//	glLightf(GL_LIGHT1,GL_CONSTANT_ATTENUATION,2);
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
	glAlphaFunc(GL_GEQUAL,0.1f);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Test To Do
	glEnable(GL_DEPTH_TEST);	
//	glEnable(GL_TEXTURE_2D);

	glReadBuffer(GL_BACK);

	return TRUE;
}

void CGL::Resize(int iWidth, int iHeight)
{
	// Handle window resizing
	float Aspect;

	if (iHeight == 0)iHeight=1;

	Aspect = (float) iWidth / (float) iHeight;

	glViewport(0, 0, iWidth, iHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, Aspect, 0.8f, 100000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

bool CGL::InitGL( HWND hWnd,int iColorBits)
{
	// Pixel format storage
	unsigned int PixelFormat;

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		iColorBits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		32,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	m_hWnd=hWnd;
	if (!(m_hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{						// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(m_hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
						// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
	if(!SetPixelFormat(m_hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(m_hRC=wglCreateContext(m_hDC)))				// Are We Able To Get A Rendering Context?
	{
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(m_hDC,m_hRC))					// Try To Activate The Rendering Context
	{
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}
//	SetGLState();

	return TRUE;
}

void CGL::DestroyGL()
{
	if (m_hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(m_hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		m_hRC=NULL;										// Set RC To NULL
	}

	if (m_hDC && !ReleaseDC(m_hWnd,m_hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		m_hDC=NULL;										// Set DC To NULL
	}
}
void CGL::SwapBuffers()
{
	// Swap the buffers
	::SwapBuffers(m_hDC);
}
