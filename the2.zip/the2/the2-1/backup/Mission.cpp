// Mission.cpp: implementation of the CMission class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "Mission.h"
#include "texmanager.h"
#include "AudioManager.h"
#include "imgtext.h"
#include "MediaPlayer.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMission::CMission()
{
	m_3dExplorer=NULL;
	m_cTerrain=NULL;
	m_cSkyBox=NULL;
	m_cHmap=NULL;
	m_cInfoPanel=NULL;
	m_cLensFlare=NULL;
	m_cSprites=NULL;
    m_cBuilding=NULL;
	m_cPlant=NULL;
	m_pAmbientSound=NULL;
	m_pAmmoManager=NULL;

    m_bActivate=false;
	m_bResource=false;
}

CMission::~CMission()
{
	DeleteMission();
}
bool  CMission::LoadMission()
{
	if(m_bResource)return true;
	CGameSetting::LoadMissionConfig();
    ///////////////////////////////////
	CTexManager cTexManager;
    //////
	if(!cTexManager.CreateMissionResource())
        MessageBox(0, "Create textures error", "Error", MB_OK | MB_ICONERROR);
    //////////////Cursor and background
	m_texTest = cTexManager.GetTextureID(TEX_MISSION_TEST_0);

	/////////////////////////////////////
	m_cHmap         = new CHeightmap;
	m_3dExplorer    = new C3dE;
	m_cTerrain      = new CTerrain;
	m_cSkyBox       = new CSkyBox;
	m_cInfoPanel    = new CInfoPanel;
	if(CGameSetting::m_bLensFlare)
	    m_cLensFlare    = new CLensFlare;
	m_cSprites      = new CSpriteManager;
    m_cBuilding     = new CBuildingManager;
	m_cPlant        = new CPlantManager;
	m_pAmbientSound = new CAmbientSounds;
	m_pAmmoManager  = new CAmmoManager;

	m_cHmap->m_cFrustumCull.InitFrustumCull(40,CGameSetting.m_iVisibleDist);
	if(!m_cSkyBox->InitSkyBox(10000,7000,10000,0,-1200,0))
	{
		MessageBox(0, "cSkyBox error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}    
	if(!m_3dExplorer->Init3dExplorer())
	{
		MessageBox(0, "read heightmap failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cTerrain->InitTerrain())
	{
		MessageBox(0, "Init Terrain failed heightmapscene.cpp", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}	
	if(m_cLensFlare!=NULL)
	{
    	if(!m_cLensFlare->InitLensFlare())
		{
	    	MessageBox(0, "Init LensFlare failed", "Error", MB_OK | MB_ICONERROR);
	    	return FALSE;
		}
	}
	if(!m_cSprites->InitSpriteManager())
	{
		MessageBox(0, "Init Terrain failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	
	if(!m_cBuilding->InitBuilding())
	{
		MessageBox(0, "Init building failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cPlant->InitPlantManager())
	{
		MessageBox(0, "Init plant failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_cInfoPanel->InitInfoPanel())
	{
		MessageBox(0, "Init infopanel failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}
	if(!m_pAmmoManager->InitAmmoManager())
	{
		MessageBox(0, "Init ammo failed", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}

	///////////////////////////////////////
	///////// sound 
    CAudioManager  cAudioManager;
	cAudioManager.CreateMissionResource();
    /////////////////////
    m_bActivate=true;
	m_bResource=true;
    return true;
}
void  CMission::RunMission()
{
	if(m_bActivate)return;
    m_pAmbientSound->PlaySounds();

	m_3dExplorer->ProcessInput();
	m_3dExplorer->TransformWorld(0); 
	m_cSkyBox->DrawSkyBox(); 
   	m_3dExplorer->TransformWorld(1);

	glColor3f(1,1,1);
     ///////////////now render scene
	glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);
	GLfloat light0_position[]={1.0f,0.5f,-0.8f,0.0f};
	glLightfv(GL_LIGHT0,GL_POSITION,light0_position);
    glEnable(GL_FOG);
    m_cTerrain->RenderTerrain();
	
    if(!CInput::m_keys['U'])
	{	
	m_cBuilding->RenderBuilding();
	}
    //////////////////////////////////
    glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);

    if(!CInput::m_keys['T'])
	{	
	m_cPlant->RenderPlant();
	}

	glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);

    if(!CInput::m_keys['Y'])
	{	
    m_cSprites->RenderSprites();
	}

    glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
    glDisable(GL_FOG);

    if(m_cLensFlare!=NULL)m_cLensFlare->RenderLensFlare();

	m_cBuilding->RenderSmoke();
    m_pAmmoManager->RenderAmmoManager();

	/////////////////////////////////////
    ///////////////////Information panel
	glLoadIdentity();
    if(m_cHmap->m_myHealth>0)m_cInfoPanel->DrawInfoPanel();
	MissionCompleted();
	//////////////////////////////////////
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		CGameSetting::m_iGameState=GAME_TEMP_MENU;
		return;
	}
	if(CInput::m_keys[VK_F4])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		CGameSetting::m_iGameState=GAME_DEAD;
		return;
	}

	////////////////////////////////////
}
void  CMission::PauseMission()
{
    m_bActivate=false;
	RestoreFOVAngle();

}
void  CMission::ResumeMission()
{
    m_bActivate=true;
    ///////// restore something
	m_cHmap->m_cFrustumCull.InitFrustumCull(40,CGameSetting.m_iVisibleDist);
    m_pAmbientSound->ResetSounds();
}
void CMission::MissionCompleted()
{
	/////////////Mission failed
	if(m_cHmap->m_myHealth<=0)
	{
    	glColor3f(0.5f,0.0f,0.0f);
    	glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_COLOR);
        glEnable(GL_BLEND);
        glDisable(GL_TEXTURE_2D);
    	glBegin(GL_QUADS);
	        glVertex3f(-200, 100 ,CImgText::GetTextDist());
	        glVertex3f( 200, 100 ,CImgText::GetTextDist());
	        glVertex3f( 200, -100 ,CImgText::GetTextDist());
	        glVertex3f(-200, -100 ,CImgText::GetTextDist());
    	glEnd();
        glDisable(GL_BLEND);
	    glColor3f(1,0,0);
	    CImgText::PrintString(400,260,"Mission Failed !",true,18,0);
	    glColor3f(0,1,0);
	    CImgText::PrintString(400,300,"Press space key to restart mission",true,16,0);
	    CImgText::PrintString(400, 330,"Press enter key to end mission",true,16,0);
       ////////////////////////////
    	if(CInput::m_keys[VK_SPACE])
		{
		    CInput::m_keys[VK_SPACE]=false;
			RestartMission();	    
		}
    	if(CInput::m_keys[13])
		{
    		CInput::m_keys[13]=false;
			RestoreFOVAngle();
    		CGameSetting::m_iGameState=GAME_MAIN_MENU;
		}
	}
	////////////Mission completed
	if(m_cSprites->IsAllDeath())
	{
    	glColor3f(0.5f,0.0f,0.0f);
    	glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_COLOR);
        glEnable(GL_BLEND);
        glDisable(GL_TEXTURE_2D);
    	glBegin(GL_QUADS);
	        glVertex3f(-200, 100 ,CImgText::GetTextDist());
	        glVertex3f( 200, 100 ,CImgText::GetTextDist());
	        glVertex3f( 200, -100 ,CImgText::GetTextDist());
	        glVertex3f(-200, -100 ,CImgText::GetTextDist());
    	glEnd();
        glDisable(GL_BLEND);
	    glColor3f(1,1,1);
	    CImgText::PrintString(400,260,"Mission Completed !",true,18,0);
	    glColor3f(0,1,0);
	    CImgText::PrintString(400, 300,"Press space key to restart mission",true,16,0);
	    CImgText::PrintString(400, 330,"Press enter key to end mission",true,16,0);
       ////////////////////////////
    	if(CInput::m_keys[VK_SPACE])
		{
		    CInput::m_keys[VK_SPACE]=false;
			RestartMission();	    
		}
    	if(CInput::m_keys[13])
		{
    		CInput::m_keys[13]=false;
			RestoreFOVAngle();
    		CGameSetting::m_iGameState=GAME_MAIN_MENU;
		}
	}
}
void CMission::RestartMission()
{
    m_cSprites->ResetAllSprite();
	m_3dExplorer->Reset3dExplorerPos();
	CMediaPlayer::Stop();
	CMediaPlayer::Play();

}
void  CMission::RestoreFOVAngle()
{
	CImgText::SetViewFOVAngle(30);
	glViewport(0, 0, CGameSetting::m_iScrWidth, CGameSetting::m_iScrHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60,float(CGameSetting::m_iScrWidth)/CGameSetting::m_iScrHeight, 0.5f, 100000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
void  CMission::DeleteMission()
{
	if(!m_bResource)return;
	//////// Texture
	CTexManager cTexManager;
	cTexManager.DeleteMissionResource();

	////////////////////////
    CAudioManager  cAudioManager;
	cAudioManager.DeleteMissionResource();
	///////////////////////////////////

	if(m_3dExplorer!=NULL) 
	{
		delete m_3dExplorer;
		m_3dExplorer=NULL;
	}
	if(m_cTerrain !=NULL)  
	{
		delete m_cTerrain;
		m_cTerrain=NULL;
	}
	if(m_cSkyBox !=NULL) 
	{
		delete m_cSkyBox;
		m_cSkyBox=NULL;
	}
	if(m_cHmap !=NULL)   
	{
		delete m_cHmap;
		m_cHmap=NULL;
	}
	if(m_cInfoPanel !=NULL)   
	{
		delete m_cInfoPanel;
		m_cInfoPanel=NULL;
	}

	if(m_cLensFlare!=NULL) 
	{
		delete m_cLensFlare;
		m_cLensFlare=NULL;
	}
	if(m_cSprites!=NULL)  
 	{
		delete m_cSprites;
		m_cSprites=NULL;
	}
    if(m_cBuilding!=NULL)  
	{
		delete m_cBuilding;
		m_cBuilding=NULL;
	}
	if(m_cPlant!=NULL)  
	{
		delete m_cPlant;
		m_cPlant=NULL;
	}
	if(m_pAmbientSound!=NULL)  
	{
		delete m_pAmbientSound;
		m_pAmbientSound=NULL;
	}
	if(m_pAmmoManager!=NULL)  
	{
		delete m_pAmmoManager;
		m_pAmmoManager=NULL;
	}
	/////////////////////////////////////
    m_bActivate=false;
	m_bResource=false;
}