// Texture.cpp: implementation of the CTexture class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Texture.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTexture::CTexture()
{
}

bool CTexture::MakeTextureBind(char* TextureFileName,unsigned int* TextureID,
							   bool bLinear,bool bMip)
{
	bool status=true;			// Status Indicator
	AUX_RGBImageRec *Image=NULL;	

     ///////////////////load wall tex
	if (Image=auxDIBImageLoad(TextureFileName))
	{	
		
/*		for(int y=0;y<Image->sizeY;y+=2)
			for(int x=0;x<Image->sizeX;x++)
			{
				Image->data[y*Image->sizeY*3+x*3+0]=0;
				Image->data[y*Image->sizeY*3+x*3+1]=0;
				Image->data[y*Image->sizeY*3+x*3+2]=0;
			}*/

		glGenTextures(1, TextureID);		// Create one Texture
   		glBindTexture(GL_TEXTURE_2D, *TextureID);
        if(bLinear)
		{
			///////////////////////////////
			if(bMip)
			{
                glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
                glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
 	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	    	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB8, Image->sizeX, Image->sizeY, GL_RGB, GL_UNSIGNED_BYTE, Image->data);
			}
			else
			{
                glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
                glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    	        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, Image->sizeX, Image->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, Image->data);				
			}
		}
		else
		{
			if(bMip)
			{
 	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
	    	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB8, Image->sizeX, Image->sizeY, GL_RGB, GL_UNSIGNED_BYTE, Image->data);
			}
			else
			{
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	    		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    	        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, Image->sizeX, Image->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, Image->data);				
			}
		}
	}
	else status=false;
	if (Image) {											// If Texture Exists
		if (Image->data) delete Image->data;				// If Texture Image Exists
		delete Image;
	}
	return status;				
}


bool CTexture::MakeSkinTextureBind(char* TextureFileName,unsigned int* TextureID,
							   bool bLinear,bool bMip)
{
	bool state=true;			// Status Indicator
	unsigned char *Image=new unsigned char [256*256*3];	
	FILE* file;
    if((file= fopen(TextureFileName, "rb"))==NULL)
	{
	    state=false;
		return state;
	}
	char id[10],version;
	fread(id,     sizeof(char),10,  file);
	fread(&version,sizeof(char),1,  file);
	if ( strncmp( id, "Hunter3D00", 10 ) != 0 )
	{
		    fclose(file);
		    return false; // "Not a valid .skn file."
	}
	if ( version !=1 )
	{
	    fclose(file);
	    return false; // "Not a valid .skn file."
	}	

	fread(Image,sizeof(unsigned char),256*256*3,file);

    fclose(file);
    file=NULL;
				
	glGenTextures(1, TextureID);		// Create one Texture
	glBindTexture(GL_TEXTURE_2D, *TextureID);
    if(bLinear)
	{
		if(bMip)
			{
 	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
	    	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB8, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, Image);
			}
			else
			{
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    	        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8,256,256, 0, GL_RGB, GL_UNSIGNED_BYTE, Image);				
			}
	}
	else
	{
			if(bMip)
			{
 	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	    	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
	    	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB8, 256, 256, GL_RGB, GL_UNSIGNED_BYTE, Image);
			}
			else
			{
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	    		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    	        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, 256,256, 0, GL_RGB, GL_UNSIGNED_BYTE, Image);				
			}
	}

    delete [] Image;				// If Texture Image Exists
	return state;				
}
/////////////////////////////////////////////////
bool CTexture::MakeAlphaTextureBind(char* TextureFileName,unsigned int* TextureID)
{
	bool status=true;												// Status Indicator
	AUX_RGBImageRec *Image=NULL;									// Create Storage Space For The Texture
	unsigned char *alpha=NULL;

	////////////////////////////////////
	if (Image=auxDIBImageLoad(TextureFileName)) 
	{							
		alpha=new unsigned char[4*Image->sizeX*Image->sizeY];		// Create Memory For RGBA8-Texture
		for (int a=0; a<Image->sizeX*Image->sizeY; a++)
		{
			alpha[4*a]=Image->data[a*3];					// R
			alpha[4*a+1]=Image->data[a*3+1];				// G
			alpha[4*a+2]=Image->data[a*3+2];				// B
            ////////////Get max
            alpha[4*a+3]=(alpha[4*a+0]<alpha[4*a+1])?alpha[4*a+0]:alpha[4*a+1];
            if(alpha[4*a+2]<alpha[4*a+3])alpha[4*a+3]=alpha[4*a+2];


		}

		///////////////////////////////////////////////			
		glGenTextures(1, TextureID);							// Create One Textures

		// Create Linear Filtered RGBA8-Texture
		glBindTexture(GL_TEXTURE_2D, *TextureID);
   	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA8, Image->sizeX, Image->sizeY, GL_RGBA, GL_UNSIGNED_BYTE, alpha);
		delete [] alpha;
	}
	else status=false;
	if (Image) {											// If Texture Exists
		if (Image->data) delete Image->data;				// If Texture Image Exists
		delete Image;
		Image=NULL;
	}	
	///////////////////////////////////
    return status;
}
bool CTexture::MakeAlphaTextureBind(char* TextureFileName,char *AlphaFileName,unsigned int* TextureID)
{
	bool status=true;												// Status Indicator
	AUX_RGBImageRec *Image=NULL;									// Create Storage Space For The Texture
	unsigned char *alpha=NULL;

	////////////////////////////////////
	if (Image=auxDIBImageLoad(TextureFileName)) 
	{							
		alpha=new unsigned char[4*Image->sizeX*Image->sizeY];		// Create Memory For RGBA8-Texture
		for (int a=0; a<Image->sizeX*Image->sizeY; a++)
		{
			alpha[4*a]=Image->data[a*3];					// R
			alpha[4*a+1]=Image->data[a*3+1];				// G
			alpha[4*a+2]=Image->data[a*3+2];				// B
		}
		/////////////////make alpha chanal
        if(AlphaFileName==NULL)return false;
	    FILE* file;
        if((file= fopen(AlphaFileName, "rb"))==NULL)
	      	return false;
		fseek(file,54,SEEK_SET);
		unsigned char temp[3];
		for ( a=0; a<Image->sizeX*Image->sizeY; a++)
		{
			fread(temp,sizeof(unsigned char),3,file);
            alpha[4*a+3]=(temp[0]>temp[1])?temp[0]:temp[1];
            if(temp[2]>alpha[4*a+3])alpha[4*a+3]=temp[2];
//          alpha[4*a+3]=(temp[0]+temp[1]+temp[2])/3;
			if(alpha[4*a+3]>50)alpha[4*a+3]=255;
		}
		fclose(file);
		///////////////////////////////////////////////			
		glGenTextures(1, TextureID);							// Create One Textures
		// Create Linear Filtered RGBA8-Texture
		glBindTexture(GL_TEXTURE_2D, *TextureID);
   	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA8, Image->sizeX, Image->sizeY, GL_RGBA, GL_UNSIGNED_BYTE, alpha);
		delete [] alpha;
	}
	else status=false;
	if (Image) {											// If Texture Exists
		if (Image->data) delete Image->data;				// If Texture Image Exists
		delete Image;
		Image=NULL;
	}	
	///////////////////////////////////
    return status;
}
bool CTexture::MakeTGAAlphaBind(char* TextureFileName,unsigned int* TextureID)
{
	FILE * fTGA;												// File pointer to texture file
	fTGA = fopen(TextureFileName, "rb");								// Open file for reading
    TGAHeader tgaheader;									// TGA header
	Texture texture;

	if(fTGA == NULL)											// If it didn't open....
	{
		MessageBox(NULL, "Could not open texture file", "ERROR", MB_OK);	// Display an error message
		return false;														// Exit function
	}
	if(fread(&tgaheader, sizeof(TGAHeader), 1, fTGA) == 0)					// Attempt to read 12 byte header from file
	{
		MessageBox(NULL, "Could not read file header", "ERROR", MB_OK);		// If it fails, display an error message 
		if(fTGA != NULL)													// Check to seeiffile is still open
		{
			fclose(fTGA);													// If it is, close it
		}
		return false;														// Exit function
	}

    GLubyte uTGAcompare[12] = {0,0,2, 0,0,0,0,0,0,0,0,0};	// Uncompressed TGA Header
    GLubyte cTGAcompare[12] = {0,0,10,0,0,0,0,0,0,0,0,0};	// Compressed TGA Header
	if(memcmp(uTGAcompare, &tgaheader, sizeof(tgaheader)) == 0)				// See if header matches the predefined header of 
	{																		// an Uncompressed TGA image
		LoadUncompressedTGA(&texture, TextureFileName, fTGA);						// If so, jump to Uncompressed TGA loading code
	}
	else if(memcmp(cTGAcompare, &tgaheader, sizeof(tgaheader)) == 0)		// See if header matches the predefined header of
	{																		// an RLE compressed TGA image
		LoadCompressedTGA(&texture, TextureFileName, fTGA);							// If so, jump to Compressed TGA loading code
	}
	else																	// If header matches neither type
	{
		MessageBox(NULL, "TGA file be type 2 or type 10 ", "Invalid Image", MB_OK);	// Display an error
		fclose(fTGA);
		return false;																// Exit function
	}
    //////////////////////////////////////////////////////////
	glGenTextures(1, TextureID);							// Create One Textures
	// Create Linear Filtered RGBA8-Texture
	glBindTexture(GL_TEXTURE_2D, *TextureID);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA8, texture.width, texture.height, texture.type, GL_UNSIGNED_BYTE, texture.imageData);

	delete [] texture.imageData;
	return true;							
}
bool CTexture::LoadUncompressedTGA(Texture * texture, char * filename, FILE * fTGA)
{
    TGA tga;

	if(fread(tga.header, sizeof(tga.header), 1, fTGA) == 0)					// Read TGA header
	{										
		MessageBox(NULL, "Could not read info header", "ERROR", MB_OK);		// Display error
		if(fTGA != NULL)													// if file is still open
		{
			fclose(fTGA);													// Close it
		}
		return false;														// Return failular
	}	
	texture->width  = tga.header[1] * 256 + tga.header[0];					// Determine The TGA Width	(highbyte*256+lowbyte)
	texture->height = tga.header[3] * 256 + tga.header[2];					// Determine The TGA Height	(highbyte*256+lowbyte)
	texture->bpp	= tga.header[4];										// Determine the bits per pixel
	tga.Width		= texture->width;										// Copy width into local structure						
	tga.Height		= texture->height;										// Copy height into local structure
	tga.Bpp			= texture->bpp;											// Copy BPP into local structure
	if((texture->width <= 0) || (texture->height <= 0) || ((texture->bpp != 24) && (texture->bpp !=32)))	// Make sure all information is valid
	{
		MessageBox(NULL, "Invalid texture information", "ERROR", MB_OK);	// Display Error
		if(fTGA != NULL)													// Check if file is still open
		{
			fclose(fTGA);													// If so, close it
		}
		return false;														// Return failed
	}
	if(texture->bpp == 24)													//If the BPP of the image is 24...
	{
		texture->type	= GL_RGB;											// Set Image type to GL_RGB
	}
	else																	// Else if its 32 BPP
	{
		texture->type	= GL_RGBA;											// Set image type to GL_RGBA
	}
	tga.bytesPerPixel	= (tga.Bpp / 8);									// Compute the number of BYTES per pixel
	tga.imageSize		= (tga.bytesPerPixel * tga.Width * tga.Height);		// Compute the total amout ofmemory needed to store data
	texture->imageData	=new  GLubyte[tga.imageSize];					// Allocate that much memory
	if(texture->imageData == NULL)											// If no space was allocated
	{
		MessageBox(NULL, "Could not allocate memory for image", "ERROR", MB_OK);	// Display Error
		fclose(fTGA);														// Close the file
		return false;														// Return failed
	}
	if(fread(texture->imageData, 1, tga.imageSize, fTGA) != tga.imageSize)	// Attempt to read image data
	{
		MessageBox(NULL, "Could not read image data", "ERROR", MB_OK);		// Display Error
		if(texture->imageData != NULL)										// If imagedata has data in it
		{
			free(texture->imageData);										// Delete data from memory
		}
		fclose(fTGA);														// Close file
		return false;														// Return failed
	}
	for(GLuint cswap = 0;  cswap < (int)tga.imageSize; cswap += tga.bytesPerPixel)	// Swap color bytes from BGR to RGB
	{
		tga.temp						= texture->imageData[cswap];
		texture->imageData[cswap]		= texture->imageData[cswap + 2];
		texture->imageData[cswap + 2]	= tga.temp;
	}
	fclose(fTGA);		

    return true;
}
bool CTexture::LoadCompressedTGA(Texture * texture, char * filename, FILE * fTGA)	
{

    return false;
}

bool  CTexture::MakeScreenTextureBind(unsigned int* TextureID)
{
//	
	if(glIsTexture(* TextureID)==GL_TRUE)
	{
//   		glBindTexture(GL_TEXTURE_2D, *TextureID);
//		glCopyTexSubImage2D(GL_TEXTURE_2D, 0,  0,0,   0,0,  512,512 );	
	}
	else
	{
		GLint Viewport[4];
        glGetIntegerv(GL_VIEWPORT, Viewport);
		int newWidth=128;

        unsigned char *pData=new unsigned char[newWidth*newWidth*3+6]; // +6 for safe
		/////////////�ҵ�pData(x,y)��Ӧ��Ļ�ϵ����ص�(sx,sy)
		int sx,sy;  //����µ�λ��
        unsigned char temp[6];
		for(int y=0;y<newWidth;y++)
			for(int x=0;x<newWidth;x++)
			{
			    sx=int(float(x*Viewport[2])/newWidth);
			    sy=int(float(y*Viewport[3])/newWidth);

	        	glReadPixels(sx,sy,1,1,
			                 GL_RGB,GL_UNSIGNED_BYTE,temp);

                pData[y*newWidth*3+x*3+0]=unsigned char(temp[0]*0.8f);
                pData[y*newWidth*3+x*3+1]=unsigned char(temp[1]*0.8f);
                pData[y*newWidth*3+x*3+2]=unsigned char(temp[2]*0.8f);
			}

        ////////////////////////////////////////////////////////////
		glGenTextures(1, TextureID);		// Create one Texture
   		glBindTexture(GL_TEXTURE_2D, *TextureID);

        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	 	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, newWidth,newWidth, 0, GL_RGB, GL_UNSIGNED_BYTE,pData);				

		delete [] pData;
	}
    return true;
}

CTexture::~CTexture()
{

}
