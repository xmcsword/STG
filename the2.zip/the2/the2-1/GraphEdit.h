// GraphEdit.h: interface for the CGraphEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHEDIT_H__643489A1_AA3D_11D6_8152_5254AB37CDC9__INCLUDED_)
#define AFX_GRAPHEDIT_H__643489A1_AA3D_11D6_8152_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphbutton.h"

class CGraphEdit : public CGraphButton
{
public:
	CGraphEdit();
	virtual ~CGraphEdit();
	void  SetEdit(RECT rect,char *sText,int maxCharacter=31 );
	void  SetEnableEdit(bool bEnableEdit);
	void  GetFocus();
	void  Clear();
	void  SetText(char *sText);
	void  SetHeightLight(bool bHLight);
    void  RenderEdit();
	bool  IsEditting();
private:
	void  UpdateEdit();
	void  FinishEdit();
	int   m_iMaxChar;
	bool  m_bEditting;
	bool  m_bEnableEdit;
	bool  m_bHeightLight;
};

#endif // !defined(AFX_GRAPHEDIT_H__643489A1_AA3D_11D6_8152_5254AB37CDC9__INCLUDED_)
