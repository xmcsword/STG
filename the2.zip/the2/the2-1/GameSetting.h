// GameSetting.h: interface for the CGameSetting class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMESETTING_H__AC0D24E8_A569_11D6_814B_5254AB37CDC9__INCLUDED_)
#define AFX_GAMESETTING_H__AC0D24E8_A569_11D6_814B_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define LOW     0
#define MEDIUM  1
#define HEIGHT  2

#define GAME_DEAD        0
#define GAME_MAIN_MENU   1
#define GAME_MISSION     2
#define GAME_TEMP_MENU   3

#define STRING_LENGTH    44

class CGameSetting  
{
public:
	CGameSetting();
	virtual ~CGameSetting();

	////////// Resolution
	static int   m_iScrWidth;
	static int   m_iScrHeight;
	static int   m_iColorDepth;

	////////// Render
    static int   m_iGamma;
	static int   m_iModelDetail;
	static int   m_iTexQuality;
	static int   m_iVisibleDist;
	static int   m_iForestDensity;
	static int   m_iFogDensity;

	////////// Audio
	static bool  m_bAudioEnable;
	static bool  m_bSound;
	static bool  m_bMusic;
	static int   m_iSoundVolume;
	static int   m_iMusicVolume;

	////////// Control
    //mouse 
    static int   m_iKeyFire;
    static int   m_iKeyZoom;
    //keyboard
    static int   m_iKeyHelp;
    static int   m_iKeyJump;
    static int   m_iKeyForward;
    static int   m_iKeyBackward;
    static int   m_iKeyLeft;
    static int   m_iKeyRight;
    static int   m_iKeyDrawFPS;
    static int   m_iKeyMute;
	////////// Mouse
    static bool  m_bMouseInvert;
    static int   m_iMouseSens;

	static bool  m_bShowMouse;

	////////// Game state
	static int   m_iGameState;

    ///////////////////////////////////Mission
	////////// Mission Select
	static int   m_iMissionSelect;
    ///sky
	static char *m_strSkyDir;
	static bool  m_bLensFlare;
	///plants
	static char *m_strPlantsDir;
	static char *m_strPlantIndex;
    ///Viewer
	static float m_fViewerPosX;
	static float m_fViewerPosZ;
	static float m_fViewerRotY;
	static char *m_strViewerWeapon;
	static char *m_strViewerWeaponSkin;
	///Terrain
	static int   m_iTextureType;
	static char *m_strHeightmap;
	static char *m_strTerrainSkinDir;
	static char *m_strTextureIndex;
	static char *m_strLODmap;

	//////////////////////////////////////////
	////////// Function
    static void         LoadDefaultSetting();
	static void         LoadSetting();
	static void         SaveSetting();
	static void         LoadMissionConfig();
	static void         SaveMissionConfig();
    //////////////////////////
private:
	static void         ReadSettingFromFile(char filename[]);
	static void         SaveSettingItem(char SectionName[],char KeyName[],
		                         int KeyValue,char sINIPath[]);
    static void         MakeModulePath(char filename[], char sINIPath[]);
	static void         SafeCheck();

	static int   m_numUser;
};

#endif // !defined(AFX_GAMESETTING_H__AC0D24E8_A569_11D6_814B_5254AB37CDC9__INCLUDED_)
