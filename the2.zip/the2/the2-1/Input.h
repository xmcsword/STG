// Input.h: interface for the CInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUT_H__D354FBA1_DC64_11D5_812C_5254AB37CDC9__INCLUDED_)
#define AFX_INPUT_H__D354FBA1_DC64_11D5_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define  MOUSE_0  1
#define  MOUSE_1  2

class CInput  
{
public:
	CInput();
	virtual ~CInput();

	void   GetInput(int virtualKey,bool bKeyDown);


	static bool  *m_keys;
	static int    m_mousePosX;
	static int    m_mousePosY;
	static float  m_mouseSpeed;
	static bool   m_bShowMouse;
    static bool   m_bAskTrans;
private:
	int   TranslateKeyValue(int );

	static int    m_numUser;
};

#endif // !defined(AFX_INPUT_H__D354FBA1_DC64_11D5_812C_5254AB37CDC9__INCLUDED_)
