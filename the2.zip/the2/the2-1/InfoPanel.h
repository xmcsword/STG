// InfoPanel1.h: interface for the CInfoPanel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INFOPANEL1_H__CAC6B22C_A7F1_4958_B73E_A59973C7BDFC__INCLUDED_)
#define AFX_INFOPANEL1_H__CAC6B22C_A7F1_4958_B73E_A59973C7BDFC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SMFLoader.h"
#include "heightmap.h"
#include "gunfire.h"

class CInfoPanel  
{
public:
	CInfoPanel();
	virtual ~CInfoPanel();

	bool InitInfoPanel();
	void DrawInfoPanel();

private:
  	void   DrawMyWeapon(); 
	void   GetNavigatorPos(VERTEX *Pos,float *x,float *y);

	CHeightmap    m_cHmap;
	////////////for gun
	CSMFLoader    m_myWeapon;
	CGunFire      m_cGunFire;
	VERTEX        m_gunMouth;

	float         m_gunBiasY;
	float         m_gunBiasAngleY;
	float         m_gunBiasZ;
	float         m_gunBiasX;
	float         m_gunBiasAngleX;

	bool          m_bFire;

	bool          m_bHelpOpen;

	unsigned int  m_texMetal;
	unsigned int  m_texNavigator;
	unsigned int  m_texHelp;

};

#endif // !defined(AFX_INFOPANEL1_H__CAC6B22C_A7F1_4958_B73E_A59973C7BDFC__INCLUDED_)
