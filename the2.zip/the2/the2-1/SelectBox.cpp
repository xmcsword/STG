// SelectBox.cpp: implementation of the CSelectBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SelectBox.h"
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSelectBox::CSelectBox()
{
    m_pButton=NULL;
}
CSelectBox::~CSelectBox()
{
	if(m_pButton!=NULL)
	{
        delete []m_pButton;
	}
}
void CSelectBox::SetSelectBox(RECT rect,char *titleFile,int curItem)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	m_iLineHeight=25;
	m_iShowLine=height/m_iLineHeight;
	rect.bottom=rect.top+ m_iShowLine*m_iLineHeight+5;
	m_rect=rect;
    
	/////////////////// read file/////////
	FILE *file;
	file = fopen(titleFile, "rt");
    if(file==NULL)
	{
		m_numLine=1;  
		m_pButton=new CGraphButton [1];
		char strErr[64];
		strcpy(strErr,"Can't Open file \"");
		strcat(strErr,titleFile);
		strcat(strErr,"\"!");
		rect.bottom=rect.top+20;
		m_pButton[0].SetButton(rect,strErr);
	}
	else
	{
        fseek(file,0,SEEK_END);
	    int size=ftell(file);
	    fseek(file,0,SEEK_SET);

		/////////////////// Find out lines num
		int numLine=0;
		char str[256];
		char *pr=NULL;
		do
		{
			pr=fgets(str,254,file);
			if(pr!=NULL && str[0]!='\n')numLine++;
		}while(pr!=NULL);
    	m_numLine= numLine;	
        ///////////////////// read title
	    fseek(file,0,SEEK_SET);

		m_pButton=new CGraphButton [m_numLine] ;
		int index=0;
		do
		{
			pr=fgets(str,254,file);
			if(pr!=NULL && str[0]!='\n')
			{
				int len=strlen(str);
				if(str[len-1]=='\n')str[len-1]=NULL;
				m_pButton[index].SetButton(rect,str,BUTTON_NORMAL,TEXT_ALIGN_LEFT);
                index++;
			}
		}while(pr!=NULL && index<m_numLine);

		fclose(file);
	}
	///////////////// set button color
	m_iSelect=0;
	for(int i=0;i<m_numLine;i++)
	{	
        m_pButton[i].SetActivateColor(0,0.4f,0);
        m_pButton[i].SetNormalColor(0,0.4f,0);
        m_pButton[i].SetRectangleColor(0,0.4f,0);
	}
    m_pButton[m_iSelect].SetActivateColor(0,0.6f,0);
	m_pButton[m_iSelect].SetNormalColor(0,0.6f,0);
 	////////// scroll bar   
    rect=m_rect;
	if(m_numLine>m_iShowLine)
	{
		m_bShowScroll=true;
    	rect.left=rect.right-20; // 20 is scrollbar's width
    	m_cScrollBar.SetScrollBar(rect,false,m_numLine-m_iShowLine,0);
    	m_cScrollBar.SetBlockWidth(16);
	}
	else
	{
        m_iShowLine=m_numLine;
		m_bShowScroll=false;
	}
	m_iHead=0;
}
void CSelectBox::SetSelect(int iItem)
{
	m_iSelect=iItem;
	if(m_iSelect>(m_iMaxItem-1))m_iSelect=m_iMaxItem-1;
	if(m_iSelect<0)m_iSelect=0;
}
int  CSelectBox::GetSelect()
{
    return m_iSelect;
}
void CSelectBox::RenderSelectBox()
{
	UpdateSelectBox();
    if(m_bShowScroll)
	{
		m_cScrollBar.RenderScrollBar();
	}

	///////////////////////////////////////
	RECT rect=m_rect;
	rect.right=m_rect.right-21;
    rect.top=m_rect.top+5;
	rect.bottom=rect.top+20;
	for(int i=0;i<m_iShowLine;i++)
	{	
		m_pButton[i+m_iHead].SetButtonRect(rect);
        m_pButton[i+m_iHead].RenderButton();
		rect.top+=m_iLineHeight;
		rect.bottom+=m_iLineHeight;
	}
	//////////////////////////background
	/////// draw rectangle
    glColor3f(0,0.7f,0);
	glBegin(GL_LINE_LOOP);
	    glVertex3i(m_rect.left-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.top , -520);
	    glVertex3i(m_rect.right-400 , 300-m_rect.bottom ,-520);
	    glVertex3i(m_rect.left-400 , 300-m_rect.bottom , -520);
	glEnd();
}

void  CSelectBox::UpdateSelectBox()
{
	//////////////////////////////
    if(!m_bShowScroll)m_iHead=0;
	else m_iHead=m_cScrollBar.GetValue();

	int old = m_iSelect;
	for(int i=0;i<m_iShowLine;i++)
	{
		if(m_pButton[i+m_iHead].m_bSelected)
		{
			m_pButton[i+m_iHead].m_bSelected=false;
			m_iSelect=i+m_iHead;
			m_pButton[i+m_iHead].SetActivateColor(0,0.6f,0);
			m_pButton[i+m_iHead].SetNormalColor(0,0.6f,0);

		}
	}
	if(old!=m_iSelect)
	{
		m_bValueChanged=true;
        m_pButton[old].SetActivateColor(0,0.4f,0);
		m_pButton[old].SetNormalColor(0,0.4f,0);
	}
	else m_bValueChanged=false;
}