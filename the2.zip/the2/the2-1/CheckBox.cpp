// CheckBox.cpp: implementation of the CCheckBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CheckBox.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCheckBox::CCheckBox()
{
	m_bEnable=true;
}
CCheckBox::~CCheckBox()
{
}
void CCheckBox::SetCheckBox(RECT rect,bool bState)
{
	CGraphButton::SetButtonRect(rect);
	m_bChecked=bState;
}
void CCheckBox::SetState(bool bState)
{
	m_bChecked=bState;
}
void CCheckBox::RenderCheckBox()
{
	UpdateCheckBox();
	CGraphButton::RenderButton();
    if(!m_bEnable)return;
	int width=m_rect.right-m_rect.left;
	int height=m_rect.bottom-m_rect.top;

	glColor3f(0,1,0);
	if(m_bChecked)
	{
		glBegin(GL_LINE_STRIP);
	        glVertex3f(m_rect.left+width*0.15f-400 , 300-m_rect.top-height*0.5f , -520);
	        glVertex3f(m_rect.left+width*0.45f-400 , 300-m_rect.top-height*0.85f , -520);
	        glVertex3f(m_rect.left+width*0.85f-400 , 300-m_rect.top-height*0.15f ,-520);
	    glEnd();
	}
	else
	{
		glBegin(GL_LINES);
	        glVertex3f(m_rect.left+width*0.15f-400 , 300-m_rect.top-height*0.15f , -520);
	        glVertex3f(m_rect.left+width*0.85f-400 , 300-m_rect.top-height*0.85f , -520);

	        glVertex3f(m_rect.left+width*0.15f-400 , 300-m_rect.top-height*0.85f , -520);
	        glVertex3f(m_rect.left+width*0.85f-400 , 300-m_rect.top-height*0.15f , -520);
	    glEnd();
	}
}
void CCheckBox::UpdateCheckBox()
{
	if(m_bSelected)
	{
        m_bSelected=false;
		m_bChecked=!m_bChecked;
		m_bValueChanged=true;
	}
	else m_bValueChanged=false;
}
void CCheckBox::SetEnable(bool bEnable)
{
    m_bEnable=bEnable;
	if(m_bEnable)
	    m_iState=BUTTON_NORMAL;
	else
	    m_iState=BUTTON_DEAD;
}


