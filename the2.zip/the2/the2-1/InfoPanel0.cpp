// InfoPanel.cpp: implementation of the CInfoPanel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InfoPanel.h"
#include "GameSetting.h"
#include "heightmap.h"
#include "imgtext.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInfoPanel::CInfoPanel()
{
	/*
    Viewport[0]=Viewport[1]=0;
	Viewport[2]=CGameSetting::m_iScrWidth;
	Viewport[3]=CGameSetting::m_iScrWidth;
    focusx=Viewport[2]/2;
	focusy=Viewport[3]/2;*/
}
CInfoPanel::~CInfoPanel()
{
}
void CInfoPanel::DrawInfoPanel()
{

    //////////////// calcau
    GLdouble objx,objy,objz;
	GLfloat depth[4];
    GLdouble ModelMatrix[16], ProjMatrix[16];
    GLint    Viewport[4];

	glGetIntegerv(GL_VIEWPORT, Viewport);
	int focusx=Viewport[2]/2;
	int focusy=Viewport[3]/2;

	glReadPixels(focusx,focusy,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,depth);

    glGetDoublev(GL_MODELVIEW_MATRIX,  ModelMatrix);
    glGetDoublev(GL_PROJECTION_MATRIX, ProjMatrix);

    gluUnProject(focusx,focusy, depth[0], 
		         ModelMatrix, ProjMatrix, Viewport,
				 &objx, &objy, &objz);
    
//	double dx=CHeightmap::m_pViewPos->xpos-objx;
//	double dy=CHeightmap::m_pViewPos->ypos-objy;
//	double dz=CHeightmap::m_pViewPos->zpos-objz;

//	double	distance=sqrt( dx*dx+dy*dy+dz*dz);

	glLoadIdentity();
	/////////////////////////////

	///////////////////// distance info
	glColor3f(1,1,1);
	CImgText::PrintValue(10,100,objx);
	CImgText::PrintValue(10,120,objy);
	CImgText::PrintValue(10,140,objz);


	CImgText::PrintValue(10,180,distance);


	////////////////////// viewer pos info
	CImgText::PrintValue(620,10,CHeightmap::m_pViewPos->xpos);
	CImgText::PrintValue(620,30,CHeightmap::m_pViewPos->ypos);
	CImgText::PrintValue(620,50,CHeightmap::m_pViewPos->zpos);	
	CImgText::PrintValue(620,70,*CHeightmap::m_pViewRotY);


	/////////////////////draw cursor
	glColor3f(0,1,0);
	glBegin(GL_LINES);
        glVertex3f(0,      0.02f,-1.12f);
        glVertex3f(0,     -0.02f,-1.12f);
        glVertex3f(-0.02f,0,     -1.12f);
        glVertex3f(0.02f, 0,     -1.12f);
    glEnd();

}
