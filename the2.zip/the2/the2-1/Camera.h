// Camera.h: interface for the CCamera class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMERA_H__B93A3521_3F0E_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_CAMERA_H__B93A3521_3F0E_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StructDef.h"
#include "cmath.h"
class CCamera  
{
public:
	CCamera();
	virtual ~CCamera();

	void   SetCamera(VERTEX position,float rotY);
	void   SetCamera(VERTEX newFoucs);
	void   SetCameraRotate(float Y_angle);
	void   SetCameraPosition(VERTEX pos);

	bool   IsEnemyInFrustum(VERTEX enemyPos);
	float  GetDistance(VERTEX pos);
    VERTEX  m_CamPos;
	float m_CamRotY;

private:
    /////////////////////////////////////
	NORMAL  m_CamDirection;

    ////////////////////////
	CMath math;
};

#endif // !defined(AFX_CAMERA_H__B93A3521_3F0E_11D6_812C_5254AB37CDC9__INCLUDED_)
