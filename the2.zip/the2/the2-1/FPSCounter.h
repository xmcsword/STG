// FPSCounter.h: interface for the CFPSCounter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FPSCOUNTER_H__F8758261_A630_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_FPSCOUNTER_H__F8758261_A630_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "imgtext.h"
class CFPSCounter  
{
public:
	CFPSCounter();
	virtual ~CFPSCounter();

	void     ShowFPS(int x=20,int y=10);

private:
	CImgText m_cText;
    int FrameTime0, FrameTime1, FrameCount0, FrameCount1, FrameRate;
};

#endif // !defined(AFX_FPSCOUNTER_H__F8758261_A630_11D6_814C_5254AB37CDC9__INCLUDED_)
