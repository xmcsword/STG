// Texture.h: interface for the CTexture class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTURE_H__D9335E64_D6A4_45E9_A6FA_FF8A3BCEB330__INCLUDED_)
#define AFX_TEXTURE_H__D9335E64_D6A4_45E9_A6FA_FF8A3BCEB330__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <stdio.h>
typedef struct
{
	GLubyte Header[12];									// TGA File Header
} TGAHeader;

typedef struct
{
	GLubyte		header[6];								// First 6 Useful Bytes From The Header
	GLuint		bytesPerPixel;							// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint		imageSize;								// Used To Store The Image Size When Setting Aside Ram
	GLuint		temp;									// Temporary Variable
	GLuint		type;	
	GLuint		Height;									//Height of Image
	GLuint		Width;									//Width ofImage
	GLuint		Bpp;									// Bits Per Pixel
} TGA;

typedef	struct									
{
	GLubyte	* imageData;									// Image Data (Up To 32 Bits)
	GLuint	bpp;											// Image Color Depth In Bits Per Pixel
	GLuint	width;											// Image Width
	GLuint	height;											// Image Height
	GLuint	type;											// Image Type (GL_RGB, GL_RGBA)
} Texture;	

class CTexture  
{
public:
	CTexture();
    bool  MakeTextureBind(char* TextureFileName,unsigned int* TextureID,
		                           bool bLinear=true,bool bMip=true);
    bool  MakeSkinTextureBind(char* TextureFileName,unsigned int* TextureID,
		                           bool bLinear=true,bool bMip=true);
    bool  MakeAlphaTextureBind(char* TextureFileName,unsigned int* TextureID);
    bool  MakeAlphaTextureBind(char* TextureFileName,char *AlphaFileName,unsigned int* TextureID);

    bool  MakeTGAAlphaBind(char* TextureFileName,unsigned int* TextureID);

	bool  MakeScreenTextureBind(unsigned int* TextureID);

	virtual ~CTexture();
protected:
    bool LoadUncompressedTGA(Texture * texture, char * filename, FILE * fTGA);
    bool LoadCompressedTGA(Texture * texture, char * filename, FILE * fTGA)	;
};

#endif // !defined(AFX_TEXTURE_H__D9335E64_D6A4_45E9_A6FA_FF8A3BCEB330__INCLUDED_)
