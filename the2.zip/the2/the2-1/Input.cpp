// Input.cpp: implementation of the CInput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Input.h"
// Conversion factor for converting between degrees and radians

bool *CInput::m_keys=NULL;
int   CInput::m_mousePosX=0;
int   CInput::m_mousePosY=0;
float CInput::m_mouseSpeed=1;
bool  CInput::m_bAskTrans=false;
int   CInput::m_numUser=0;
bool  CInput::m_bShowMouse=true;
//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CInput::CInput()
{
	if(m_numUser==0)
	{
		m_keys        =new bool [256];
    	for(int i=0;i<256;i++)
			m_keys[i]=false;
	}
	m_numUser++;
}
CInput::~CInput()
{
	m_numUser--;
	if(m_numUser==0)
	{
		if(m_keys!=NULL)
		    delete [] m_keys;
	}
}

void CInput::GetInput(int virtualKey,bool bKeyDown)
{
	if(m_bAskTrans)
	{
		m_bAskTrans=false;

    	if(virtualKey==20 )  // capslock
		{
	    	if(bKeyDown)m_keys[virtualKey]=!m_keys[virtualKey];
	    	return;
		}
		if(virtualKey>36 && virtualKey<41)
		{
			virtualKey-=37;
			return;
		}
		virtualKey=TranslateKeyValue(virtualKey);
	}

	///////////////////
	if(bKeyDown)
		m_keys[virtualKey]=true;
	else
       	m_keys[virtualKey]=false;

}
int CInput::TranslateKeyValue(int virtualKey)
{
    /////// pad keys
	if(virtualKey>95 && virtualKey<106)return (virtualKey-48);

	////////26 char 
	if(m_keys[16] )  /// Shift or capslock pressed
	{
		if(virtualKey>64 && virtualKey<91 && !m_keys[20]) // A-Z
		{
			m_keys[virtualKey+32]=false;
			return virtualKey;
		}
		switch(virtualKey)
		{
		case 186: // :
            virtualKey=58;
            m_keys[59]=false;
			break;
		case 187: // +
            virtualKey=43;
            m_keys[61]=false;
			break;
		case 188: // <
            virtualKey=60;
            m_keys[44]=false;
			break;
		case 189: // _
            virtualKey=95;
            m_keys[45]=false;
			break;
		case 190: // >
            virtualKey=62;
            m_keys[46]=false;
			break;
		case 191: // ?
            virtualKey=63;
            m_keys[47]=false;
			break;
		case 192: // ~
            virtualKey=126;
            m_keys[96]=false;
			break;
		case 219: // {
            virtualKey=123;
            m_keys[91]=false;
			break;
		case 221: // }
            virtualKey=125;
            m_keys[93]=false;
			break;
		case 222: // "
            virtualKey=34;
            m_keys[39]=false;
			break;

		case 48: // 0-)
            virtualKey=41;  
            m_keys[48]=false;
			break;
		case 49: // 0-)
            virtualKey=33;  
            m_keys[49]=false;
			break;
		case 57: // 9-(
            virtualKey=40;
            m_keys[57]=false;
			break;
		case 56: // 8-*
            virtualKey=42;
            m_keys[56]=false;
			break;
		}
	}
	else
	{
		if(virtualKey>64 && virtualKey<91 && !m_keys[20]) // A-Z
		{
			m_keys[virtualKey]=false;
			virtualKey+=32;   // translate to a-z
			return virtualKey;
		}
		switch(virtualKey)
		{
		case 186: // :
            virtualKey=59;
            m_keys[58]=false;
			break;
		case 187: // =
            virtualKey=61;
            m_keys[43]=false;
			break;
		case 188: // ,
            virtualKey=44;
            m_keys[60]=false;
			break;
		case 189: // -
            virtualKey=45;
            m_keys[95]=false;
			break;
		case 190: // >
            virtualKey=46;
            m_keys[62]=false;
			break;
		case 191: // ?
            virtualKey=47;
            m_keys[63]=false;
			break;
		case 192: // `
            virtualKey=96;
            m_keys[126]=false;
			break;
		case 219: // {
            virtualKey=91;
            m_keys[123]=false;
			break;
		case 221: // }
            virtualKey=93;
            m_keys[125]=false;
			break;
		case 222: // '
            virtualKey=39;
            m_keys[34]=false;
			break;

		case 48: // 0-)
            m_keys[41]=false;
			break;
		case 49: // 1-!
            m_keys[33]=false;
			break;
		case 57: // 9-(
            m_keys[40]=false;
			break;
		case 56: // 8-*
            m_keys[42]=false;
			break;
		}
	}
	///////////////////////////////////////
    return   virtualKey;
}











