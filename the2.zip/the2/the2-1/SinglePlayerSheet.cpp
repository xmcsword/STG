// SinglePlayerSheet.cpp: implementation of the CSinglePlayerSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SinglePlayerSheet.h"
#include "texmanager.h"
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CSinglePlayerSheet::CSinglePlayerSheet()
{
}
CSinglePlayerSheet::~CSinglePlayerSheet()
{
}
bool CSinglePlayerSheet::InitSheet()
{
	RECT rect;
	rect.top=555;
	rect.bottom=585;
	for(int i=0;i<SP_ITEM_NUM;i++)
	{
		rect.left=50+i*250;
		rect.right=250+i*250;
	    m_cButton[i].SetButtonRect(rect);
	}
    m_cButton[0].SetButtonText("Back");
	m_cButton[1].SetButtonText("Load Save");
	m_cButton[2].SetButtonText("New Game");

	m_cButton[1].SetButtonState(BUTTON_DEAD);
	/////////////////////change bar
   
	rect.top=80;
	rect.bottom=290;
	rect.left=100;
	rect.right=300;

	unsigned int texid[4];
	CTexManager cTexManager;
	texid[0]=cTexManager.GetTextureID(TEX_HERO_PHOTO_0);
	texid[1]=cTexManager.GetTextureID(TEX_HERO_PHOTO_1);
	texid[2]=cTexManager.GetTextureID(TEX_HERO_PHOTO_2);
	texid[3]=cTexManager.GetTextureID(TEX_HERO_PHOTO_3);
	
	m_cHero.SetChangeBar(rect,texid,4,0);
	///////////////// script
	rect.top=80;
	rect.bottom=300;
	rect.left=320;
	rect.right=700;
	m_cScript.SetViewBox(rect,"script/hero0.txt");

	//////////// name edit
	rect.left=240;
	rect.right=560;	
	rect.top=330;
	rect.bottom=500;
    m_cPlayerList.SetListBox(rect,PLAYER_NAME,"script/players.txt");

	rect.left=250;
	rect.right=395;
	rect.top=500;
	rect.bottom=520;
	m_cModifyButton.SetButton(rect,"Change Name");
	rect.left=405;
	rect.right=550;
	m_cDeleteButton.SetButton(rect,"Delete Player");
	////////////////////////////////

	m_iSelect=-1;
    m_bActive=false;
	return true;
}
int CSinglePlayerSheet::RenderSheet()
{
	if(!m_bActive)return -1;

	UpdateSinglePlayer();

	DrawBackGround();

	for(int i=0;i<SP_ITEM_NUM;i++)
	{
	    m_cButton[i].RenderButton();
	}
	/////////////////////////////
 	m_cHero.RenderChangeBar();
	if(m_cHero.m_bValueChanged)
	{
		char file[64];
		wsprintf(file,"script/hero%d.txt",m_cHero.GetSelected());
		m_cScript.SetText(file);
	}
	m_cScript.RenderViewBox();

    m_cPlayerList.RenderListBox();

	m_cModifyButton.RenderButton();
	m_cDeleteButton.RenderButton();

	for(i=0;i<SP_ITEM_NUM;i++)
	{
	    if(m_cButton[i].m_bSelected)
		{
			m_cButton[i].m_bSelected=false;
			m_iSelect=i;
			return i;
		}
	} 
	if(CInput::m_keys[13]) // key enter pressed
	{
		CInput::m_keys[13]=false;
		m_iSelect=2;
		return 2;
	}
	return -1;
}
void   CSinglePlayerSheet::UpdateSinglePlayer()
{
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		m_iSelect=0;
		return ;
	}
	if(m_cModifyButton.m_bSelected)
	{
		m_cModifyButton.m_bSelected=false;
		m_cPlayerList.SetCurrentItemEnableEdit();
	}
	if(m_cDeleteButton.m_bSelected)
	{
		m_cDeleteButton.m_bSelected=false;
		m_cPlayerList.ClearCurrentItem();
	}
}
void  CSinglePlayerSheet::DrawBackGround()
{
	CImgText cText;
	glColor3f(0,1,0);
	cText.PrintString(50,20,"Single Player",0,24,0);

	glColor3f(0,0.7f,0);
	////////////////
	int x0=10,x1=800-x0;
	int y0=50,y1=540;
    DrawRectangle( x0, x1, y0, y1);  //  All

    x0=80;  x1=800-x0;
	y0=70;  y1=300;
    DrawRectangle( x0, x1, y0, y1);  //  top

}
void CSinglePlayerSheet::DrawRectangle(int x0,int x1,int y0,int y1)
{
	glBegin(GL_LINE_LOOP);
		glVertex3i(x0-400,300-y0,-520);
		glVertex3i(x1-400,300-y0,-520);
		glVertex3i(x1-400,300-y1,-520);
		glVertex3i(x0-400,300-y1,-520);
    glEnd();
}
void CSinglePlayerSheet::SavePlayerInfo()
{
    m_cPlayerList.SaveItemTitle("script/players.txt");
}

