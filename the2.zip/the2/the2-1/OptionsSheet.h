// OptionsSheet.h: interface for the COptionsSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPTIONSSHEET_H__E9D175C1_A702_11D6_814D_5254AB37CDC9__INCLUDED_)
#define AFX_OPTIONSSHEET_H__E9D175C1_A702_11D6_814D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "changeBar.h"
#include "scrollbar.h"
#include "checkbox.h"
#include "ctrlsetbox.h"

#define   OP_ITEM_NUM 3
#define   FATHER_MAIN_MENU 0
#define   FATHER_NEW_GAME  1



class COptionsSheet  
{
public:
	COptionsSheet();
	virtual ~COptionsSheet();
	bool InitSheet();
	int  RenderSheet();
	void LoadSetting();
	int    m_iSelect;
	bool   m_bActive;
	int    m_iFather;
private:
	void   UpdateOptionsSheet();
	void   DrawBackGround();
	void   DrawRectangle(int x0,int x1,int y0,int y1);

	void   SaveSetting();

	CGraphButton  m_cButton[OP_ITEM_NUM];

	CChangeBar    m_cResolutionBar;
	CChangeBar    m_cColorDepthBar;
	CChangeBar    m_cModelDetailBar;
	CChangeBar    m_cTexQualityBar;	
	CChangeBar    m_cForestDensityBar;
	CChangeBar    m_cFontTypeBar;

	CScrollBar    m_cBrightnessBar;
	CScrollBar    m_cVisiblebDistBar;

	CScrollBar    m_cFogDensityBar;

    CCheckBox     m_cMusicCheckBox;
    CCheckBox     m_cSoundCheckBox;
	CScrollBar    m_cMusicVolumeBar;
	CScrollBar    m_cSoundVolumeBar;
    

	CScrollBar    m_cMouseSensitivity;
    CChangeBar    m_cMouseInvert;

	CCtrlSetBox   m_cKeySetting;

};

#endif // !defined(AFX_OPTIONSSHEET_H__E9D175C1_A702_11D6_814D_5254AB37CDC9__INCLUDED_)
