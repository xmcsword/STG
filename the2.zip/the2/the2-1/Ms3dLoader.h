// Ms3dLoader2.h: unsigned shorterface for the CMs3dLoader2 class.
/*****************************************************
         class CMs3dLoader2
		                    Author Hunter3D
     Loads and renders MilkShape 3D models.
In this version ,It can get texture file names from Ms3d file. 
Please waite me to add animation in CMs3dLoader3...
*****************************************************/
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MS3DLOADER2_H__9CA81F21_D209_11D5_85EA_5254AB37CDC9__INCLUDED_)
#define AFX_MS3DLOADER2_H__9CA81F21_D209_11D5_85EA_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
		//	Vertex structure

#include "structdef.h"

typedef struct MS3DHeader_TYP
{
	char m_ID[10];
	int  m_version;
} MS3DHeader;

// Vertex information
typedef struct MS3DVertex_TYP
{
	unsigned char m_flags;
	float m_vertex[3];
	char m_boneID;
	unsigned char m_refCount;
} MS3DVertex;

// Triangle information
typedef struct MS3DTriangle_TYP
{
	unsigned short m_flags;
	unsigned short m_vertexIndices[3];
	float m_vertexNormals[3][3];
	float m_u[3];
	float m_v[3];
	unsigned char m_smoothingGroup;
	unsigned char m_groupIndex;
} MS3DTriangle;
///Mesh information
typedef struct MS3DMesh_TYP
{
	unsigned char m_flags;
	char m_name[32];
	unsigned short  m_numTriangles;
	unsigned short *m_TriangleIndices;
	char m_MaterialIndex;
} MS3DMesh;
// Material information
typedef struct MS3DMaterial_TYP
{
    char m_name[32];
    float m_ambient[4];
    float m_diffuse[4];
    float m_specular[4];
    float m_emissive[4];
    float m_shininess;	// 0.0f - 128.0f
    float m_transparency;	// 0.0f - 1.0f
    char m_mode;	// 0, 1, 2 is unused now
    char m_texture[128];
    char m_alphamap[128];
} MS3DMaterial;
/////////////////////////////////////////////
struct Vertex
{
	float m_location[3];
};
//	Triangle structure
struct Triangle
{
	float m_normal[3];
	float m_u[3], m_v[3];
	unsigned short   m_vertexIndices[3];
};
//	Mesh
struct Mesh
{
	unsigned int   m_textureIndex;
	unsigned short m_numTriangles;
	unsigned short *m_pTriangleIndices;
};

//////////////////////////////////////////////////
//////////////////////////////////////////////////
class CMs3dLoader  
{
public:
	CMs3dLoader();
	~CMs3dLoader();

	public:
	    bool Load( const char *filename ,float scale) ;
		void Render();
        void DrawBoundary();
		VERTEX GetVertex(int number);
		BOUNDARY_3D   m_boundary;
	protected:
		void Process();
		//	Meshes used
		unsigned short m_numMeshes;
		unsigned short m_numTriangles;	
		unsigned short m_numVertices;	

		Mesh *m_pMeshes;
		//	Triangles used
		Triangle *m_pTriangles;
		//	Vertices Used
		Vertex *m_pVertices;
        //  Texture

};

#endif // !defined(AFX_MS3DLOADER2_H__9CA81F21_D209_11D5_85EA_5254AB37CDC9__INCLUDED_)
