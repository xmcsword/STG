// HitParticle.h: interface for the CHitParticle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HITPARTICLE_H__64FDA341_B5F4_11D6_90D2_5254AB37CDC9__INCLUDED_)
#define AFX_HITPARTICLE_H__64FDA341_B5F4_11D6_90D2_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "smokeparticle.h"

class CHitParticle  : public CSmokeParticle
{
public:
	CHitParticle();
	virtual ~CHitParticle();

	void InitParticle(VERTEX position ,unsigned int texSmoke,
					  int  smokeNumber=20,int fragmentNumber=30,
					  float size=1);
	void DrawFragment();
	void Reset(VERTEX pos);
	void Render();
	float        m_Life;
	VERTEX       m_pos;
private:
	void SetFragParticle(int num);

	PARTICLE    *particle;

	float        m_Fade;
	float        m_color[3];
	float        m_gravity;
	int          m_numFragment;

};

#endif // !defined(AFX_HITPARTICLE_H__64FDA341_B5F4_11D6_90D2_5254AB37CDC9__INCLUDED_)
