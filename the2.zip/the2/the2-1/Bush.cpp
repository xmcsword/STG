// Bush.cpp: implementation of the CBush class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Bush.h"
#include "texmanager.h"
#include "math.h"
#include "heightmap.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBush::CBush()
{
	m_size=10.0f;
    m_height=m_size*0.5f;
}

CBush::~CBush()
{

}
bool CBush::InitBush(int type)
{
	 m_type=type;
	 CTexManager cTexManager;
	 //////////////read blend skin texture
//	 if(type==1)
		 texBush=cTexManager.GetTextureID(TEX_BUSH_0);
//     else
//		 texBush=cTexManager.GetTextureID(TEX_BUSH_0);

     return true;
}
void CBush::RenderBush(VERTEX pos)
{
    glPushMatrix();	
	glTranslatef(pos.xpos,pos.ypos,pos.zpos);

   	glAlphaFunc(GL_GREATER,0.10f);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
    glEnable(GL_ALPHA_TEST);
	glBindTexture(GL_TEXTURE_2D, texBush);
	glEnable(GL_TEXTURE_2D);
	////////////////////////////////////
	if(m_type==1)
        DrawBush();
	else
		DrawLichen();
   ///////////////////////////////////////////
    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND); 
    glPopMatrix();

}
void CBush::DrawBush()
{
	DrawCross(m_size,0,80,0,1,0.336f,1);
	DrawCross(m_size*0.4f,m_size*0.2f,60,1,0.65f,0,0.336f);

	
    glPushMatrix();	
    //////////////////////////////////
	glTranslatef(m_size*0.4f,0,m_size*0.25f);
	DrawCross(m_size*0.4f,0,70,1,0.65f,0,0.336f);
	////////////////////////////
	glPopMatrix();
}
void CBush::DrawLichen()
{
	DrawCross(m_size,0,45,0,1,0.336f,1);
	DrawCross(m_size*0.7f,m_size*0.2f,30,1,0.65f,0,0.336f);


/*	
    glPushMatrix();	
    //////////////////////////////////
	glTranslatef(m_size*0.4f,0,m_size*0.25f);
	DrawCross(m_size*0.4f,0,70,1,0.65f,0,0.336f);
	////////////////////////////
	glPopMatrix();
*/
}
void CBush::DrawCross(float size,float bias,int angle,float x1,float x2,float y1,float y2)
{
	int num=360/angle;

	glBegin(GL_QUADS);
	int curAngle=0;
	for(int i=0;i<num;i++)
	{
		curAngle=angle*i;


	    glTexCoord2f(x1,y1);
	    glVertex3f(bias*cosf(0.0174533f*curAngle),0,bias*sinf(0.0174533f*curAngle));	   
		
		glTexCoord2f(x2,y1);
	    glVertex3f((bias+size)*cosf(0.0174533f*curAngle),0,(bias+size)*sinf(0.0174533f*curAngle));	   

  	    glTexCoord2f(x2,y2);
	    glVertex3f((bias+size)*cosf(0.0174533f*curAngle),size*0.5f,(bias+size)*sinf(0.0174533f*curAngle));	   
	
		glTexCoord2f(x1,y2);
	    glVertex3f(bias*cosf(0.0174533f*curAngle),size*0.5f,bias*sinf(0.0174533f*curAngle));	   
 
	
    	CHeightmap::m_numTriangles += 2 ;
	}
    glEnd();
}
