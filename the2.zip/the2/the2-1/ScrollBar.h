// ScrollBar.h: interface for the CScrollBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCROLLBAR_H__E9D175C2_A702_11D6_814D_5254AB37CDC9__INCLUDED_)
#define AFX_SCROLLBAR_H__E9D175C2_A702_11D6_814D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphspin.h"
#include "processbar.h"

class CScrollBar  
{
public:
	CScrollBar();
	virtual ~CScrollBar();

	void SetScrollBar(RECT rect,bool bHorz=true,int iMaxValue=100,int iMinValue=0,int iCurValue=0);
    void SetMaxMinValue(int iMaxValue,int iMinValue);
	void SetBlockWidth(int width);
	void SetScrollValue(int iValue);
    void SetEnable(bool bState);
	void SetValue(int value);
    int  GetValue();

	void RenderScrollBar();
	bool m_bValueChanged;
	bool m_bEnable;
private:
	void UpdateScrollBar();
	
	CGraphSpin    m_cSpin[2];
	CProcessBar   m_cProcess;
};

#endif // !defined(AFX_SCROLLBAR_H__E9D175C2_A702_11D6_814D_5254AB37CDC9__INCLUDED_)
