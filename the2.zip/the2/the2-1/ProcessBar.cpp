// ProcessBar.cpp: implementation of the CProcessBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ProcessBar.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessBar::CProcessBar()
{
    m_iBlockWidth=18;
}

CProcessBar::~CProcessBar()
{

}
void CProcessBar::SetProcessBar(RECT rect,int iMaxValue,int iMinValue,
		                   int curValue,bool bHorz,int style)
{
	CGraphButton::SetButtonRect(rect);
	m_iMaxValue=iMaxValue;
	m_iMinValue=iMinValue;
	m_iValue=curValue;
	m_bHorz=bHorz;
	m_iStyle=style;
}
void CProcessBar::SetMaxMinValue(int iMaxValue,int iMinValue)
{
	m_iMaxValue=iMaxValue;
	m_iMinValue=iMinValue;
}
void CProcessBar::SetValue(int iValue)
{
	if(iValue<m_iMinValue || iValue>m_iMaxValue)return;
	m_iValue=iValue;
}
void CProcessBar::SetBlockWidth(int width)
{
	if(m_bHorz)
	{
		if(width>(m_rect.right-m_rect.left-2))width=m_rect.right-m_rect.left-2;
	}
    else
	{
		if(width>(m_rect.bottom-m_rect.top-2))width=m_rect.bottom-m_rect.top-2;
	}
 	if(width<16)width=16;   
    m_iBlockWidth=width;
}


void CProcessBar::RenderProcessBar()
{
	UpdateProcessBar();
	CGraphButton::RenderButton();
	int width=m_rect.right-m_rect.left;
	int height=m_rect.bottom-m_rect.top;

	RECT rect=m_rect;
	if(m_bHorz)
	{
		rect.left += int(float((width-m_iBlockWidth)*(m_iValue-m_iMinValue))/(m_iMaxValue-m_iMinValue));
		rect.right=rect.left+m_iBlockWidth;
		rect.top+=2;
		rect.bottom-=2;
	}
	else
	{
		rect.top += int(float((height-m_iBlockWidth)*(m_iValue-m_iMinValue))/(m_iMaxValue-m_iMinValue));
		rect.bottom=rect.top+m_iBlockWidth;
		rect.left+=2;
		rect.right-=2;
	}
    DrawBlock(rect);
}
void CProcessBar::UpdateProcessBar()
{
	if(m_iState!=BUTTON_PUSHED)return;
	/////////// mouse cling
	POINT point;
	GetCursorPos(&point);
	if(m_bHorz)
        point.y=(m_rect.bottom+m_rect.top)/2;
	else
        point.x=(m_rect.right+m_rect.left)/2;
    SetCursorPos(point.x,point.y);

	////////////////////////////////////
	int width=m_rect.right-m_rect.left;
	int height=m_rect.bottom-m_rect.top;
	int delta=m_iMaxValue-m_iMinValue;

	if(m_bHorz)
	{
	    if(m_rect.left>=m_cInput.m_mousePosX)
			m_iValue=m_iMinValue;
		else if((m_rect.right-m_iBlockWidth)<=m_cInput.m_mousePosX)
			m_iValue=m_iMaxValue;
		else
		{
			float factor=float(m_cInput.m_mousePosX-m_rect.left)/(width-m_iBlockWidth);
			m_iValue=m_iMinValue + int(delta*factor);
		}
	}
    else
	{
	    if(m_rect.top>=m_cInput.m_mousePosY)
			m_iValue=m_iMinValue;
		else if((m_rect.bottom-m_iBlockWidth)<=m_cInput.m_mousePosY)
			m_iValue=m_iMaxValue;
		else
		{
			float factor=float(m_cInput.m_mousePosY-m_rect.top)/(height-m_iBlockWidth);
			m_iValue=m_iMinValue+ int(delta*factor);
		}
	}


}
void  CProcessBar::DrawBlock(RECT rect)
{
    glDisable(GL_TEXTURE_2D);
	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3f(0.25f,0.6f,0.0f);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(0,0.8f,0);
	else if(m_iState==BUTTON_PUSHED)glColor3f(0.4f,0.8f,0);
    else glColor3f(0.35f,0.35f,0.35f);

	glBegin(GL_QUADS);
	    glVertex3i(rect.left-400 , 300-rect.top , -520);
	    glVertex3i(rect.right-400 , 300-rect.top , -520);
    	glVertex3i(rect.right-400 , 300-rect.bottom ,-520);
	    glVertex3i(rect.left-400 , 300-rect.bottom , -520);
	glEnd();


	/////// set color
	if(m_iState==BUTTON_NORMAL)glColor3f(0.3f,0.7f,0.3f);
	else if(m_iState==BUTTON_ACTIVATE)glColor3f(0,1.0f,0);
	else if(m_iState==BUTTON_PUSHED)glColor3f(0.8f,1.0f,0);
    else glColor3f(0.6f,0.6f,0.6f);
 
	/////// draw rectangle
	glBegin(GL_LINE_LOOP);
	    glVertex3i(rect.left-400 , 300-rect.top , -520);
	    glVertex3i(rect.right-400 , 300-rect.top , -520);
	    glVertex3i(rect.right-400 , 300-rect.bottom ,-520);
	    glVertex3i(rect.left-400 , 300-rect.bottom , -520);
	glEnd();
}







