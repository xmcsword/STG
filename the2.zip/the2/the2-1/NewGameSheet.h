// NewGameSheet.h: interface for the CNewGameSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NEWGAMESHEET_H__259D2041_AC94_11D6_8156_5254AB37CDC9__INCLUDED_)
#define AFX_NEWGAMESHEET_H__259D2041_AC94_11D6_8156_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "changeBar.h"
#include "ViewBox.h"
#include "SelectBox.h"

class CNewGameSheet  
{
public:
	CNewGameSheet();
	virtual ~CNewGameSheet();
	bool InitSheet();
	int  RenderSheet();
	int  GetMissionSelect();

	int    m_iSelect;
	bool   m_bActive;
private:
	void UpdateSheet();
	void DrawBackground();
	void   DrawRectangle(int x0,int x1,int y0,int y1);

	CGraphButton  m_cButton[3];

	CSelectBox    m_cMissionSelectBox;
	CViewBox      m_cMissionViewBox;
	CChangeBar    m_cSketchBar;

};

#endif // !defined(AFX_NEWGAMESHEET_H__259D2041_AC94_11D6_8156_5254AB37CDC9__INCLUDED_)
