// Rocket.h: interface for the CRocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROCKET_H__A54D3EE1_5561_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_ROCKET_H__A54D3EE1_5561_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "heightmap.h"
#include "particle.h"

struct FLAME
{
	float	    life;					// Particle Life
	float    	size;					// 
	VERTEX      pos;
};

#define P_MAXNUM 10

class CRocket  
{
public:
	CRocket();
	virtual ~CRocket();

	float    m_Speed;
	VERTEX   m_oldPos;
	VERTEX   m_CurPos;

	NORMAL   m_direction;
	float    m_rotX,m_rotY,m_rotZ;
	float    m_life;

	bool     InitRocket(VERTEX  startPos,float rotx,float roty ,NORMAL direction,unsigned int texid );
    void     UpdateRocket();
	void     DrawRocket();
	
	bool     m_bHit;
private:
	void     DrawExplosion();
	void     DrawSmokeTail();
	void     Flamethrow();
    CHeightmap   m_cHmap;
	CParticle    m_ptcExplosion;

    FLAME     m_particle[P_MAXNUM];
	int       listPos;
	unsigned int m_texid;
};

#endif // !defined(AFX_ROCKET_H__A54D3EE1_5561_11D6_812C_5254AB37CDC9__INCLUDED_)
