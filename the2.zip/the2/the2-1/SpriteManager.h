// SpritManager.h: interface for the CSpriteManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPRITMANAGER_H__6DB068E1_4A5D_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_SPRITMANAGER_H__6DB068E1_4A5D_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "sprite.h"
#include "smfloader.h"
#include "heightmap.h"

class CSpriteManager  
{
public:
	CSpriteManager();
	virtual ~CSpriteManager();
	bool   InitSpriteManager();

	bool   IsAllDeath();
	void   ResetAllSprite();
	void   UpdateSpriteManager();
    void   RenderSprites();
private:
	CHeightmap m_cHmap;

	CSMFLoader m_cSoldier;
	CSMFLoader m_cWeapon;

	int        m_numSoldier;
	CSprite   *m_cSprite;

    /////////////////develop mode
	bool             m_bFreeze;
    bool             m_bNoVisible;
	bool             m_bNoHarm;

};

#endif // !defined(AFX_SPRITMANAGER_H__6DB068E1_4A5D_11D6_812C_5254AB37CDC9__INCLUDED_)
