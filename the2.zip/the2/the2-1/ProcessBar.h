// ProcessBar.h: interface for the CProcessBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSBAR_H__0783BE61_A713_11D6_814D_5254AB37CDC9__INCLUDED_)
#define AFX_PROCESSBAR_H__0783BE61_A713_11D6_814D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphbutton.h"
class CProcessBar  : public CGraphButton
{
public:
	CProcessBar();
	virtual ~CProcessBar();
	void     SetProcessBar(RECT rect,int iMaxValue=100,int iMinValue=0,
		                   int curValue=0,bool bHorz=true,int style=0);
    void     SetMaxMinValue(int iMaxValue,int iMinValue);
	void     SetValue(int iValue);
	void     SetBlockWidth(int width);

 	void     RenderProcessBar();
	int      m_iValue;
	int      m_iMaxValue;
	int      m_iMinValue;

private:
    void     UpdateProcessBar();
	void     DrawBlock(RECT rect);

	bool     m_bHorz;
	int      m_iStyle;
	int      m_iBlockWidth;
};

#endif // !defined(AFX_PROCESSBAR_H__0783BE61_A713_11D6_814D_5254AB37CDC9__INCLUDED_)
