// ListBox.cpp: implementation of the CListBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ListBox.h"
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CListBox::CListBox()
{
	m_pEdit=NULL;
	m_bValueChanged=false;
}
CListBox::~CListBox()
{
	if(m_pEdit != NULL)
		delete [] m_pEdit;
}
void CListBox::SetListBox(RECT rect,int numItem,char *titleFile,int curItem)
{
	m_rect=rect;
	m_iMaxItem=numItem;
	m_pEdit=new CGraphEdit [m_iMaxItem];

	rect.left=m_rect.left+10;
	rect.right=m_rect.right-10;
	int height=rect.bottom-rect.top-4;
	height=height/m_iMaxItem;

	rect.top=m_rect.top+2;
	rect.bottom=rect.top+25;
	/////////////// get title string
	
	FILE *file;
	file = fopen(titleFile, "rt");
    char **str=NULL;
    if(file!=NULL)
	{
	    str=new char * [numItem];
 	    for(int i=0;i<m_iMaxItem;i++)
		{
			str[i]=new char [32];
			char c=fgetc(file);
			int pos=0;
			while(c!=EOF && c!='\n' && pos<29)
			{
                str[i][pos]=c;
				pos++;
				c=fgetc(file);
			}
			str[i][pos]=NULL;
		}
		fclose(file);
	}

	///////////////////////////////
	char title[32];
	for(int  i=0;i<m_iMaxItem;i++)
	{
		if(str!=NULL)
		{
			strcpy(title,str[i]);
			delete [] str[i];
		}
		else
		    strcpy(title,"");

		m_pEdit[i].SetEdit(rect,title,28);
		rect.top+=height;
		rect.bottom+=height;
		m_pEdit[i].SetActivateColor(0,0.4f,0);
	    m_pEdit[i].SetNormalColor(0,0.4f,0);
		if(m_pEdit[i].m_sText[0]!=NULL)m_pEdit[i].SetEnableEdit(false);
	}
	if(str!=NULL)delete [] str;
	m_iSelect=0;
	m_pEdit[0].SetActivateColor(0,0.6f,0);
	m_pEdit[0].SetNormalColor(0,0.6f,0);
	m_pEdit[0].SetRectangleColor(0,1,0);
}
void CListBox::SetSelect(int iItem)
{
	m_iSelect=iItem;
	if(m_iSelect>(m_iMaxItem-1))m_iSelect=0;
	if(m_iSelect<0)m_iSelect=0;
}
int  CListBox::GetSelect()
{
	return m_iSelect;
}
void CListBox::RenderListBox()
{   
	UpdateListBox();
	for(int i=0;i<m_iMaxItem;i++)
	{
		m_pEdit[i].RenderEdit();
		if(m_pEdit[i].m_sText[0]==NULL && !m_pEdit[i].IsEditting())
		{
			int x=(m_pEdit[i].m_rect.left+m_pEdit[i].m_rect.right)/2;
			int y=(m_pEdit[i].m_rect.top+m_pEdit[i].m_rect.bottom)/2;
			CImgText::PrintString(x,y,"New Player",true);
		}
	}

}
void  CListBox::UpdateListBox()
{
	int old=m_iSelect;
	for(int i=0;i<m_iMaxItem;i++)
	{
		if(m_pEdit[i].m_bSelected)
		{
			m_iSelect=i;
			m_pEdit[i].SetActivateColor(0,0.6f,0);
			m_pEdit[i].SetNormalColor(0,0.6f,0);
			m_pEdit[i].SetRectangleColor(0,1,0);
//			if(m_pEdit[i].m_sText[0]==NULL)m_pEdit[i].SetEnableEdit(true);
//			else m_pEdit[i].SetEnableEdit(false);
		}
	}

	if(old!=m_iSelect)
	{
		m_bValueChanged=true;
        m_pEdit[old].SetActivateColor(0,0.4f,0);
		m_pEdit[old].SetNormalColor(0,0.4f,0);
		m_pEdit[old].SetRectangleColor(0,0.6f,0);
	}
	else m_bValueChanged=false;
}
void CListBox::ClearCurrentItem()
{
	m_pEdit[m_iSelect].Clear();
}
void CListBox::SetCurrentItemEnableEdit()
{
	m_pEdit[m_iSelect].GetFocus();
}
void CListBox::SaveItemTitle(char *titleFile)
{
	FILE *file;
	file = fopen("script/players.txt", "wt");
    if(file!=NULL)
	{
 	    for(int i=0;i<m_iMaxItem;i++)
		{
			fputs(m_pEdit[i].m_sText,file);
			fputc('\n',file);
		}
		fclose(file);
	}
}