// Mission.h: interface for the CMission class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MISSION_H__5BE0DB82_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
#define AFX_MISSION_H__5BE0DB82_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "3de.h"
#include "sprite.h"
#include "Heightmap.h"
#include "Terrain.h"
#include "SkyBox.h"
#include "spritemanager.h"
#include "lensflare.h"
#include "buildingmanager.h"
#include "plantmanager.h"
#include "infopanel.h"
#include "AmbientSounds.h"
#include "AmmoManager.h"

class CMission  
{
public:
	CMission();
	virtual ~CMission();
	bool     LoadMission();
	void     RunMission();
	void     PauseMission();
	void     ResumeMission();
	void     DeleteMission();
private:
	void     MissionCompleted();
	void     RestartMission();
	void     RestoreFOVAngle();

	C3dE             *m_3dExplorer;
	CTerrain         *m_cTerrain;
	CSkyBox          *m_cSkyBox;
	CHeightmap       *m_cHmap;
	CInfoPanel       *m_cInfoPanel;
	CLensFlare       *m_cLensFlare;
	CSpriteManager   *m_cSprites;
    CBuildingManager *m_cBuilding;
	CPlantManager    *m_cPlant;
	CAmbientSounds   *m_pAmbientSound;
	CAmmoManager     *m_pAmmoManager;

    bool     m_bActivate;
	bool     m_bResource;
	unsigned int m_texTest;
};

#endif // !defined(AFX_MISSION_H__5BE0DB82_AF6C_11D6_815B_5254AB37CDC9__INCLUDED_)
