// Audio.h: interface for the CAudio class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUDIO_H__C59411DC_4F55_40AF_945A_7157AAE6F15B__INCLUDED_)
#define AFX_AUDIO_H__C59411DC_4F55_40AF_945A_7157AAE6F15B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <dmusicc.h>
#include <dmusici.h>
#include "audiodef.h"
#include "structdef.h"

class CAudioSegment  
{
public:

	LPDIRECTMUSICSEGMENT8  dmSegment;
	LPDIRECTCSound3DBUFFER ds3DBuffer;
	bool                   is3DSound;
	VERTEX                *vPosition;

	void Set3DPos(VERTEX *pos);
	void Set3DDistances(float minDistance, float maxDistance);	
	void Shutdown(void);

	CAudioSegment() : dmSegment(NULL),  ds3DBuffer(NULL), 
		              is3DSound(false) , vPosition(NULL)
		{	}

	~CAudioSegment() 
		{	}
};

class CAudio  
{
public:
    CAudio();
	virtual ~CAudio();

	static void DeleteSound(unsigned int NumOfSound);
	static bool CreateSound(unsigned int NumOfSound, char* filename, bool is3DSound);

	static void Play(unsigned int NumOfSound,DWORD numRepeats, bool bPrimary ,bool bCheckOlyOne=true);
    static bool CheckSoundPlaying(unsigned int NumOfSound);
    static int  GetSoundState(unsigned int NumOfSound);
	static void Stop(unsigned int NumOfSound);
	static void StopAll();
	static void SetVolume(int fVolume);
	static bool SetAudioActive(bool bActiveAudio);
	static bool IsAudioActive();
	static bool IsAudioEnable();
	
	static void SetSoundPos(unsigned int NumOfSound,VERTEX *pos);
	static void SetListenerPos(VERTEX *pos,float roty);
	static void SetSoundRolloff(float rolloff);

	static VERTEX GetTransformSoundPos(VERTEX *vSoundPos);

//private:
	static bool InitAudio();	
    static void ReleaseAudio(void);

	static LPDIRECTMUSICLOADER8	     dmLoader;			// the loader
	static LPDIRECTMUSICPERFORMANCE8 dmPerformance;	// the performance
	static LPDIRECTMUSICAUDIOPATH    dm3DAudioPath;	// the audiopath
    //////////////////////////////////
	static CAudioSegment  *pSound;
	static char           *pSoundState;
	static VERTEX          vListenerPos;
	static float           froty;
	static bool            bActive;
	static bool            bEnable;
	static int             m_numUser;
};

#endif // !defined(AFX_AUDIO_H__C59411DC_4F55_40AF_945A_7157AAE6F15B__INCLUDED_)
