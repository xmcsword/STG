// Rifle.cpp: implementation of the CRifle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Rifle.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRifle::CRifle()
{
	m_bHit=false;
}

CRifle::~CRifle()
{
}
bool CRifle::LunchBullet(int id,VERTEX  startPos,float rotx,float roty,NORMAL direction)
{
	m_id=id;
    m_bulletPos=startPos;
	m_rotX=rotx;
	m_rotY=roty;
    m_direction = direction;
	CalcDestinationPos();
  
	if(m_bHit)
	{
	    m_bltParticle.InitParticle(EXPLOSION_P,startPos);
 	}

    ///////////////Draw Bullet Track//////////////////////
    glDisable(GL_TEXTURE_2D);
	glColor3f(0.6f,0.7f,0.75f);
	glBegin(GL_LINES);
	    glVertex3f(startPos.xpos,    startPos.ypos,    startPos.zpos);
	    glVertex3f(m_bulletPos.xpos, m_bulletPos.ypos, m_bulletPos.zpos);
/*
	    glVertex3f(startPos.xpos,    startPos.ypos,    startPos.zpos);
	    glVertex3f(m_bulletPos.xpos+2, m_bulletPos.ypos+2, m_bulletPos.zpos);

	    glVertex3f(startPos.xpos,    startPos.ypos,    startPos.zpos);
	    glVertex3f(m_bulletPos.xpos, m_bulletPos.ypos+5, m_bulletPos.zpos+2);

	    glVertex3f(startPos.xpos,    startPos.ypos,    startPos.zpos);
	    glVertex3f(m_bulletPos.xpos, m_bulletPos.ypos-6, m_bulletPos.zpos);
 */  glEnd();
    //// 
	return true;
}

void  CRifle::CalcDestinationPos()
{
	
	float deltaH=8;
	float step=1;
    m_bHit=false;
	int   count=0;
	while(deltaH >0 && count<1000)
	{   
//		step=deltaH*0.5f;
        m_bulletPos.xpos+=m_direction.nx*step;
        m_bulletPos.ypos+=m_direction.ny*step;
        m_bulletPos.zpos+=m_direction.nz*step;

		deltaH=m_bulletPos.ypos-m_cHmap.GetHeight(&m_bulletPos);
		count++;
	}
	if(deltaH<0)
	{
		m_bHit=true;
	}
}
void CRifle::DrawRifleShot()
{
	if(!m_bHit)return;
    glPushMatrix();	
	glTranslatef(m_bulletPos.xpos,m_bulletPos.ypos,m_bulletPos.zpos);
	glRotatef(*m_cHmap.m_pViewRotY,  0.0f,1.0f,0.0f);
	glRotatef(-*m_cHmap.m_pViewRotX,  1.0f,0.0f,0.0f);

        m_bltParticle.DrawParticles(m_bulletPos);

    glPopMatrix();


}









