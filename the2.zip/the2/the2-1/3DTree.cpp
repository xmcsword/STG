// 3DTree.cpp: implementation of the C3DTree class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "3DTree.h"
#include "Texmanager.h"
#include "math.h"
#include "heightmap.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DTree::C3DTree()
{
	m_szTree=1;
    m_height=m_szTree*60;
}

C3DTree::~C3DTree()
{

}
bool C3DTree::Init3DTree(int type,float size)
{
	 m_szTree = size;
	 m_height=m_szTree*60;
	 m_type=type;

	 CTexManager cTexManager;
	 //////////////read blend skin texture
	 if(type==1)
	 {
         texTreeBody=cTexManager.GetTextureID(TEX_TREEBODY_0);
		 texBranch=cTexManager.GetTextureID(TEX_BRANCH_0);
	 }
	 else
	 {
         texTreeBody=cTexManager.GetTextureID(TEX_TREEBODY_1);
		 texBranch=cTexManager.GetTextureID(TEX_BRANCH_1);
	 }
     return true;
}
void C3DTree::Render3DTree(VERTEX pos)
{
    glPushMatrix();	
	glTranslatef(pos.xpos,pos.ypos,pos.zpos);

    Draw3DTree();

    glPopMatrix();

	if(m_type==1)
		CHeightmap::m_numTriangles += 100 ;
	else
		CHeightmap::m_numTriangles += 68 ;
}
void C3DTree::Draw3DTree()
{
    ///////////////////////////////////
	//////////Draw Tree Body
    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND);
 	glBindTexture(GL_TEXTURE_2D, texTreeBody);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUAD_STRIP);
	    for(float i=0;i<8;i++)
		{
	        glTexCoord2f(i*0.3f,0);    
			glVertex3f(-m_szTree*sinf(i*45*0.0174533f),0,-m_szTree*cosf(i*45*0.0174533f));
	        glTexCoord2f(i*0.3f+0.3f,8);    
			glVertex3f(-m_szTree*sinf(i*45*0.0174533f)*0.1f,m_height,-m_szTree*cosf(i*45*0.0174533f)*0.1f);
		}
	    glTexCoord2f(2.4f,0); 
	    glVertex3f(0,0,-m_szTree);
	    glTexCoord2f(2.7f,8);    
		glVertex3f(0,m_height,-m_szTree*0.1f);
    glEnd();

    //////////////////////////////////////////
	///////////////// Draw Branch ////////////
   	glAlphaFunc(GL_GREATER,0.10f);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
    glEnable(GL_ALPHA_TEST);

 	glBindTexture(GL_TEXTURE_2D, texBranch);
	glEnable(GL_TEXTURE_2D);
    
	if(m_type==1)
		DrawYellowTree();
	else
		DrawGreenTree();

	////////////////////////////////////

    glDisable(GL_ALPHA_TEST);
	glDisable(GL_BLEND); 
}
void C3DTree::DrawYellowTree()
{

    //////////////////////////////////
    glPushMatrix();	
    //////////////////////////////////
	glTranslatef(0,m_height*0.24f,0);
	glRotatef(0,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f,m_height*0.2f);

	glTranslatef(0,m_height*0.02f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.31f,m_height*0.31f);
  
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(70,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.32f,m_height*0.32f);
 
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(200,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.32f,m_height*0.32f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.31f,m_height*0.31f);

 
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.31f,m_height*0.31f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.31f,m_height*0.31f);
 
	glTranslatef(0,m_height*0.031f,0);
	glRotatef(190,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f,m_height*0.3f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(70,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.29f,m_height*0.29f);
/*
	glTranslatef(0,m_height*0.05f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.31f,m_height*0.31f);
  
	glTranslatef(0,m_height*0.032f,0);
	glRotatef(110,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.29f,m_height*0.29f);
 
	glTranslatef(0,m_height*0.032f,0);
	glRotatef(70,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.28f,m_height*0.28f);
*/
	glTranslatef(0,m_height*0.041f,0);
	glRotatef(190,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.26f,m_height*0.26f);

 
	glTranslatef(0,m_height*0.031f,0);
	glRotatef(110,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.24f,m_height*0.24f);

	glTranslatef(0,m_height*0.031f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.23f,m_height*0.23f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(200,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.22f,m_height*0.22f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.21f,m_height*0.21f);

 
	glTranslatef(0,m_height*0.04f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.20f,m_height*0.20f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(200,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.19f,m_height*0.19f);

	glTranslatef(0,m_height*0.03f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.18f,m_height*0.18f);

 
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.17f,m_height*0.17f);
/*
	glTranslatef(0,m_height*0.03f,0);
	glRotatef(160,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.16f,m_height*0.16f);
 
	glTranslatef(0,m_height*0.032f,0);
	glRotatef(190,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.15f,m_height*0.15f);

	glTranslatef(0,m_height*0.031f,0);
	glRotatef(100,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.14f,m_height*0.14f);
  */
	glTranslatef(0,m_height*0.051f,0);
	glRotatef(190,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.13f,m_height*0.13f);

	glTranslatef(0,m_height*0.032f,0);
	glRotatef(120,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.12f,m_height*0.12f);

	////////////top
	glTranslatef(0,-m_height*0.05f,0);
	DrawTop(m_height*0.2f,m_height*0.3f);
   
	////////////////////////////
	glPopMatrix();
	////////////////////////////



}
void C3DTree::DrawGreenTree()
{
    //////////////////////////////////
    glPushMatrix();	
    //////////////////////////////////
	glTranslatef(0,m_height*0.3f,0);
	glRotatef(0,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f,m_height*0.2f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(170,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.25f,m_height*0.25f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.3f,m_height*0.3f);
  
	glTranslatef(0,m_height*0.04f,0);
	glRotatef(130,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.32f,m_height*0.32f);
 
	glTranslatef(0,m_height*0.045f,0);
	glRotatef(200,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.32f,m_height*0.32f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.28f,m_height*0.28f);

 
	glTranslatef(0,m_height*0.045f,0);
	glRotatef(150,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.25f,m_height*0.25f);

	glTranslatef(0,m_height*0.05f,0);
	glRotatef(80,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.23f,m_height*0.23f);
 
	glTranslatef(0,m_height*0.05f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f,m_height*0.2f);
 
	glTranslatef(0,m_height*0.05f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.2f,m_height*0.2f);
 
	glTranslatef(0,m_height*0.04f,0);
	glRotatef(90,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.16f,m_height*0.16f);

	glTranslatef(0,m_height*0.04f,0);
	glRotatef(180,  0.0f,1.0f,0.0f);
    DrawBranch(m_height*0.15f,m_height*0.15f);

	////////////top

	DrawTop(m_height*0.3f,m_height*0.3f);
   
	////////////////////////////
	glPopMatrix();
	////////////////////////////
}
void C3DTree::DrawBranch(float width,float height)
{
	glBegin(GL_QUADS);
	    ////////// face 1
	    glTexCoord2f(1,0);
	    glVertex3f(0,0,0);

	    glTexCoord2f(0,0);
	    glVertex3f(width,0,0);

	    glTexCoord2f(0,1);
	    glVertex3f(width,height,0);

	    glTexCoord2f(1,1);
	    glVertex3f(0,height,0);


	    ////////// face 2
	    glTexCoord2f(1,0);
	    glVertex3f(0,0,0);

	    glTexCoord2f(0,0);
	    glVertex3f(width*0.5f,height*0.5f,0.7071f*width);

	    glTexCoord2f(0,1);
	    glVertex3f(width,height,0);

	    glTexCoord2f(1,1);
	    glVertex3f(width*0.5f,height*0.5f,-0.7071f*width);

	glEnd();
}
void C3DTree::DrawTop(float width,float height)
{
	glBegin(GL_QUADS);
	    ////////// face 1
	    glTexCoord2f(1,0);
	    glVertex3f(0,0,0);

	    glTexCoord2f(0,0);
	    glVertex3f(0.7071f*width,0.5f*height,0);

	    glTexCoord2f(0,1);
	    glVertex3f(0,height,0);

	    glTexCoord2f(1,1);
	    glVertex3f(-0.7071f*width,0.5f*height,0);

	    ////////// face 2
	    glTexCoord2f(1,0);
	    glVertex3f(0,0,0);

	    glTexCoord2f(0,0);
	    glVertex3f(0,height*0.5f,0.7071f*width);

	    glTexCoord2f(0,1);
	    glVertex3f(0,height,0);

	    glTexCoord2f(1,1);
	    glVertex3f(0,height*0.5f,-0.7071f*width);

	glEnd();
}
