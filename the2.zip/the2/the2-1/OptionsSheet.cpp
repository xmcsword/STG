// OptionsSheet.cpp: implementation of the COptionsSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OptionsSheet.h"
#include "audio.h"
#include "mediaplayer.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COptionsSheet::COptionsSheet()
{
	m_iFather=0;
}
COptionsSheet::~COptionsSheet()
{
}
bool COptionsSheet::InitSheet()
{
	RECT rect;
	////////////// Init 3 Button
	rect.top=555;
	rect.bottom=585;
	for(int i=0;i<OP_ITEM_NUM;i++)
	{
		rect.left=50+i*250;
		rect.right=250+i*250;
	    m_cButton[i].SetButtonRect(rect);
	}
    m_cButton[0].SetButtonText("Back");
	m_cButton[1].SetButtonText("Default");
	m_cButton[2].SetButtonText("Accept");

	//////////////////////////////////////////
	//////////////////// Init bars
	int x=220,y=95;
	int dy=32;

	char **str;
	str=new char* [4];
	for(int j=0;j<4;j++)
		str[j]=new char [32];
	strcpy(str[0],"640 x 480");
	strcpy(str[1],"800 x 600");
	strcpy(str[2],"1024 x 768");
	strcpy(str[3],"1280 x 960");

	//////////    m_cResolutionBar
	rect.top=y;
	rect.bottom=y+18;
	rect.left=x;
	rect.right=x+170;
	m_cResolutionBar.SetChangeBar(rect,str,4,1);
	//////////    m_cColorDepthBar
	rect.top=y+dy;
	rect.bottom=y+dy+18;
	strcpy(str[0],"16");
	strcpy(str[1],"32");
	m_cColorDepthBar.SetChangeBar(rect,str,2,0);
	//////////    m_cModelDetailBar
	rect.top=y+dy*3;
	rect.bottom=y+dy*3+18;
	strcpy(str[0],"Low");
	strcpy(str[1],"Medium");
	strcpy(str[2],"Height");
	m_cModelDetailBar.SetChangeBar(rect,str,3,0);
	//////////    m_cTexQualityBar
	rect.top=y+dy*4;
	rect.bottom=y+dy*4+18;
	m_cTexQualityBar.SetChangeBar(rect,str,3,2);

	//////// m_cForestDensityBar
	rect.top=y+dy*6;
	rect.bottom=y+dy*6+18;
	m_cForestDensityBar.SetChangeBar(rect,str,3,0);

	//////////    m_cFontTypeBar
	rect.top=y+dy*8;
	rect.bottom=y+dy*8+18;
	strcpy(str[0],"Elegence");
	strcpy(str[1],"Strong");
	m_cFontTypeBar.SetChangeBar(rect,str,2,0);

	//////////////////////////////////////
    ///////////////////// init Scroll bar
	//////// m_cBrightnessBar
	rect.top=y+dy*2;
	rect.bottom=y+dy*2+18;
	m_cBrightnessBar.SetScrollBar(rect,true,60,-30,0);
	//////// m_cVisiblebDistBar
	rect.top=y+dy*5;
	rect.bottom=y+dy*5+18;
	m_cVisiblebDistBar.SetScrollBar(rect,true,80,30,6);
	//////// m_cFogDensityBar
	rect.top=y+dy*7;
	rect.bottom=y+dy*7+18;
	m_cFogDensityBar.SetScrollBar(rect,true,80,30,1);
    ///////////////////audio
	///////////////music check box
	y=440;
	rect.top=y;
	rect.bottom=y+18;
    rect.right=rect.left+18;
    m_cMusicCheckBox.SetCheckBox(rect);
	///////////////sound check box
	rect.left=315;
	rect.right=rect.left+18;
	m_cSoundCheckBox.SetCheckBox(rect);
    ///////////////// music volume
	rect.left=x;
	rect.right=x+170;
	rect.top=y+dy;
	rect.bottom=y+dy+18;
	m_cMusicVolumeBar.SetScrollBar(rect,true,100,0,70);
    ////////////////  sound volume
	rect.top=y+dy*2;
	rect.bottom=y+dy*2+18;
	m_cSoundVolumeBar.SetScrollBar(rect,true,100,0,70);
	///////////////////////////////////mouse
    /////////////   m_cMouseInvert;
    y=440;
	rect.left=670;
	rect.right=770;	
	rect.top=y;
	rect.bottom=y+18;
	strcpy(str[0],"No");
	strcpy(str[1],"Yes");
	m_cMouseInvert.SetChangeBar(rect,str,2,0);
	////////////   m_cMouseSensitivity
	rect.left=610;
	rect.right=770;	
	rect.top=y+dy;
	rect.bottom=y+dy+18;
	m_cMouseSensitivity.SetScrollBar(rect,true,100,20,16);
 
	/////////////////keyboard setting
	///////////////// m_cKeySetting
	rect.left=450;
	rect.right=770;	
	rect.top=95;
	rect.bottom=365;
	m_cKeySetting.SetCtrlSetBox(rect);

	////////////////////////////////////////////
	for(j=0;j<4;j++)
		delete [] str[j];
	delete [] str;
    ///////////////////////////////////////////////
	LoadSetting();
	/////////////////////////////////////////
	m_iSelect=-1;
    m_bActive=false;
	return true;
}
int COptionsSheet::RenderSheet()
{
	if(!m_bActive)return -1;

	DrawBackGround();

	for(int i=0;i<OP_ITEM_NUM;i++)
	{
	    m_cButton[i].RenderButton();
	}
	/////////////////////////////////////
	for(i=0;i<OP_ITEM_NUM;i++)
	{
	    if(m_cButton[i].m_bSelected)
		{
			m_cButton[i].m_bSelected=false;
			m_iSelect=i;
		}
	} 
	UpdateOptionsSheet();
	
    ////////// video
	m_cResolutionBar.RenderChangeBar();
	m_cColorDepthBar.RenderChangeBar();

	m_cModelDetailBar.RenderChangeBar();
	m_cTexQualityBar.RenderChangeBar();
	m_cFontTypeBar.RenderChangeBar();

	m_cBrightnessBar.RenderScrollBar();
	m_cVisiblebDistBar.RenderScrollBar();
	m_cForestDensityBar.RenderChangeBar();
	m_cFogDensityBar.RenderScrollBar();

	////////// audio
	m_cSoundCheckBox.RenderCheckBox();
	m_cMusicCheckBox.RenderCheckBox();
	m_cMusicVolumeBar.RenderScrollBar();
	m_cSoundVolumeBar.RenderScrollBar(); 

   	/////////// mouse
	m_cMouseInvert.RenderChangeBar();
	m_cMouseSensitivity.RenderScrollBar();

	//////////  Keyboard
	m_cKeySetting.RenderCtrlSetBox();

    ///////////////////////////////////
	return -1;
}
void COptionsSheet::UpdateOptionsSheet()
{
	if(CInput::m_keys[VK_ESCAPE])
	{
		CInput::m_keys[VK_ESCAPE]=false;
		m_iSelect=0;
		return ;
	}
	if(CInput::m_keys[13])//enter key
	{
		CInput::m_keys[13]=false;
		m_iSelect=2;
		return ;
	}

	if(m_cFontTypeBar.m_bValueChanged)
	{
        CImgText cText;
	    cText.SetFontType(m_cFontTypeBar.GetSelected());
	}
	if(m_cMusicCheckBox.m_bValueChanged)
	{
        m_cMusicVolumeBar.SetEnable(m_cMusicCheckBox.m_bChecked);		
		if(m_cMusicCheckBox.m_bChecked)
		{
			CMediaPlayer::SetMediaActive(true);
			CMediaPlayer::Play();
		}
		else
		{
			CMediaPlayer::SetMediaActive(false);
			CMediaPlayer::Pause();
		}
	}
	if(m_cMusicVolumeBar.m_bValueChanged)
	{
		CMediaPlayer::SetVolume(m_cMusicVolumeBar.GetValue());
	}
	if(m_cSoundCheckBox.m_bValueChanged)
	{
        m_cSoundVolumeBar.SetEnable(m_cSoundCheckBox.m_bChecked);		
		if(m_cSoundCheckBox.m_bChecked)
			CAudio::SetAudioActive(true);
		else
		{
			CAudio::SetAudioActive(false);
			CAudio::StopAll();
		}
	}
	if(m_cSoundVolumeBar.m_bValueChanged)
	{
		CAudio::SetVolume(m_cSoundVolumeBar.GetValue());
		CAudio::Play(MENU_SOUND_TEST,1,true);
	}
	if(m_cBrightnessBar.m_bValueChanged)
	{
		CGameSetting::m_iGamma=m_cBrightnessBar.GetValue();
	}
    if(m_iSelect==1)
	{
		m_iSelect=-1;
		CGameSetting cGameSetting;
        cGameSetting.LoadDefaultSetting();
		LoadSetting();
	}
    if(m_iSelect==2)
	{
		SaveSetting();
	}
}

void  COptionsSheet::LoadSetting()
{
	CGameSetting cGameSetting;
	///////////////////// Load Resolution
    if(cGameSetting.m_iScrWidth==640) m_cResolutionBar.SetItem(0);
    if(cGameSetting.m_iScrWidth==800) m_cResolutionBar.SetItem(1);
    if(cGameSetting.m_iScrWidth==1024)m_cResolutionBar.SetItem(2);
    if(cGameSetting.m_iScrWidth==1280)m_cResolutionBar.SetItem(3);
    if(cGameSetting.m_iColorDepth==16) m_cColorDepthBar.SetItem(0);
    if(cGameSetting.m_iColorDepth==32) m_cColorDepthBar.SetItem(1);

	//////////////////// Load Render
    m_cBrightnessBar.SetValue(cGameSetting.m_iGamma);

    if(cGameSetting.m_iModelDetail==LOW   ) m_cModelDetailBar.SetItem(0);
    if(cGameSetting.m_iModelDetail==MEDIUM) m_cModelDetailBar.SetItem(1);
    if(cGameSetting.m_iModelDetail==HEIGHT) m_cModelDetailBar.SetItem(2);

    if(cGameSetting.m_iTexQuality==LOW   ) m_cTexQualityBar.SetItem(0);
    if(cGameSetting.m_iTexQuality==MEDIUM) m_cTexQualityBar.SetItem(1);
    if(cGameSetting.m_iTexQuality==HEIGHT) m_cTexQualityBar.SetItem(2);

    m_cVisiblebDistBar.SetValue(cGameSetting.m_iVisibleDist);

    if(cGameSetting.m_iForestDensity==LOW   ) m_cForestDensityBar.SetItem(0);
    if(cGameSetting.m_iForestDensity==MEDIUM) m_cForestDensityBar.SetItem(1);
    if(cGameSetting.m_iForestDensity==HEIGHT) m_cForestDensityBar.SetItem(2);

    m_cFogDensityBar.SetValue(cGameSetting.m_iFogDensity);

    ///////////////////  Load audio
	if(cGameSetting.m_bMusic)
	{
		m_cMusicCheckBox.SetState(true);
		m_cMusicVolumeBar.SetEnable(true);
		CMediaPlayer::SetMediaActive(true);
		CMediaPlayer::Play();
	}
	else 
	{
		m_cMusicCheckBox.SetState(false);
		m_cMusicVolumeBar.SetEnable(false);
		CMediaPlayer::SetMediaActive(false);
		CMediaPlayer::Pause();
	}
	if(cGameSetting.m_bSound)
	{
		m_cSoundCheckBox.SetState(true);
		m_cSoundVolumeBar.SetEnable(true);
		CAudio::SetAudioActive(true);
	}
	else
	{
		m_cSoundCheckBox.SetState(false);
		m_cSoundVolumeBar.SetEnable(false);
		CAudio::SetAudioActive(false);
	}

    m_cMusicVolumeBar.SetValue(cGameSetting.m_iMusicVolume);
	CMediaPlayer::SetVolume(cGameSetting.m_iMusicVolume);
    m_cSoundVolumeBar.SetValue(cGameSetting.m_iSoundVolume);
	CAudio::SetVolume(cGameSetting.m_iSoundVolume);

	if(!cGameSetting.m_bAudioEnable)m_cMusicCheckBox.SetEnable(false);
	if(!cGameSetting.m_bAudioEnable)m_cSoundCheckBox.SetEnable(false);
	if(!cGameSetting.m_bAudioEnable)m_cMusicVolumeBar.SetEnable(false);
	if(!cGameSetting.m_bAudioEnable)m_cSoundVolumeBar.SetEnable(false);
	///////////////////////////////////mouse
    if(cGameSetting.m_bMouseInvert==0) m_cMouseInvert.SetItem(0);
    if(cGameSetting.m_bMouseInvert==1) m_cMouseInvert.SetItem(1);
    m_cMouseSensitivity.SetValue(cGameSetting.m_iMouseSens);
	////////////////////////////////// Keyboard
    m_cKeySetting.LoadSetting();

}
void  COptionsSheet::SaveSetting()
{
	CGameSetting cGameSetting;
	////////////// Save Resolution
	int select=m_cResolutionBar.GetSelected();
    if(select==0)cGameSetting.m_iScrWidth=640;
    if(select==1)cGameSetting.m_iScrWidth=800;
    if(select==2)cGameSetting.m_iScrWidth=1024;
    if(select==3)cGameSetting.m_iScrWidth=1280;

	select=m_cColorDepthBar.GetSelected();
    if(select==0)cGameSetting.m_iColorDepth=16;
    if(select==1)cGameSetting.m_iColorDepth=32;


	//////////    save Render
    cGameSetting.m_iGamma=m_cBrightnessBar.GetValue();

	select=m_cModelDetailBar.GetSelected();
    if(select==0)cGameSetting.m_iModelDetail=LOW;
    if(select==1)cGameSetting.m_iModelDetail=MEDIUM;
    if(select==2)cGameSetting.m_iModelDetail=HEIGHT;

	select=m_cTexQualityBar.GetSelected();
    if(select==0)cGameSetting.m_iTexQuality=LOW;
    if(select==1)cGameSetting.m_iTexQuality=MEDIUM;
    if(select==2)cGameSetting.m_iTexQuality=HEIGHT;

    cGameSetting.m_iVisibleDist=m_cVisiblebDistBar.GetValue();

	select=m_cForestDensityBar.GetSelected();
    if(select==0)cGameSetting.m_iForestDensity=LOW;
    if(select==1)cGameSetting.m_iForestDensity=MEDIUM;
    if(select==2)cGameSetting.m_iForestDensity=HEIGHT;

    cGameSetting.m_iFogDensity=m_cFogDensityBar.GetValue();


    ///////////////////   save  audio
    if(m_cMusicCheckBox.m_bChecked)cGameSetting.m_bMusic=true;
	else cGameSetting.m_bMusic=false;

    if(m_cSoundCheckBox.m_bChecked)cGameSetting.m_bSound=true;
	else cGameSetting.m_bSound=false;

	cGameSetting.m_iMusicVolume=m_cMusicVolumeBar.GetValue();

	cGameSetting.m_iSoundVolume=m_cSoundVolumeBar.GetValue();

	/////////////////  save mouse
    /////////////   m_cMouseInvert;
	select=m_cMouseInvert.GetSelected();
    if(select==0)cGameSetting.m_bMouseInvert=false;
    if(select==1)cGameSetting.m_bMouseInvert=true;

	cGameSetting.m_iMouseSens=m_cMouseSensitivity.GetValue();

	//////////////////// Keyboard
	m_cKeySetting.SaveSetting();

    ///////////////////////////////////////////////
	/////// Save to config.ini
    cGameSetting.SaveSetting();
	////////////////////////////////////////
}

void  COptionsSheet::DrawBackGround()
{
	CGameSetting cGameSetting;
	///////////////////title and rectangle
	CImgText cText;
	glColor3f(1,1,0);
	cText.PrintString(20,14,"Game Setting",0,24,0);

	glColor3f(0,0.7f,0);
	
    ////////////////
	int x0=10,x1=800-x0;
	int y0=50,y1=540;
    DrawRectangle( x0, x1, y0, y1);  //  All
    x0=13;  x1=420;
	y0=53;  y1=392;
    DrawRectangle( x0, x1, y0, y1);  // left top
	y0=395;  y1=537;
    DrawRectangle( x0, x1, y0, y1);  // left bottom
    x0=423;  x1=787;
	y0=53;  y1=392;
    DrawRectangle( x0, x1, y0, y1);  // right top
	y0=395;  y1=537;
    DrawRectangle( x0, x1, y0, y1);  // right bottom
	////////////////// video
	glColor3f(0.8f,0.8f,0);
	cText.PrintString(20,60,"Video Setting",0,20,0);
	glColor3f(0,1,0);
	int x=30,y=95;
	int dy=32;
	cText.PrintString(x,y + 0,  "Resolution",0,16,0);
	cText.PrintString(x,y + dy*1,"Color Depth",0,16,0);
	cText.PrintString(x,y + dy*2,"Brightness",0,16,0);
	cText.PrintString(x,y + dy*3,"Model Detail",0,16,0);
	cText.PrintString(x,y + dy*4,"Texture Quality",0,16,0);
	cText.PrintString(x,y + dy*5,"Visible Distance",0,16,0);
	cText.PrintString(x,y + dy*6,"Forest Density",0,16,0);
	cText.PrintString(x,y + dy*7,"Fog Density",0,16,0);
	cText.PrintString(x,y + dy*8,"Font Type",0,16,0);
    ///////////////// audio
	if(!cGameSetting.m_bAudioEnable)glColor3f(0.5f,0.5f,0.5f);
	else  glColor3f(0.8f,0.8f,0);
	cText.PrintString(20,405,"Audio Setting",0,20,0);
	if(!cGameSetting.m_bAudioEnable)glColor3f(0.5f,0.5f,0.5f);
	else  glColor3f(0,1,0);

    y=440;
	cText.PrintString(x,y + 0,       "Audio Select",0,16,0);
	cText.PrintString(x+215,y + 0,   "Music",0,16,0);
	cText.PrintString(x+307,y + 0,   "Sound",0,16,0);
	cText.PrintString(x,y + dy,      "Music Volume",0,16,0);
	cText.PrintString(x,y + dy*2,    "Sound Volume",0,16,0);
	
	if(!cGameSetting.m_bAudioEnable)
	{
		glColor3f(1,0,0);
		cText.PrintString(220,405,"Audio Inavlid",0,20,0);
	}

    //////////////// Mouse

	glColor3f(0.8f,0.8f,0);
	cText.PrintString(440,400,"Mouse Setting",0,20,0);
	glColor3f(0,1,0);
	x=450;
    y=440;
	cText.PrintString(x,y + 0,   "Invert",0,16,0);
	cText.PrintString(x,y + dy*1,"Sensitivity",0,16,0);

	/////////////// Keyboard
	glColor3f(0.8f,0.8f,0);
	cText.PrintString(440,60,"Keyboard Setting",0,20,0);


	////////////////
	glColor3f(1,1,1);
}
void COptionsSheet::DrawRectangle(int x0,int x1,int y0,int y1)
{
	glBegin(GL_LINE_LOOP);
		glVertex3i(x0-400,300-y0,-520);
		glVertex3i(x1-400,300-y0,-520);
		glVertex3i(x1-400,300-y1,-520);
		glVertex3i(x0-400,300-y1,-520);
    glEnd();
}