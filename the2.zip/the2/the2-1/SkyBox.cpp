// SkyBox.cpp: implementation of the CSkyBox class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "texmanager.h"
#include "SkyBox.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSkyBox::CSkyBox()
{
}
CSkyBox::~CSkyBox()
{
}
bool CSkyBox::InitSkyBox(int XLenght, int YLenght,int ZLenght,
				 int CenterX,int CenterY,int CenterZ)
{
	m_XLength=XLenght;
	m_YLength=YLenght;
	m_ZLength=ZLenght;
	m_CenterX=CenterX;
	m_CenterY=CenterY;
	m_CenterZ=CenterZ;

	CTexManager cTexManager;
	texSky[0]=cTexManager.GetTextureID(TEX_SKY_0);
	texSky[1]=cTexManager.GetTextureID(TEX_SKY_1);
	texSky[2]=cTexManager.GetTextureID(TEX_SKY_2);
	texSky[3]=cTexManager.GetTextureID(TEX_SKY_3);
	texSky[4]=cTexManager.GetTextureID(TEX_SKY_4);
	return true;
}
void CSkyBox::DrawSkyBox()
{
	int lx,ly,lz,cx,cy,cz;
	lx=m_XLength;
	ly=m_YLength;
	lz=m_ZLength;
	cx=m_CenterX;
	cy=m_CenterY;
	cz=m_CenterZ;

	float btmy=0.0f;//This variable indicate how much texture should be cut from 0 to btmy
//  glDisable(GL_FOG); 
	////////front
 	glBindTexture(GL_TEXTURE_2D, texSky[0]);
   	glEnable(GL_TEXTURE_2D); 
  		glBegin(GL_QUADS);
	            glTexCoord2f(0,btmy);
			    glVertex3i(-lx+cx, cy,   -lz+cz);

    	        glTexCoord2f(1,btmy);
			    glVertex3i(lx+cx, cy,   -lz+cz);

	            glTexCoord2f(1,1);
			    glVertex3i(lx+cx, ly+cy,   -lz+cz);

	            glTexCoord2f(0,1);
			    glVertex3i(-lx+cx, ly+cy,    -lz+cz);
            glEnd();
	glDisable(GL_TEXTURE_2D); 
	///     ////////////////sky1
	/////////////////right
	glBindTexture(GL_TEXTURE_2D, texSky[1]);
   	glEnable(GL_TEXTURE_2D); 
  
		glBegin(GL_QUADS);
	            glTexCoord2f(0,btmy);
			    glVertex3i(lx+cx, cy,    -lz+cz);

    	        glTexCoord2f(1,btmy);
			    glVertex3i(lx+cx, cy,    lz+cz);

	            glTexCoord2f(1,1);
			    glVertex3i(lx+cx, ly+cy,    lz+cz);

	            glTexCoord2f(0,1);
			    glVertex3i(lx+cx, ly+cy,    -lz+cz);
            glEnd();
	glDisable(GL_TEXTURE_2D); 
	///     ////////////////sky2
	//////////////back
	glBindTexture(GL_TEXTURE_2D, texSky[2]);
   	glEnable(GL_TEXTURE_2D); 
 
		glBegin(GL_QUADS);
	            glTexCoord2f(0,btmy);
			    glVertex3i(lx+cx, cy,    lz+cz);

    	        glTexCoord2f(1,btmy);
			    glVertex3i(-lx+cx, cy,    lz+cz);

	            glTexCoord2f(1,1);
			    glVertex3i(-lx+cx, ly+cy,    lz+cz);

	            glTexCoord2f(0,1);
			    glVertex3i(lx+cx, ly+cy,    lz+cz);
            glEnd();
	glDisable(GL_TEXTURE_2D); 
	///     ////////////////sky3
	////////////////left
	glBindTexture(GL_TEXTURE_2D, texSky[3]);
   	glEnable(GL_TEXTURE_2D); 
	       glBegin(GL_QUADS);
	            glTexCoord2f(0,btmy);
			    glVertex3i(-lx+cx, cy,    lz+cz);

    	        glTexCoord2f(1,btmy);
			    glVertex3i(-lx+cx, cy,    -lz+cz);

	            glTexCoord2f(1,1);
			    glVertex3i(-lx+cx, ly+cy,    -lz+cz);

	            glTexCoord2f(0,1);
			    glVertex3i(-lx+cx, ly+cy,    lz+cz);
            glEnd();
	glDisable(GL_TEXTURE_2D); 
	///     ////////////////sky4
	/////////////up
	glBindTexture(GL_TEXTURE_2D, texSky[4]);
   	glEnable(GL_TEXTURE_2D); 

		glBegin(GL_QUADS);
	            glTexCoord2f(0,0);
			    glVertex3i(-lx+cx, ly+cy,    -lz+cz);

    	        glTexCoord2f(1,0);
			    glVertex3i(lx+cx,ly+cy,    -lz+cz);

	            glTexCoord2f(1,1);
			    glVertex3i(lx+cx, ly+cy,    lz+cz);

	            glTexCoord2f(0,1);
			    glVertex3i(-lx+cx, ly+cy,    lz+cz);
            glEnd();
	glDisable(GL_TEXTURE_2D);
  //glEnable(GL_FOG); 
}


