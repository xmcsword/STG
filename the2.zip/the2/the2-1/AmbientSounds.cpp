// AmbientSounds.cpp: implementation of the CAmbientSounds class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AmbientSounds.h"
#include "audio.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAmbientSounds::CAmbientSounds()
{
	m_time=0;
	m_number=0;
}
CAmbientSounds::~CAmbientSounds()
{
}
void CAmbientSounds::ResetSounds()
{
	m_time=0;
	m_number=0;
}
void CAmbientSounds::PlaySounds()
{
	if(m_time==0)
	{
		CAudio::Play(SOUND_AMBIENT,-1,false);
		CAudio::Play(SOUND_BIRD_0 + m_number,1,false);
		m_time++;
	}
	
	if(m_time>200)
	{
		m_time=1;
		m_number++;
		if(m_number>7)m_number=0;
	    CAudio::Play(SOUND_BIRD_0 + m_number,1,false);
	}
	m_time++;
}