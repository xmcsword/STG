// Normal.h: interface for the CNormal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NORMAL_H__32731B81_4718_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_NORMAL_H__32731B81_4718_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNormal  
{
public:
	CNormal();
	virtual ~CNormal();
	float     m_3dENormal[360][3];
};

#endif // !defined(AFX_NORMAL_H__32731B81_4718_11D6_812C_5254AB37CDC9__INCLUDED_)
