// AmbientSounds.h: interface for the CAmbientSounds class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AMBIENTSOUNDS_H__FA1BA2E1_1033_11D6_90D1_5254AB37CDC9__INCLUDED_)
#define AFX_AMBIENTSOUNDS_H__FA1BA2E1_1033_11D6_90D1_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAmbientSounds  
{
public:
	CAmbientSounds();
	virtual ~CAmbientSounds();
	void    ResetSounds();
	void    PlaySounds();
private:
	int     m_time;
	int     m_number;

};

#endif // !defined(AFX_AMBIENTSOUNDS_H__FA1BA2E1_1033_11D6_90D1_5254AB37CDC9__INCLUDED_)
