// Menu.h: interface for the CMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MENU_H__902ED7E2_A628_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_MENU_H__902ED7E2_A628_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "mainmenusheet.h"
#include "singleplayersheet.h"
#include "optionssheet.h"
#include "CreditSheet.h"
#include "newgamesheet.h"
#include "input.h"

class CMenu  
{
public:
	CMenu();
	virtual ~CMenu();
	void  RenderMenu();
    bool  LoadMenu();
    void  DeleteMenu();
private:
	void   UpdateMenu();
	void   DrawCursor();
	void   DrawBackGround();

    CMainMenuSheet      *m_cMainMenuSheet;
	CSinglePlayerSheet  *m_cSinglePlayerSheet;
	COptionsSheet       *m_cOptionsSheet;
	CCreditSheet        *m_cCreditSheet;
	CNewGameSheet       *m_cNewGameSheet;

	bool   m_bActive;
	bool   m_bResource;

	unsigned int        m_texCursor;
	unsigned int        m_texBkg;
    CInput              m_cInput;

};

#endif // !defined(AFX_MENU_H__902ED7E2_A628_11D6_814C_5254AB37CDC9__INCLUDED_)
