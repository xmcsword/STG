// SMFNormal.h: interface for the CSMFNormal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMFNORMAL_H__CEED9AE1_5E6E_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_SMFNORMAL_H__CEED9AE1_5E6E_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSMFNormal  
{
public:
	CSMFNormal();
	virtual ~CSMFNormal();
	static float     *m_pSMFNormal;
	static int        m_numUser;

};

#endif // !defined(AFX_SMFNORMAL_H__CEED9AE1_5E6E_11D6_812C_5254AB37CDC9__INCLUDED_)
