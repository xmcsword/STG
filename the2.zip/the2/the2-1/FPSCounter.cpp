// FPSCounter.cpp: implementation of the CFPSCounter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FPSCounter.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFPSCounter::CFPSCounter()
{
	FrameTime0=0;
	FrameTime1=0;
	FrameCount0=0;
	FrameCount1=0;
	FrameRate=0;
}

CFPSCounter::~CFPSCounter()
{

}

void CFPSCounter::ShowFPS(int x,int y)
{
	char infoStr[16];
	wsprintf(infoStr,"%d FPS", FrameRate);
	m_cText.PrintString(x,y,infoStr,0,16,1);
	////////////Count Frame Rate /////////
	if(FrameCount1<5000)FrameCount1++;
	else FrameCount1=0;
	FrameTime1=timeGetTime();
	if((FrameTime1-FrameTime0)>1000)
	{
		FrameRate=(FrameCount1-FrameCount0)*1000/(FrameTime1-FrameTime0);
        FrameTime0=FrameTime1;
		FrameCount0=FrameCount1;
	}
}
