// ImgText.cpp: implementation of the CImgText class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ImgText.h"
#include "stdio.h"
#include "math.h"
unsigned int  CImgText::m_texFont;
int           CImgText::m_numUser=0;
int           CImgText::m_FontType=0;
float         CImgText::m_textDist=-520;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImgText::CImgText()
{
	m_numUser++;
}

CImgText::~CImgText()
{
	m_numUser--;
	if(m_numUser==0)
	{
	}
}
void  CImgText::PrintString(int x,int y,char* string,
							bool bCenter,int size,int type)
{
	int num=strlen(string);
	float widthFactor=0.65f;
	if(m_FontType==1)widthFactor=0.7f;
	int xbias=int(bCenter*(num+1)*size*widthFactor)/2;
	int ybias=bCenter*size/2;
 
	glBlendFunc(GL_ONE,GL_ONE);
	glEnable(GL_BLEND);
//	glAlphaFunc(GL_GEQUAL,0.05f);
//	glEnable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);
 	glBindTexture(GL_TEXTURE_2D,m_texFont );
	glEnable(GL_TEXTURE_2D);	
	float texx,texy;
	float xpos,ypos;
	ypos=float(300-y+ybias);
	
 	glBegin(GL_QUADS);
        for(int i=0;i<num;i++)
		{
			texx=float(int(string[i])%16)/16;
			texy=float(int(string[i]-32)/16)/16 + m_FontType*0.5f;
			xpos=float(x-xbias-400) + i*size*widthFactor;
			
			glTexCoord2f(texx,1-texy);    
			glVertex3f(xpos,ypos,m_textDist);

			glTexCoord2f(texx+0.0625f,1-texy);    
			glVertex3f(xpos+size,ypos,m_textDist);

			glTexCoord2f(texx+0.0625f,1-texy-0.0625f);    
			glVertex3f(xpos+size,ypos-size,m_textDist);

			glTexCoord2f(texx,1-texy-0.0625f);    
			glVertex3f(xpos,ypos-size,m_textDist);
		}  
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
//	glEnable(GL_DEPTH_TEST);
//	glDisable(GL_ALPHA_TEST);
}
void CImgText::PrintfChar(int x,int y,char ch,
		              bool bCenter,int size,int type)
{
	char str[2];
	str[0]=ch;
	str[1]=NULL;
    PrintString(x,y,str,bCenter,size,type);

}
void  CImgText::PrintValue(int x,int y,float fValue,bool bCenter,int size)
{
	char str[32];
	sprintf(str,"%.2f",fValue);
    PrintString( x, y,str);
}
void  CImgText::PrintValue(int x,int y,double dValue,bool bCenter,int size)
{
	char str[32];
	sprintf(str,"%.2f",dValue);
    PrintString( x, y,str);
}
void  CImgText::PrintValue( int x,int y,int iValue,bool bCenter,int size)
{
	char str[32];
	wsprintf(str,"%d",iValue);
    PrintString( x, y,str);

}
void  CImgText::SetFontType(int type)
{
	m_FontType=type;
	if(m_FontType!=1)m_FontType=0;

}
void  CImgText::SetViewFOVAngle(float angle)
{
	if(angle<2 || angle>85)angle=60;

	m_textDist=-300/tanf(angle*0.0174533f);
}
float CImgText::GetTextDist()
{
    return m_textDist;
}