// Camera.cpp: implementation of the CCamera class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Camera.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCamera::CCamera()
{
    m_CamPos=VERTEX(10,0,10);
    m_CamDirection=NORMAL(1,0,0);
	m_CamRotY=0;
}

CCamera::~CCamera()
{
}
void CCamera::SetCamera(VERTEX position,float rotY)
{
    m_CamPos=position;
	m_CamRotY=rotY;

	m_CamDirection=NORMAL(-sinf(rotY*0.0174533f),
		                  0,
						  -cosf(rotY*0.0174533f));
	m_CamDirection=math.Normalization(m_CamDirection);
}

void CCamera::SetCamera(VERTEX newFoucs)
{
	m_CamDirection=NORMAL(newFoucs.xpos-m_CamPos.xpos,0,newFoucs.zpos-m_CamPos.zpos);
	m_CamDirection=math.Normalization(m_CamDirection);
	m_CamRotY=acosf(-m_CamDirection.nz/float(sqrt(m_CamDirection.nz*m_CamDirection.nz+m_CamDirection.nx*m_CamDirection.nx)))*57.29578f;
	if(m_CamDirection.nx>0)m_CamRotY=360-m_CamRotY;
}
void   CCamera::SetCameraRotate(float yrot)
{
	if(yrot>360 || yrot<0)yrot=0;
	m_CamRotY=yrot;
}
void   CCamera::SetCameraPosition(VERTEX pos)
{
    m_CamPos=pos;
}
float CCamera::GetDistance(VERTEX pos)
{
	float dx=(m_CamPos.xpos>pos.xpos)?(m_CamPos.xpos-pos.xpos):(pos.xpos-m_CamPos.xpos);
//	float dy=(m_CamPos.ypos>pos.ypos)?(m_CamPos.ypos-pos.ypos):(pos.ypos-m_CamPos.ypos);
	float dz=(m_CamPos.zpos>pos.zpos)?(m_CamPos.zpos-pos.zpos):(pos.zpos-m_CamPos.zpos);

    return dx+dz;
}
bool CCamera::IsEnemyInFrustum(VERTEX enemyPos)
{
    float cosValue=math.GetTwoVectorAngleCosine(NORMAL(enemyPos.xpos-m_CamPos.xpos,
		                                 enemyPos.ypos -m_CamPos.ypos,
										 enemyPos.zpos-m_CamPos.zpos ) , 
										 m_CamDirection);
	if(cosValue>0)  ///////// In camera
	{
		return true;
	}
    return false; ///// out of camera
}
