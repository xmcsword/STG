// ChangeBar.cpp: implementation of the CChangeBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ChangeBar.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CChangeBar::CChangeBar()
{
    m_sText=NULL;
	m_texID=NULL;
    m_iSelect=0;
    m_bEnable=true;
}

CChangeBar::~CChangeBar()
{
	if(m_texID!=NULL)
	{
		delete [] m_texID;
	}
	if(m_sText!=NULL)
	{
		for(int i=0;i<m_iMaxItem;i++)
		    delete [] m_sText[i];
        delete [] m_sText;
	}
}
void CChangeBar::SetChangeBar(RECT rect, char **sText,int numItem,int curItem)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	RECT rt=rect;
    /////// set spin
	rt.right=rt.left+height;
	m_cSpin[0].SetSpin(rt,1);
	rt.right=rect.right;
	rt.left=rt.right-height;
	m_cSpin[1].SetSpin(rt,0);
    /////// Set button
	if(numItem>32)numItem=32;
	m_iMaxItem=numItem;
	m_sText=new char*[numItem];
    for(int i=0;i<numItem;i++)
	{
		m_sText[i]=new char [32];
    	strcpy(m_sText[i],sText[i]);
	}

	rt.left=rect.left+ int(height*1.2f);
	rt.right=rect.right-int(height*1.2f);

	m_iSelect=curItem;
	if(m_iSelect>(numItem-1))m_iSelect=0;
 
	m_cButton.SetButton(rt,m_sText[m_iSelect]);

}
void CChangeBar::SetChangeBar(RECT rect, unsigned int *texID,int numItem,int curItem)
{
	int width=rect.right-rect.left;
	int height=rect.bottom-rect.top;
	RECT rt=rect;
    /////// set spin
	rt.top=rect.top+int(height*0.4f);
	rt.bottom=rect.top+int(height*0.6f);
	rt.right=rt.left+int(width*0.035f);
	m_cSpin[0].SetSpin(rt,1);
	rt.right=rect.right;
	rt.left=rt.right-int(width*0.035f);
	m_cSpin[1].SetSpin(rt,0);
    /////// Set button
	m_iMaxItem=numItem;
	m_texID=new unsigned int [numItem];
	for(int i=0;i<numItem;i++)
		m_texID[i]=texID[i];

    rt=rect;
	rt.left=rect.left+ int(height*0.08f);
	rt.right=rect.right-int(height*0.08f);

	m_iSelect=curItem;
	if(m_iSelect>(numItem-1))m_iSelect=0;
	m_cButton.SetButton(rt,m_texID[m_iSelect]);
}
void CChangeBar::SetEnable(bool bState)
{
	m_bEnable=bState;
	if(m_bEnable)
	{
		m_cSpin[0].m_iState=BUTTON_NORMAL;
		m_cSpin[1].m_iState=BUTTON_NORMAL;
        m_cButton.m_iState=BUTTON_NORMAL;
	}
	else
	{
		m_cSpin[0].m_iState=BUTTON_DEAD;
		m_cSpin[1].m_iState=BUTTON_DEAD;
        m_cButton.m_iState=BUTTON_DEAD;
	}
}
void CChangeBar::RenderChangeBar()
{
	UpdateChangeBar();
	m_cSpin[0].RenderSpin();
	m_cSpin[1].RenderSpin();
	m_cButton.RenderButton();
}
void   CChangeBar::UpdateChangeBar()
{
	int oldValue=m_iSelect;
	if(m_cButton.m_bSelected)
	{
		m_cButton.m_bSelected=false;
		m_iSelect++;
		if(m_iSelect==m_iMaxItem)m_iSelect=0;
		UpdateButtonShow();
	}
	if(m_cSpin[0].m_bSelected)
	{
		m_cSpin[0].m_bSelected=false;
		m_iSelect--;
		if(m_iSelect==-1)m_iSelect=m_iMaxItem-1;
		UpdateButtonShow();
	}
	if(m_cSpin[1].m_bSelected)
	{
		m_cSpin[1].m_bSelected=false;
		m_iSelect++;
		if(m_iSelect==m_iMaxItem)m_iSelect=0;
		UpdateButtonShow();
	}
	if(oldValue!=m_iSelect)m_bValueChanged=true;
	else m_bValueChanged=false;

}

void CChangeBar::UpdateButtonShow()
{
	if(m_cButton.m_bShowPicture)
		m_cButton.SetButtonPicture(m_texID[m_iSelect]);
	else
	{
		m_cButton.SetButtonText(m_sText[m_iSelect]);
	}
}
void CChangeBar::SetItem(int iItem)
{
	m_iSelect=iItem;
	if(m_iSelect>(m_iMaxItem-1))m_iSelect=m_iMaxItem-1;
	if(m_iSelect<0)m_iSelect=0;
	UpdateButtonShow();
}
int  CChangeBar::GetSelected()
{
    return m_iSelect;
}
int   CChangeBar::GetTotalItemNumber()
{
    return m_iMaxItem;
}
/*
void CChangeBar::GetString(char *string,int iItem)
{
	if(m_sText==NULL)return;
	if(iItem>=m_iMaxItem)return;
	int len=strlen(m_sText);
	int start;
	int cur=0,i=0;
	//////find out start
	while(i!=iItem && cur<len)
	{
		if(m_sText[cur] == '`')
		    i++;

        cur++;
	}
	start=cur;
	//////find out end
	while(cur<len)
	{
		if(m_sText[cur] == '`')
		    break;
        cur++;
	}
    int num=cur-start;
	if(num>32)num=32;

	for(i=0;i<num;i++)
		string[i]=m_sText[start+i];

	string[i]=NULL;

}
*/








