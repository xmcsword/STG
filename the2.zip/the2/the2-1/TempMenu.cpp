// TempMenu.cpp: implementation of the CTempMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TempMenu.h"
#include "texmanager.h"
#include "audio.h"
#include "input.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTempMenu::CTempMenu()
{
    m_cTempSheet=NULL;
	m_cOptionsSheet=NULL;
	m_bActivate=false;
	m_bResource=false;
}
CTempMenu::~CTempMenu()
{
	DeleteMenu();
}
bool  CTempMenu::LoadMenu()
{
	if(m_bResource)return true;

	//////// Texture
	CTexManager cTexManager;
	if(!cTexManager.CreateTempMenuResource())
        MessageBox(0, "Create textures error", "Error", MB_OK | MB_ICONERROR);
    //////////////Cursor and background
	m_texCursor = cTexManager.GetTextureID(TEX_MENU_CURSOR);
	m_texBkg    = cTexManager.GetTextureID(TEX_SCREEN_CAPTURE);

	///////////////////Sheets
    m_cTempSheet         = new CTempSheet;
	m_cOptionsSheet      = new COptionsSheet;

 	m_cTempSheet->InitSheet();
	m_cOptionsSheet->InitSheet();

    m_cTempSheet->m_bActive=true;

	///////// sound 
	
	CAudio audio;
	audio.CreateSound(MENU_SOUND_CLICK,"audio/menu/click.wav",false);
	audio.CreateSound(MENU_SOUND_TEST,"audio/ambient/bird0.wav",false);

    ///////////////////////////////
	m_bActivate=true;
	m_bResource=true;
	return true;
}
void  CTempMenu::DeleteMenu()
{
	if(!m_bResource)return;

	//////// delete Texture
	CTexManager cTexManager;
	cTexManager.DeleteTempMenuResource();

    ////////// sheets
    if(m_cTempSheet !=NULL)
	{
		delete m_cTempSheet;
		m_cTempSheet=NULL;
	}
	if(m_cOptionsSheet  !=NULL) 
	{
		delete m_cOptionsSheet;
		m_cOptionsSheet=NULL;
	}
	///////////////// delete audio
	
	CAudio audio;
	audio.DeleteSound(MENU_SOUND_CLICK);
	audio.DeleteSound(MENU_SOUND_TEST);
	//////////////////////////////
	m_bActivate=false;
	m_bResource=false;

}
void CTempMenu::RenderMenu()
{
	if(!m_bActivate)return;

	UpdateMenu();

	DrawBackGround();
	/////////////////////////////////////

	m_cTempSheet->RenderSheet();
	m_cOptionsSheet->RenderSheet();
	//////////////////////////////
	if(CInput::m_bShowMouse)DrawCursor();
}
void CTempMenu::UpdateMenu()
{
	if(m_cTempSheet->m_bActive)
	{
		if(m_cTempSheet->m_iSelect==0)
		{
            m_cTempSheet->m_iSelect=-1;
			CGameSetting::m_iGameState=GAME_MISSION;
		}	

		if(m_cTempSheet->m_iSelect==3)
		{
            m_cTempSheet->m_iSelect=-1;
			m_cTempSheet->m_bActive=false;
			m_cOptionsSheet->m_bActive=true;
		}	
		if(m_cTempSheet->m_iSelect==4)
		{
			CGameSetting::m_iGameState=GAME_MAIN_MENU;
		}
	}
	if(m_cOptionsSheet->m_bActive)
	{
		if(m_cOptionsSheet->m_iSelect==0  || m_cOptionsSheet->m_iSelect==2)
		{
			m_cOptionsSheet->m_iSelect=-1;
			m_cOptionsSheet->m_bActive=false;
			m_cTempSheet->m_bActive=true;
		}
	}

}
void  CTempMenu::DrawBackGround()
{
	static float move=0;
//	move+=0.01f;
	if(move>1)move=0;

 	    glBindTexture(GL_TEXTURE_2D, m_texBkg);
	    glEnable(GL_TEXTURE_2D);	
		glColor3f(1,1,1);
 	    glBegin(GL_QUADS);
     	    glTexCoord2f(move,1);    
	        glVertex3i(-400 , 300 , -520);
	        glTexCoord2f(1+move,1);   
	        glVertex3i(400 , 300 , -520);
		    glTexCoord2f(1+move,0);   
	        glVertex3i(400 , -300 , -520);
		    glTexCoord2f(move,0);    
	        glVertex3i(-400 , -300 , -520);
	    glEnd();
	    glDisable(GL_TEXTURE_2D);
}
void  CTempMenu::DrawCursor()
{
    	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	    glEnable(GL_BLEND);
 	    glBindTexture(GL_TEXTURE_2D, m_texCursor);
	    glEnable(GL_TEXTURE_2D);	
		glColor3f(1,1,1);
 	    glBegin(GL_QUADS);
     	    glTexCoord2f(0,1);    
	        glVertex3i(m_cInput.m_mousePosX-400 , 300-m_cInput.m_mousePosY , -520);
	        glTexCoord2f(1,1);   
	        glVertex3i(m_cInput.m_mousePosX+16-400 , 300-m_cInput.m_mousePosY , -520);
		    glTexCoord2f(1,0);   
	        glVertex3i(m_cInput.m_mousePosX+16-400 , 300-m_cInput.m_mousePosY-16 , -520);
		    glTexCoord2f(0,0);    
	        glVertex3i(m_cInput.m_mousePosX-400 , 300-m_cInput.m_mousePosY-16 , -520);
	    glEnd();
	    glDisable(GL_TEXTURE_2D);
	    glDisable(GL_BLEND);
}