// Pine.h: interface for the CPine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PINE_H__D0CF8261_9E79_11D6_8142_5254AB37CDC9__INCLUDED_)
#define AFX_PINE_H__D0CF8261_9E79_11D6_8142_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
class CPine  
{
public:
	CPine();
	virtual ~CPine();
    bool InitPine(int treeType,float treeSize=0.2f);
	void RenderPine(VERTEX position);

protected:
    void DrawPine();
	void DrawBranch(float width);

	float m_szTree;
	float m_height;

    unsigned int texTreeBody;
	unsigned int texBranch;
};

#endif // !defined(AFX_PINE_H__D0CF8261_9E79_11D6_8142_5254AB37CDC9__INCLUDED_)
