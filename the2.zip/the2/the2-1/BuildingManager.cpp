// BuildingManager.cpp: implementation of the CBuildingManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BuildingManager.h"
#include "texmanager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBuildingManager::CBuildingManager()
{
	m_numHouse=0;
	m_cHouse=NULL;
}
CBuildingManager::~CBuildingManager()
{
	if(m_cHouse!=NULL)
	{
		delete [] m_cHouse;
		m_cHouse=NULL;
	}
}
bool CBuildingManager::InitBuilding()
{

	if(!m_ms3dHouse.Load("model/ms3d/house.ms3d",1))
	{
		MessageBox(0, "Load building file error", "Error", MB_OK | MB_ICONERROR);
		return FALSE;
	}

	m_cSmoke.InitParticle(CTexManager::GetTextureID(TEX_SMOKE_0),0,50,1);

	//////////////////////////////////////////////////
	m_numHouse=m_cHmap.m_numBuilding;

	m_cHouse=new CHouse [m_numHouse];
	bool bSmoke=false;
	int  texID=TEX_HOUSE_0;
	for(int i=0;i<m_numHouse;i++)
	{
        bSmoke=!bSmoke;
		texID++;
		if(texID>TEX_HOUSE_2)texID=TEX_HOUSE_0;
    	m_cHouse[i].InitHouse(&m_ms3dHouse,&m_cSmoke,m_cHmap.m_buildingPos[i],
		                  0,CTexManager::GetTextureID(texID),bSmoke);

    	m_cHmap.m_bigBndyBuilding[i] = &m_cHouse[i].m_bigBoundary;
    	m_cHmap.m_smallBndyBuilding[i] = &m_cHouse[i].m_smallBoundary;
	
	}
	//////////////////////////////////////////////////
	return true;

}

void CBuildingManager::RenderBuilding()
{
	for(int i=0;i<m_numHouse;i++)
    	m_cHouse[i].DrawHouse();

}
void CBuildingManager::RenderSmoke()
{
	for(int i=0;i<m_numHouse;i++)
      	m_cHouse[i].DrawSmoke();

}
