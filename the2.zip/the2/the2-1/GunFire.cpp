// GunFire.cpp: implementation of the CGunFire class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GunFire.h"
#include "texManager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGunFire::CGunFire()
{
	m_maxFireSize=0.8f;
	m_minFireSize=0.5f;
    m_gunFireSize=0.5f;
	m_fireGrowth=1.5f;
	m_guFireRotate=0;
	m_addAngle=5;
}

CGunFire::~CGunFire()
{

}
void CGunFire::InitGunFire(float minSize,float maxSize)
{
	CTexManager cTex;
	m_texGunFire=cTex.GetTextureID(TEX_GUN_FIRE);

	m_maxFireSize=maxSize;
	m_minFireSize=minSize;
	m_gunFireSize=m_maxFireSize;
}
void CGunFire::DrawGunFire()
{
    glPushMatrix();	 
    glRotatef(m_guFireRotate,  0.0f,0.0f,1.0f);

    m_guFireRotate+=m_addAngle;
	if(m_guFireRotate>50)m_addAngle =-10;
	if(m_guFireRotate<-50)m_addAngle=10;

    m_gunFireSize +=  m_fireGrowth;
	if(m_gunFireSize>m_maxFireSize)m_fireGrowth=-0.085f;
	if(m_gunFireSize<m_minFireSize)m_fireGrowth= 0.085f;

	    ////////////draw fire
	    glDisable(GL_CULL_FACE);
     	glBindTexture(GL_TEXTURE_2D,m_texGunFire);
    	glEnable(GL_TEXTURE_2D);
    	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
        glEnable(GL_BLEND);

    	glBegin(GL_QUADS);
          glTexCoord2d(0,0); 
    	  glVertex3d( -m_gunFireSize , -m_gunFireSize ,0);
          glTexCoord2d(1,0); 
    	  glVertex3d( m_gunFireSize , -m_gunFireSize ,0);
          glTexCoord2d(1,1); 
    	  glVertex3d(m_gunFireSize , m_gunFireSize ,0);
          glTexCoord2d(0,1); 
    	  glVertex3d(-m_gunFireSize , m_gunFireSize ,0);
        glEnd();

    	glDisable(GL_BLEND);
    	glEnable(GL_CULL_FACE);

    glPopMatrix();
}