// AmmoManager.h: interface for the CAmmoManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AMMOMANAGER_H__36A19001_546B_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_AMMOMANAGER_H__36A19001_546B_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "heightmap.h"
#include "hitparticle.h"
#include "ammomanager.h"

#define  MAXROCKET  10
#define  MAXBULLET  15

class CAmmoManager  
{
public:
	CAmmoManager();
	virtual ~CAmmoManager();
    bool   InitAmmoManager();
	void   RenderAmmoManager();
private:
	void          Fire(VERTEX pos);
    void          UpdateAmmoManager();
	CHitParticle  m_cHitParticle[MAXBULLET];
	CHeightmap    m_cHmap;

};

#endif // !defined(AFX_AMMOMANAGER_H__36A19001_546B_11D6_812C_5254AB37CDC9__INCLUDED_)
