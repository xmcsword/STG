// Bush.h: interface for the CBush class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUSH_H__52F60941_9DAC_11D6_813E_5254AB37CDC9__INCLUDED_)
#define AFX_BUSH_H__52F60941_9DAC_11D6_813E_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "structdef.h"

class CBush  
{
public:
	CBush();
	virtual ~CBush();
    bool InitBush(int type);
	void RenderBush(VERTEX position);

protected:
    void DrawBush();
    void DrawLichen();

	void DrawCross(float size,float bias,int angle,float tex_x1,float tex_x2,float tex_y1,float tex_y2);
 
	float m_size;
	float m_height;

	int   m_type;

    unsigned int texBush;
};

#endif // !defined(AFX_BUSH_H__52F60941_9DAC_11D6_813E_5254AB37CDC9__INCLUDED_)
