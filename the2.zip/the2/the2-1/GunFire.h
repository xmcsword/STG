// GunFire.h: interface for the CGunFire class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GUNFIRE_H__EFBD3921_B9D0_11D6_90D9_5254AB37CDC9__INCLUDED_)
#define AFX_GUNFIRE_H__EFBD3921_B9D0_11D6_90D9_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGunFire  
{
public:
	CGunFire();
	virtual ~CGunFire();
	void  InitGunFire(float minSize=0.8f,float maxSize=0.5f);
	void  DrawGunFire();
private:
	float         m_maxFireSize;
	float         m_minFireSize;

	float         m_gunFireSize;
	float         m_guFireRotate;
	float         m_addAngle;
	float         m_fireGrowth;

	unsigned int  m_texGunFire;

};

#endif // !defined(AFX_GUNFIRE_H__EFBD3921_B9D0_11D6_90D9_5254AB37CDC9__INCLUDED_)
