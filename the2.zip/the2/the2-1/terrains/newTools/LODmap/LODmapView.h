// LODmapView.h : interface of the CLODmapView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LODMAPVIEW_H__811407ED_601D_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_LODMAPVIEW_H__811407ED_601D_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLODmapView : public CView
{
protected: // create from serialization only
	CLODmapView();
	DECLARE_DYNCREATE(CLODmapView)

// Attributes
public:
	CLODmapDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLODmapView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLODmapView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLODmapView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LODmapView.cpp
inline CLODmapDoc* CLODmapView::GetDocument()
   { return (CLODmapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LODMAPVIEW_H__811407ED_601D_11D6_812C_5254AB37CDC9__INCLUDED_)
