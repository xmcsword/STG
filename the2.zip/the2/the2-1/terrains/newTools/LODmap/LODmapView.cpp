// LODmapView.cpp : implementation of the CLODmapView class
//

#include "stdafx.h"
#include "LODmap.h"

#include "LODmapDoc.h"
#include "LODmapView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLODmapView

IMPLEMENT_DYNCREATE(CLODmapView, CView)

BEGIN_MESSAGE_MAP(CLODmapView, CView)
	//{{AFX_MSG_MAP(CLODmapView)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLODmapView construction/destruction

CLODmapView::CLODmapView()
{
	// TODO: add construction code here

}

CLODmapView::~CLODmapView()
{
}

BOOL CLODmapView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CLODmapView drawing

void CLODmapView::OnDraw(CDC* pDC)
{


}

/////////////////////////////////////////////////////////////////////////////
// CLODmapView printing

BOOL CLODmapView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CLODmapView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CLODmapView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CLODmapView diagnostics

#ifdef _DEBUG
void CLODmapView::AssertValid() const
{
	CView::AssertValid();
}

void CLODmapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CLODmapDoc* CLODmapView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLODmapDoc)));
	return (CLODmapDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLODmapView message handlers

int CLODmapView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
    ///////////////////////////////////////////////////////
	//////////read data
	//////////////////////////////
	unsigned char lodmap[256][256];
	unsigned char rgb[3];
	int z,x;
	FILE* file;
    ////////////mask1
    if((file= fopen("LODmap_source.bmp", "rb"))==NULL)
		return false;
	fseek(file,54,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
		{
			fread(rgb,sizeof(unsigned char),3,file);	
			if(rgb[0]==rgb[1] && rgb[1]==rgb[2] && rgb[0]==0)
				lodmap[z][x]=7;
			else if(rgb[0]==rgb[1] && rgb[1]==rgb[2] && rgb[0]==192)
				lodmap[z][x]=6;
			else if(rgb[0]==rgb[1] && rgb[1]==rgb[2] && rgb[0]==128)
				lodmap[z][x]=5;
			else if(rgb[0]==255 &&  rgb[1]==rgb[2] && rgb[1]==0)
				lodmap[z][x]=4;
			else if(rgb[0]==rgb[1] && rgb[0]==0 && rgb[2]==255)
				lodmap[z][x]=3;
			else if(rgb[0]==rgb[2] && rgb[0]==0 && rgb[1]==255)
				lodmap[z][x]=2;
			else if(rgb[0]==rgb[1] && rgb[1]==rgb[2] && rgb[0]==255)
				lodmap[z][x]=1;

		}

	fclose(file);
	file=NULL;   
	////////////////////////////////////////////////////////
	/////////// Filtrate data
    /////////////////////////////////////////////////////////
	for(z=0;z<256;z++)
        for(x=1;x<256;x+=2)
		{
			if(lodmap[z][x]==7 || lodmap[z][x]==6)lodmap[z][x]=0;
		}

	for(x=0;x<256;x++)
        for(z=1;z<256;z+=2)
		{
			if(lodmap[z][x]==7 || lodmap[z][x]==6)lodmap[z][x]=0;
		}
    ////////////////write data
	///////////////////////////////////////////
    if((file=fopen("lodmap.lod","wb"))==NULL)
	    return false;
    for(z=255;z>-1;z--)
		for( x=0;x<256;x++)
                fwrite(&lodmap[z][x],sizeof(unsigned char),1,file);
    ///////////////////////
	fclose(file);    


	return 0;
}
