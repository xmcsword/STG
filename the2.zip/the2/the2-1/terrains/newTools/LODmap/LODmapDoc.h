// LODmapDoc.h : interface of the CLODmapDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LODMAPDOC_H__811407EB_601D_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_LODMAPDOC_H__811407EB_601D_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLODmapDoc : public CDocument
{
protected: // create from serialization only
	CLODmapDoc();
	DECLARE_DYNCREATE(CLODmapDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLODmapDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLODmapDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLODmapDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LODMAPDOC_H__811407EB_601D_11D6_812C_5254AB37CDC9__INCLUDED_)
