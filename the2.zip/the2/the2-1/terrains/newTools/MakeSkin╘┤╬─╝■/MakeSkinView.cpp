// MakeSkinView.cpp : implementation of the CMakeSkinView class
//

#include "stdafx.h"
#include "MakeSkin.h"

#include "MakeSkinDoc.h"
#include "MakeSkinView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMakeSkinView

IMPLEMENT_DYNCREATE(CMakeSkinView, CView)

BEGIN_MESSAGE_MAP(CMakeSkinView, CView)
	//{{AFX_MSG_MAP(CMakeSkinView)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMakeSkinView construction/destruction

CMakeSkinView::CMakeSkinView()
{
	// TODO: add construction code here
	strcpy(id,"Hunter3D00");
	version=1;
}

CMakeSkinView::~CMakeSkinView()
{
}

BOOL CMakeSkinView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMakeSkinView drawing

int CMakeSkinView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	if(!ReadPicture())
	{
		MessageBox("Read pics error!");
		return -1;
	}
	if(!MakeTerSkin())
	{
		MessageBox("make skins error!");
		return -1;
	}	
	return 0;
}

void CMakeSkinView::OnDraw(CDC* pDC)
{
	CMakeSkinDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
    COLORREF color;
    for(int z=0;z<256;z++)
    	for(int x=0;x<256;x++)
		{
	    	color=RGB(baseA[z][x][2],baseA[z][x][1],baseA[z][x][0]);
	    	pDC->SetPixel(x,z,color);
		}
}

bool CMakeSkinView::ReadPicture()
{
	int x,z;
	FILE* file;
    ////////////mask1
    if((file= fopen("mask/mask1.bmp", "rb"))==NULL)
		return false;
	fseek(file,1078,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
			fread(&mask1[z][x],sizeof(unsigned char),1,file);	
	if(fclose(file)!=0)
		return false;
	file=NULL;
    ////////////mask2
    if((file= fopen("mask/mask2.bmp", "rb"))==NULL)
		return false;
	fseek(file,1078,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
			fread(&mask2[z][x],sizeof(unsigned char),1,file);	
	if(fclose(file)!=0)
		return false;
	file=NULL;
    ////////////mask3
    if((file= fopen("mask/mask3.bmp", "rb"))==NULL)
		return false;
	fseek(file,1078,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
			fread(&mask3[z][x],sizeof(unsigned char),1,file);	
	if(fclose(file)!=0)
		return false;
	file=NULL;   
	////////////////////BaseA
    if((file= fopen("output/a1.bmp", "rb"))==NULL)
		return false;
	fseek(file,54,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
			fread(&baseA[z][x],sizeof(unsigned char),3,file);	
	if(fclose(file)!=0)
		return false;
	file=NULL;   
	////////////////////BaseB
    if((file= fopen("output/b1.bmp", "rb"))==NULL)
		return false;
	fseek(file,54,SEEK_SET);
	for( z=255;z>-1;z--)
		for( x=0;x<256;x++)
			fread(&baseB[z][x],sizeof(unsigned char),3,file);	
	if(fclose(file)!=0)
		return false;
	file=NULL;   

    return true;
}

bool CMakeSkinView::MakeTerSkin()
{
	
	FILE * OutFile;
	unsigned char blended;
	float factor;
	int x,z,i;
	////////////write File TerSkin1A.skn
    if((OutFile=fopen("OutPut/TerSkin1.skn","wb"))==NULL)
	    return false;
	fwrite(id,sizeof(char),10,OutFile);
	fwrite(&version,sizeof(char),1,OutFile);
    /////////////////////////////////////////
    for(z=255;z>-1;z--)
		for(x=0;x<256;x++)
		{
			factor=float(mask1[z][x])/255;
			for(i=0;i<3;i++)
			{
				blended=unsigned char(factor*baseA[z][x][2-i]+(1-factor)*baseB[z][x][2-i]);
                fwrite(&blended,sizeof(unsigned char),1,OutFile);
			}
		}
    ///////////////////////
	fclose(OutFile);
	OutFile=NULL;
	////////////write File TerSkin1B.skn
    if((OutFile=fopen("OutPut/TerSkin2.skn","wb"))==NULL)
	    return false;
	fwrite(id,sizeof(char),10,OutFile);
	fwrite(&version,sizeof(char),1,OutFile);
    /////////////////////////////////////////
    for(z=255;z>-1;z--)
		for(x=0;x<256;x++)
		{
			factor=1-float(mask1[z][x])/256;
			for(i=0;i<3;i++)
			{
				blended=unsigned char(factor*baseA[z][x][2-i]+(1-factor)*baseB[z][x][2-i]);
                fwrite(&blended,sizeof(unsigned char),1,OutFile);
			}
		}
    ///////////////////////
	fclose(OutFile);
	OutFile=NULL;
	////////////write File TerSkin2.skn
    if((OutFile=fopen("OutPut/TerSkin3.skn","wb"))==NULL)
	    return false;
	fwrite(id,sizeof(char),10,OutFile);
	fwrite(&version,sizeof(char),1,OutFile);
    /////////////////////////////////////////
    for(z=255;z>-1;z--)
		for(x=0;x<256;x++)
		{
			factor=float(mask2[z][x])/256;
			for(i=0;i<3;i++)
			{
				blended=unsigned char(factor*baseA[z][x][2-i]+(1-factor)*baseB[z][x][2-i]);
                fwrite(&blended,sizeof(unsigned char),1,OutFile);
			}
		}
    ///////////////////////
	fclose(OutFile);
	OutFile=NULL;
	////////////write File TerSkin3A.skn
    if((OutFile=fopen("OutPut/TerSkin4.skn","wb"))==NULL)
	    return false;
	fwrite(id,sizeof(char),10,OutFile);
	fwrite(&version,sizeof(char),1,OutFile);
    /////////////////////////////////////////
    for(z=255;z>-1;z--)
		for(x=0;x<256;x++)
		{
			factor=float(mask3[z][x])/256;
			for(i=0;i<3;i++)
			{
				blended=unsigned char(factor*baseA[z][x][2-i]+(1-factor)*baseB[z][x][2-i]);
                fwrite(&blended,sizeof(unsigned char),1,OutFile);
			}
		}
    ///////////////////////
	fclose(OutFile);
	OutFile=NULL;


    return true;

}


/////////////////////////////////////////////////////////////////////////////
// CMakeSkinView diagnostics

#ifdef _DEBUG
void CMakeSkinView::AssertValid() const
{
	CView::AssertValid();
}

void CMakeSkinView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
CMakeSkinDoc* CMakeSkinView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMakeSkinDoc)));
	return (CMakeSkinDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMakeSkinView message handlers
