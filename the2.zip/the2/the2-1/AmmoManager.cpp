// AmmoManager.cpp: implementation of the CAmmoManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AmmoManager.h"
#include "texmanager.h"
#include "math.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAmmoManager::CAmmoManager()
{

}
CAmmoManager::~CAmmoManager()
{
}
bool CAmmoManager::InitAmmoManager()
{
	for(int i=0;i<MAXBULLET;i++)
	{
		m_cHitParticle[i].InitParticle(VERTEX(0,0,0),CTexManager::GetTextureID(TEX_SMOKE_0),
			                           20,20,0.1f);
	}

    return true;
}

void  CAmmoManager::UpdateAmmoManager()
{
	if(m_cHmap.m_bAttack)
	{
		Fire(VERTEX(float(m_cHmap.m_focusPosX),
		            float(m_cHmap.m_focusPosY),
	                float(m_cHmap.m_focusPosZ)));
	}

}
void  CAmmoManager::Fire(VERTEX pos)
{
	float minlife=1;
	int index=0;
	for(int i=0;i<MAXBULLET;i++)
	{
		if(m_cHitParticle[i].m_Life<minlife)
		{
			minlife=m_cHitParticle[i].m_Life;
			index=i;
		}
	}
	m_cHitParticle[index].Reset(VERTEX(pos.xpos,pos.ypos,pos.zpos));
	if(m_cHmap.m_focusState==FOCUS_BODY)m_cHitParticle[index].SetSmokeColor(1,0,0);
	if(m_cHmap.m_focusState==FOCUS_GROUND)m_cHitParticle[index].SetSmokeColor(0.6f,0.5f,0.1f);
}
void  CAmmoManager::RenderAmmoManager()
{
	UpdateAmmoManager();
	/////////// ����
    int   index[MAXBULLET];
	float distlist[MAXBULLET];
	float temp;
	int   tempint;
    float dx,dy,dz;

	int numDraw=0;    //���λ��Ƹ���
	for(int i=0;i<MAXBULLET;i++)
	{
		if(m_cHitParticle[i].m_Life>0)
		{
            index[numDraw]=i;
	        dx=m_cHmap.m_ViewPos.xpos-m_cHitParticle[i].m_pos.xpos;
	        dy=m_cHmap.m_ViewPos.ypos-m_cHitParticle[i].m_pos.ypos;
	        dz=m_cHmap.m_ViewPos.zpos-m_cHitParticle[i].m_pos.zpos;
		    distlist[numDraw]=dx*dx+dy*dy+dz*dz;
			numDraw++;
		}
	}
	/////////����
	for( i=1;i<numDraw;i++)
	{
        for(int k=0;k<(numDraw-i);k++)
			if(distlist[k]<distlist[k+1])
			{
				temp=distlist[k];
				distlist[k]=distlist[k+1];
				distlist[k+1]=temp;

				tempint=index[k];
				index[k]=index[k+1];
				index[k+1]=tempint;
			}       
	}
    ////////����Զ����˳�����
	for( i=0;i<numDraw;i++)
	{
		if(m_cHitParticle[index[i]].m_Life>0)
			m_cHitParticle[index[i]].Render();
	}
}
