// ImgText.h: interface for the CImgText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMGTEXT_H__F8758267_A630_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_IMGTEXT_H__F8758267_A630_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CImgText  
{
public:
	CImgText();
	virtual ~CImgText();

	static void  SetFontType(int type);
	static void  SetViewFOVAngle(float angle);
	static float GetTextDist();

    static void  PrintString(int x,int y,char* string,
		              bool bCenter=false,int size=16,int type=0);
	static void  PrintfChar(int x,int y,char ch,
		              bool bCenter=false,int size=16,int type=0);
	static void  PrintValue( int x,int y,float fValue,
		              bool bCenter=false,int size=20);
	static void  PrintValue( int x,int y,double dValue,
		              bool bCenter=false,int size=20);
	static void  PrintValue( int x,int y,int   iValue,
		              bool bCenter=false,int size=20);    
	
	static unsigned int   m_texFont;
private:
	static int            m_numUser;
	static int            m_FontType;
	static float          m_textDist;
};

#endif // !defined(AFX_IMGTEXT_H__F8758267_A630_11D6_814C_5254AB37CDC9__INCLUDED_)
