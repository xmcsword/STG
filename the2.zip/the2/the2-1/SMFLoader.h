// SMFLoader.h: interface for the CSMFLoader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMFLOADER_H__1F4AECE1_B383_11D6_90CE_5254AB37CDC9__INCLUDED_)
#define AFX_SMFLOADER_H__1F4AECE1_B383_11D6_90CE_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SMFNormal.h"
#include "structdef.h"

#define SMF_STAND     0
#define SMF_RUN       1
#define SMF_ATTACK    2
#define SMF_PAIN      3
#define SMF_FLIP      4
#define SMF_WAVE      5
#define SMF_CRSTAND   6
#define SMF_CRWALK    7
#define SMF_CRATTACK  8
#define SMF_CRPAIN    9
#define SMF_DEATH1    10
#define SMF_DEATH2    11

#define SMF_GUN_MOUTH  0
#define SMF_EYE_POS    1
#define SMF_HEART_POS  2



struct SMF_RAW_VERTEX
{
	unsigned char vertex[3];		//Scaled version of the model's 'real' vertex coordinate
	unsigned char lightNormalIndex;	//An index into the table of normals, kept by Quake 2
};
struct SMF_FRAME
{
	float	       scale[3];		//The scale used by the model's 'fake' vertex structure
	float	       translate[3];	//The translation used by the model's 'fake' vertex structure
	char	       name[16];		//The name for the frame
	SMF_RAW_VERTEX vertices[1];		//An array of SMF_VERTEX structures
};

struct SMF_VERTEX
{
	float x,y,z;				//The (x,y,z) location of the vertex
	int   normalIndex;
};

struct  SMF_TEMPVERTEX  //���ڴ��glCommandsҪ����������trips��fans������
{
	float  texcoord[2];
	float  vertex[3];     
	int    startNormalIndex;
	int    endNormalIndex;
};
struct SMF_ACTION
{
	char   actionName[12];
	int    startFrame;
	int    endFrame;
};
class CSMFLoader  
{
public:
	CSMFLoader();
	virtual ~CSMFLoader();
	bool InitSMFLoader(char* ModelFileName,unsigned int texid,float scale);
	void RenderOneFrame(int numFrame);
	void Animate(int startFrame,int endFrame,float percent);
	void DrawSMFBoundary();
	VERTEX GetPos(int posIndex,float percent=0);
	BOUNDARY_3D m_boundary;

//private:
		int    numGlCommands;
		int    numFrames;
		int    frameSize;
		int    numVertices;
		int    numAction;

		long            *glCommands;
		SMF_VERTEX      *pVertexData;
		SMF_TEMPVERTEX  *pTempFrame;

		SMF_VERTEX      *startPointer;
		SMF_VERTEX      *endPointer;

		SMF_ACTION      *pAction;

		unsigned int       textureID;
		float              scale;

		int                keyIndex[4];

		CSMFNormal         m_SMFNormal;

    	void PreProcess();
    	bool LoadModel(char* ModelFileName);
};

#endif // !defined(AFX_SMFLOADER_H__1F4AECE1_B383_11D6_90CE_5254AB37CDC9__INCLUDED_)
