// Terrain.cpp: implementation of the CTerrain class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <stdio.h>
#include "Terrain.h"
#include "Texmanager.h"
#include "GameSetting.h"
#include "cmath.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTerrain::CTerrain()
{
	for(int i=0;i<128;i++)
		for(int j=0;j<128;j++)
		{	
			Skinmap[i][j].TextureIndex=0;	
			Skinmap[i][j].TextureOrder=0;
		}
	for( i=0;i<256;i++)
		for(int j=0;j<256;j++)
		{
            NormalIndex[i*256+j]=0;
		}
}

bool CTerrain::InitTerrain()
{
	 CTexManager cTexManager;
	 //////////////read blend skin texture
     Blend[0]=cTexManager.GetTextureID(TEX_TERRAIN_SKN1);
     Blend[1]=cTexManager.GetTextureID(TEX_TERRAIN_SKN2);
     Blend[2]=cTexManager.GetTextureID(TEX_TERRAIN_SKN3);
     Blend[3]=cTexManager.GetTextureID(TEX_TERRAIN_SKN4);

	 /////////////////////read base skin and cover skin texture
	 BaseA[0]=cTexManager.GetTextureID(TEX_TERRAIN_A1);
	 BaseA[1]=cTexManager.GetTextureID(TEX_TERRAIN_A2);
	 BaseA[2]=cTexManager.GetTextureID(TEX_TERRAIN_A3);

	 BaseB[0]=cTexManager.GetTextureID(TEX_TERRAIN_B1);
	 BaseB[1]=cTexManager.GetTextureID(TEX_TERRAIN_B2);
	 BaseB[2]=cTexManager.GetTextureID(TEX_TERRAIN_B3);
	 
     Detail[0]=cTexManager.GetTextureID(TEX_TERRAIN_DETAIL_0);
//   Detail[1]=cTexManager.GetTextureID(TEX_TERRAIN_DETAIL_1);
     
    //////////////////////init terrain skin
    /////construct texture index 
	unsigned char index[64][64];
	FILE *fp;
	fp=fopen(CGameSetting::m_strTextureIndex,"rb");
//	fp=fopen("terrains/64_index.BMP","rb");
	if(!fp)return false;
	fseek(fp,1078,SEEK_SET);
	for(int z=63;z>-1;z--)
		for(int x=0;x<64;x++)
		{
			fread(&index[z][x],sizeof(unsigned char),1,fp);	
		}
    fclose(fp); 
    /////////////////get texture index ,texture order 
	for( z=0;z<64;z++)
		for(int x=0;x<64;x++)
		{
			int  name=0;
			int addz=z+1;
			int addx=x+1;
			if(addx==64)addx=0;
			if(addz==64)addz=0;

			if(index[z][x]>64)    name+=8;	
			if(index[z][addx]>64)  name+=4;
			if(index[addz][addx]>64)name+=2;
			if(index[addz][x]>64)  name+=1;

			////////////////////////////////////
			if(name==15)//��һ����ͼ
			{   
				Skinmap[z][x].TextureIndex=BaseA[rand()%3];
    	    	Skinmap[z][x].TextureOrder=rand()%4;
			}
			else if(name==0)//�ڶ�����ͼ
			{
				Skinmap[z][x].TextureIndex=BaseB[rand()%3];
    	    	Skinmap[z][x].TextureOrder=rand()%4;
			}
			else  //������ͼ
			{
				if(name==8 || name==4 || name==2 || name==1 )
					Skinmap[z][x].TextureIndex=Blend[0];

				if(name==7 || name==11|| name==13|| name==14)
					Skinmap[z][x].TextureIndex=Blend[1];

				if(name==12|| name==6 || name==3 || name==9 )
					Skinmap[z][x].TextureIndex=Blend[2];
				
				if(name==10|| name==5  )
					Skinmap[z][x].TextureIndex=Blend[3];
				/////////////////// get order
				if(name==8 || name==7 || name==10|| name==12)
					Skinmap[z][x].TextureOrder=0;

				if(name==4 || name==11|| name==5 || name==6 )
					Skinmap[z][x].TextureOrder=1;

				if(name==2 || name==13|| name==3 )
					Skinmap[z][x].TextureOrder=2;

				if(name==1 || name==14|| name==9 )
					Skinmap[z][x].TextureOrder=3;
			}		
		}
    //////////////read lodmap.lod
	fp=fopen(CGameSetting::m_strLODmap,"rb");
//	fp=fopen("terrains/lodmap.lod","rb");
	if(!fp)return false;
	for( z=255;z>-1;z--)
		for(int x=0;x<256;x++)
		{
			fread(&LODmap[z][x],sizeof(unsigned char),1,fp);	
		}

	///////////////////////////////////////////////
	///////////////Calculate light normal and lighting color
	CMath math;
	NORMAL na1,na2,na;
	NORMAL nb1,nb2,nb;
    NORMAL normal;
	float  xz;
	float  xrot,yrot;
	for( z=0;z<256;z++)
		for(int x=0;x<256;x++)
		{
			int addz=z+1;   if(addz==256)addz=0;
			int subz=z-1;   if(subz==-1)subz=255;
			int addx=x+1;   if(addx==256)addx=0;
			int subx=x-1;   if(subx==-1)subx=255;

			na1=NORMAL(0, float(m_cHmap.m_pTmap[(addz)*256+x] -m_cHmap.m_pTmap[z*256+x] ),6);
			na2=NORMAL(6,float(m_cHmap.m_pTmap[z*256+addx] -m_cHmap.m_pTmap[z*256+x] ),0 );
		
			nb1=NORMAL(0, float(m_cHmap.m_pTmap[(subz)*256+x] -m_cHmap.m_pTmap[z*256+x] ),-6);
			nb2=NORMAL(-6,float(m_cHmap.m_pTmap[z*256+subx] -m_cHmap.m_pTmap[z*256+x] ),0 );

			na=math.GetTwoNormalProduct(na1,na2);
			nb=math.GetTwoNormalProduct(nb1,nb2);
            //////////////////////////////////
            normal.nx=na.nx+nb.nx;
            normal.ny=na.ny+nb.ny;
            normal.nz=na.nz+nb.nz;
			normal=math.Normalization(normal);
            ///////////////////Init Lighting normal////////
			if(normal.ny>1)normal.ny=1;
			if(normal.ny<-1)normal.ny=-1;

			xrot=asinf(normal.ny)*57.29578f;
			xz=(float)sqrt(normal.nx*normal.nx+normal.nz*normal.nz);
			yrot=acosf(-normal.nz/xz)*57.29578f;
			if(normal.nx>0)yrot=360-yrot;

			NormalIndex[z*256+x]=int(xrot/10) * 36+ int(yrot/10);
			if(NormalIndex[z*256+x]>359)NormalIndex[z*256+x]=359;
            ///////////////////Init Lighting Color////////
			/*
			float Aglcos=math.GetTwoVectorAngleCosine(NORMAL(-1.0f,0.5f,1.0f),normal);            
			if(Aglcos>0 && Aglcos<=1)ColorIndex[z*256+x]=int(Aglcos*255);
			else ColorIndex[z*256+x]=0;*/
		}
    ////////// Init Lighting color
            
	//////////////////end
	return true;
}
void CTerrain::RenderTerrain()
{
	numTriangles=0;
    glEnable(GL_DEPTH_TEST);

	int uppos=m_cHmap.m_cFrustumCull.m_upPos;
	int downpos=m_cHmap.m_cFrustumCull.m_downPos;

	for(int z=m_cHmap.m_cFrustumCull.m_pos[uppos].y;z<m_cHmap.m_cFrustumCull.m_pos[downpos].y;z++)
		for(int x=m_cHmap.m_cFrustumCull.m_LeftArray[z];x<m_cHmap.m_cFrustumCull.m_RightArray[z];x++)
            RenderTerrainTile( x, z);

	m_cHmap.m_numTriangles +=numTriangles;

}
////////////////////////////////////////////////////////


void CTerrain::RenderTerrainTile(int x,int z)
{ 
	int level=LODmap[z][x];
	if(level==0)return;

	    if(level==7 )
	       DrawLevel_7(x-128,z-128);	
	    else if(level==6 )
	       DrawLevel_6(x-128,z-128);	
	    else if(level==5 )
	       DrawLevel_5(x-128,z-128);	
	    else if(level==4)
	       DrawLevel_4(x-128,z-128);
	    else if(level==3)
	       DrawLevel_3(x-128,z-128);
	    else if(level==2)
	       DrawLevel_3(x-128,z-128);
    	else  if(level==1)			
	       DrawLevel_3(x-128,z-128);

}

void CTerrain::DrawLevel_1(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x+128-1,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+128+1,z+128+1);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+128+1,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];
			int base5=GetPos(x+128,z-1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz,ex,ez,fx,fz,gx,gz,hx,hz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			ex=(ax+bx)*0.5f;	ez=(az+bz)*0.5f;
            fx=(bx+cx)*0.5f;    fz=(bz+cz)*0.5f;
			gx=(cx+dx)*0.5f;    gz=(cz+dz)*0.5f;
			hx=(dx+ax)*0.5f;    hz=(dz+az)*0.5f;
			///////////////////////////////////
			//////////////////Left_up
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //6
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+1]]);
			glTexCoord2f((dx+0.5f)*0.5f,(dz+0.5f)*0.5f);
		    glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+1] ), float((rz+1)*10+m_cHmap.m_ViewOffsetZ));
            //0
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            //5
			if(LODmap[128+z][128+x-1]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256]]);
			    glTexCoord2f((dx+hx)*0.5f,(dz+hz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256] ), float(rz+1)*10+m_cHmap.m_ViewOffsetZ);
			}
            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//11
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+1]]);
		    glTexCoord2f((hx+0.5f)*0.5f,(hz+0.5f)*0.5f);
	        glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+1] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//7
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+2]]);
			glTexCoord2f((gx+0.5f)*0.5f,(gz+0.5f)*0.5f);
		    glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+2] ), float(rz+1)*10+m_cHmap.m_ViewOffsetZ);
            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            //1
			if(LODmap[128+z-1][128+x]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+1]]);
			    glTexCoord2f((gx+dx)*0.5f,(gz+dz)*0.5f);
		        glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+1] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
			}	
            //0
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();

			///////////////////////////////////
			//////////////////Left_down
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //16
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+1]]);
			glTexCoord2f((ax+0.5f)*0.5f,(az+0.5f)*0.5f);
		    glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+1] ), float((rz+3)*10+m_cHmap.m_ViewOffsetZ));
            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //15
			if(LODmap[128+z][128+x-1]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768]]);
			    glTexCoord2f((ax+hx)*0.5f,(az+hz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768] ), float(rz+3)*10+m_cHmap.m_ViewOffsetZ);
			}
            //20
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			//21
			if(LODmap[128+z+1][128+x]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+1]]);
			    glTexCoord2f((ax+ex)*0.5f,(az+ez)*0.5f);
		        glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+1] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			}
			//22
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			glTexCoord2f(ex,ez);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			//17
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+2]]);
	        glTexCoord2f((ex+0.5f)*0.5f,(ez+0.5f)*0.5f);
	        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+2] ), float(rz+3)*10+m_cHmap.m_ViewOffsetZ);
			
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//11
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+1]]);
		    glTexCoord2f((hx+0.5f)*0.5f,(hz+0.5f)*0.5f);
	        glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+1] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			///////////////////////////////////
			//////////////////right_up
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //8
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+3]]);
			glTexCoord2f((cx+0.5f)*0.5f,(cz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+3] ), float((rz+1)*10+m_cHmap.m_ViewOffsetZ));
            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
			//7
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+2]]);
		    glTexCoord2f((gx+0.5f)*0.5f,(gz+0.5f)*0.5f);
	        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+2] ), float(rz+1)*10+m_cHmap.m_ViewOffsetZ);
	
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //13
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+3]]);
			glTexCoord2f((fx+0.5f)*0.5f,(fz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+3] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //14
	        glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
	        glTexCoord2f(fx,fz);
            glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

            //9
			if(LODmap[128+z][128+x+1]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+256]]);
			    glTexCoord2f((fx+cx)*0.5f,(fz+cz)*0.5f);
		        glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+256]), float(rz+1)*10+m_cHmap.m_ViewOffsetZ);
			}
			//4
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
		    glTexCoord2f(cx,cz);
	        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

            //3
			if(LODmap[128+z-1][128+x]==1)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+3]]);
			    glTexCoord2f((gx+cx)*0.5f,(gz+cz)*0.5f);
		        glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+3] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
			}	
            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			///////////////////////////////////
			//////////////////right_down
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //18
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+3]]);
			glTexCoord2f((bx+0.5f)*0.5f,(bz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+3] ), float((rz+3)*10+m_cHmap.m_ViewOffsetZ));
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//17
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+2]]);
		    glTexCoord2f((ex+0.5f)*0.5f,(ez+0.5f)*0.5f);
	        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+2] ), float(rz+3)*10+m_cHmap.m_ViewOffsetZ);
		
			//22
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			glTexCoord2f(ex,ez);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
            //23
			if(LODmap[128+z+1][128+x]==1)
			{
	    		glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+3]]);
		    	glTexCoord2f((ex+bx)*0.5f,(ez+bz)*0.5f);
		        glVertex3f(float(rx+3)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+3]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			}
            //24
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
		    glTexCoord2f(bx,bz);
		    glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
	
            //19
			if(LODmap[128+z][128+x+1]==1)
			{
		    	glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+768]]);
			    glTexCoord2f((bx+fx)*0.5f,(bz+fz)*0.5f);
		        glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+768]), float(rz+3)*10+m_cHmap.m_ViewOffsetZ);
			}
            //14
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
		    glTexCoord2f(fx,fz);
		    glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
	
            //13
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+3]]);
			glTexCoord2f((fx+0.5f)*0.5f,(fz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+3] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			glEnd();


			numTriangles+=32;
}
void CTerrain::DrawLevel_2(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x+128-1,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+128+1,z+128+1);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+128+1,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];
			int base5=GetPos(x+128,z-1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz,ex,ez,fx,fz,gx,gz,hx,hz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			ex=(ax+bx)*0.5f;	ez=(az+bz)*0.5f;
            fx=(bx+cx)*0.5f;    fz=(bz+cz)*0.5f;
			gx=(cx+dx)*0.5f;    gz=(cz+dz)*0.5f;
			hx=(dx+ax)*0.5f;    hz=(dz+az)*0.5f;
			///////////////////////////////////
			//////////////////Left_up
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //6
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+1]]);
			glTexCoord2f((dx+0.5f)*0.5f,(dz+0.5f)*0.5f);
		    glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+1] ), float((rz+1)*10+m_cHmap.m_ViewOffsetZ));
            //0
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

            //0
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();

			///////////////////////////////////
			//////////////////Left_down
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //16
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+1]]);
			glTexCoord2f((ax+0.5f)*0.5f,(az+0.5f)*0.5f);
		    glVertex3f(float((rx+1)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+1] ), float((rz+3)*10+m_cHmap.m_ViewOffsetZ));
            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

            //20
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			//21

			//22
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			glTexCoord2f(ex,ez);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
	
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //10
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			glTexCoord2f(hx,hz);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512]), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			///////////////////////////////////
			//////////////////right_up
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //8
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+256+3]]);
			glTexCoord2f((cx+0.5f)*0.5f,(cz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+256+3] ), float((rz+1)*10+m_cHmap.m_ViewOffsetZ));
            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
	
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
            //14
	        glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
	        glTexCoord2f(fx,fz);
            glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);

			//4
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
		    glTexCoord2f(cx,cz);
	        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

            //2
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			glTexCoord2f(gx,gz);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			///////////////////////////////////
			//////////////////right_down
			///////////////////////////////////
			glBegin(GL_TRIANGLE_FAN);
            //18
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+768+3]]);
			glTexCoord2f((bx+0.5f)*0.5f,(bz+0.5f)*0.5f);
		    glVertex3f(float((rx+3)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+768+3] ), float((rz+3)*10+m_cHmap.m_ViewOffsetZ));
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
     		//22
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			glTexCoord2f(ex,ez);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);

            //24
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
		    glTexCoord2f(bx,bz);
		    glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);

            //14
		    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
		    glTexCoord2f(fx,fz);
		    glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			//12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float(rx+2)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			glEnd();

			numTriangles+=16;
}

void CTerrain::DrawLevel_3(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x-1+128,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+1+128,z+1+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+1+128,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];
			int base5=GetPos(x+128,z-1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			glBegin(GL_TRIANGLE_FAN);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float((rz+2)*10+m_cHmap.m_ViewOffsetZ));

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            

			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
				//glColor3fv(cNormal.m_3dEColor[ColorIndex[base0+256]]);
			    glTexCoord2f((ax+dx)*0.5f,(az+dz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);


			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			

			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			    glTexCoord2f((ax+bx)*0.5f,(az+bz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
	

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);

	
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
				//glColor3fv(cNormal.m_3dEColor[ColorIndex[base4+256]]);
			    glTexCoord2f((cx+bx)*0.5f,(cz+bz)*0.5f);
		        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
	
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);


			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			    glTexCoord2f((cx+dx)*0.5f,(cz+dz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
		

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			/////////////////////////blend
			/*
			glBindTexture(GL_TEXTURE_2D, Detail[0]);
			glEnable(GL_TEXTURE_2D);
//			glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_COLOR);
			glBlendFunc(GL_SRC_COLOR,GL_DST_COLOR);
			glEnable(GL_BLEND);
			glBegin(GL_TRIANGLE_FAN);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float((rz+2)*10+m_cHmap.m_ViewOffsetZ));

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            

			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
				//glColor3fv(cNormal.m_3dEColor[ColorIndex[base0+256]]);
			    glTexCoord2f((ax+dx)*0.5f,(az+dz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);


			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			

			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			    glTexCoord2f((ax+bx)*0.5f,(az+bz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
	

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);

	
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
				//glColor3fv(cNormal.m_3dEColor[ColorIndex[base4+256]]);
			    glTexCoord2f((cx+bx)*0.5f,(cz+bz)*0.5f);
		        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
	
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);


			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			    glTexCoord2f((cx+dx)*0.5f,(cz+dz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
		

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();

			glDisable(GL_BLEND);

  */
			numTriangles+=8;
}
void CTerrain::DrawLevel_4(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x-1+128,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+1+128,z+1+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+1+128,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];
//			int base5=GetPos(x+128,z-1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			glBegin(GL_TRIANGLE_FAN);
            //12
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512+2]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512+2] ), float((rz+2)*10+m_cHmap.m_ViewOffsetZ));
            //0
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            //10
			if(LODmap[128+z][128+x-1]<4)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+512]]);
			    glTexCoord2f((ax+dx)*0.5f,(az+dz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			}
            //20
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			//22
			if(LODmap[128+z+1][128+x]<4)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2+2]]);
			    glTexCoord2f((ax+bx)*0.5f,(az+bz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2+2] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			}
            //24
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
            //14
			if(LODmap[128+z][128+x+1]<4)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4+512]]);
				//glColor3fv(cNormal.m_3dEColor[ColorIndex[base4+256]]);
			    glTexCoord2f((cx+bx)*0.5f,(cz+bz)*0.5f);
		        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4+512] ), float(rz+2)*10+m_cHmap.m_ViewOffsetZ);
			}			
            //4
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            //2
			if(LODmap[128+z-1][128+x]<4)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0+2]]);
			    glTexCoord2f((cx+dx)*0.5f,(cz+dz)*0.5f);
		        glVertex3f(float((rx+2)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0+2] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
			}	
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();

			numTriangles+=4;
}

void CTerrain::DrawLevel_5(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x-1+128,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+1+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+1+128,z+1+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+1+128,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			glBegin(GL_TRIANGLE_FAN);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base3]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base4]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+4)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			numTriangles+=2;
}

void CTerrain::DrawLevel_6(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
			int base1=GetPos(x+128,z+2+128);
			int base2=GetPos(x+2+128,z+2+128);
			int base3=GetPos(x+2+128,z+128);
			int base4=GetPos(x+1+128,z+1+128);

			int base5=GetPos(x+128,z+1+128);
			int base6=GetPos(x+1+128,z+2+128);
			int base7=GetPos(x+2+128,z+1+128);
			int base8=GetPos(x+1+128,z+128);

	        float ax,az,bx,bz,cx,cz,dx,dz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			glBegin(GL_TRIANGLE_FAN);
 
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			glTexCoord2f(0.5f,0.5f);
		    glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float((rz+4)*10+m_cHmap.m_ViewOffsetZ));

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
   
			if(LODmap[128+z][128+x-2]!=7)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base5]]);
			    glTexCoord2f((ax+dx)*0.5f,(az+dz)*0.5f);
		        glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base5] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			}

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base1]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base1]), float(rz+8)*10+m_cHmap.m_ViewOffsetZ);

			if(LODmap[128+z+2][128+x]!=7)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base6]]);
			    glTexCoord2f((ax+bx)*0.5f,(az+bz)*0.5f);
		        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base6] ), float(rz+8)*10+m_cHmap.m_ViewOffsetZ);
			}
       
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+8)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2] ), float(rz+8)*10+m_cHmap.m_ViewOffsetZ);
      
			if(LODmap[128+z][128+x+2]!=7)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base7]]);
			    glTexCoord2f((cx+bx)*0.5f,(cz+bz)*0.5f);
		        glVertex3f(float((rx+8)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base7] ), float(rz+4)*10+m_cHmap.m_ViewOffsetZ);
			}			
    
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+8)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
            //2
			if(LODmap[128+z-2][128+x]!=7)
			{
			    glNormal3fv(cNormal.m_3dENormal[NormalIndex[base8]]);
			    glTexCoord2f((cx+dx)*0.5f,(cz+dz)*0.5f);
		        glVertex3f(float((rx+4)*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base8] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);
			}	
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();

			numTriangles+=4;
}
void CTerrain::DrawLevel_7(int x,int z)
{
            int rx=x*4;
	        int rz=z*4;
			int base0=GetPos(x+128,z+128);
//			int base1=GetPos(x-1+128,z+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x-1];
			int base2=GetPos(x+128,z+2+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x];
			int base3=GetPos(x+2+128,z+2+128);//m_cHmap.m_pMovemap[(128+z)*256+128+x+1];
			int base4=GetPos(x+2+128,z+128);//m_cHmap.m_pMovemap[(128+z+1)*256+128+x+1];

	        float ax,az,bx,bz,cx,cz,dx,dz;
            //////////////////////////// 
			glBindTexture(GL_TEXTURE_2D, Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureIndex);
			glEnable(GL_TEXTURE_2D);
			////////////Get Texture Order////////////////
			switch(Skinmap[GetZpos(x,z)/4][GetXpos(x,z)/4].TextureOrder)
            {
			case 0:
                ax=0; az=0; bx=1;bz=0;  cx=1;cz=1;  dx=0; dz=1;	break;
			case 1:
                ax=1; az=0; bx=1;bz=1;  cx=0;cz=1;  dx=0; dz=0;	break;
			case 2:
                ax=1; az=1; bx=0;bz=1;  cx=0;cz=0;  dx=1; dz=0;	break;
    		case 3:
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;
			default :
                ax=0; az=1; bx=0;bz=0;  cx=1;cz=0;	dx=1; dz=1;	break;   
			}
			glBegin(GL_TRIANGLE_FAN);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base0]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base0]]);
			glTexCoord2f(dx,dz);
		    glVertex3f(float(rx*10)+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base0] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base2]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base2]]);
			glTexCoord2f(ax,az);
		    glVertex3f(float(rx)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base2]), float(rz+8)*10+m_cHmap.m_ViewOffsetZ);
			
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base3]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base3]]);
			glTexCoord2f(bx,bz);
		    glVertex3f(float(rx+8)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base3] ), float(rz+8)*10+m_cHmap.m_ViewOffsetZ);
			
			glNormal3fv(cNormal.m_3dENormal[NormalIndex[base4]]);
			//glColor3fv(cNormal.m_3dEColor[ColorIndex[base4]]);
			glTexCoord2f(cx,cz);
		    glVertex3f(float(rx+8)*10+m_cHmap.m_ViewOffsetX,  float(m_cHmap.m_pTmap[base4] ), float(rz)*10+m_cHmap.m_ViewOffsetZ);

			glEnd();
			numTriangles+=2;
}
int  CTerrain::GetPos(int x,int z)
{
	return m_cHmap.m_pMovemap[(z)*256+x].zpos*256+m_cHmap.m_pMovemap[(z)*256+x].xpos;
}
int  CTerrain::GetXpos(int x,int z)
{
	return m_cHmap.m_pMovemap[(128+z)*256+128+x].xpos;
}
int  CTerrain::GetZpos(int x,int z)
{
	return m_cHmap.m_pMovemap[(128+z)*256+128+x].zpos;
}
CTerrain::~CTerrain()
{
	for(int i=0;i<4;i++)
	    glDeleteTextures(1,&Blend[i]);

	for(i=0;i<5;i++)
	{
		glDeleteTextures(1,&BaseA[i]);
		glDeleteTextures(1,&BaseB[i]);
	}
}
int CTerrain::GetNumTriangles()
{
	return numTriangles;
}
