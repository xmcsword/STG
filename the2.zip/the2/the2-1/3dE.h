// 3dE.h: interface for the C3dE class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DE_H__5700AE62_401D_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_3DE_H__5700AE62_401D_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "heightmap.h"
#include "input.h"
#include "gamesetting.h"

class C3dE  
{
public:
	C3dE();
	virtual ~C3dE();
	bool Init3dExplorer();
	void Reset3dExplorerPos();
   	void ProcessInput();
	void TransformWorld(int step);
	void UpdateHeightmap();
	//////////////////////////////
//protected:
    void   ChangeFOVAngle();

	bool         m_bAttacked;
    bool         m_bAttacking;


	CHeightmap      m_cHmap;

    CInput          m_cInput;
	CGameSetting    m_cGS;


	float        m_Height;
	float        m_baseHeight;
    VERTEX       m_eyePos;

	float     m_RotX;
	float     m_RotY;
	float     m_RotZ;

	NORMAL m_RunVector;
	float  m_JumpSpeed;
	float  m_MaxRunSpeed;
	float  m_Acceleration;
	float  m_Decrease;
	float  m_AirDecrease;
	float  m_Gravity;
	bool   m_bFlying;
	float  m_maxDifferent;  //�ɿ�Խ�����߶�

    float  m_YBiasAngle;
	float  m_YBias;
    float  m_ZBiasAngle;
	bool   m_bBiasLeft;

	float  m_gunYBias;
	float  m_gunZBias;
	int    m_gunState;

	///////////////////for zoom
	float  m_maxFOVAngle; 
	float  m_minFOVAngle;
	float  m_orgFOVAngle;
	float  m_curFOVAngle; 
	bool   m_bZoomed;
	bool   m_bZoomOut;
	int    m_iZoomAngle;

	float  m_mouseSpeed;

};

#endif // !defined(AFX_3DE_H__5700AE62_401D_11D6_812C_5254AB37CDC9__INCLUDED_)
