
/////////////////texturedef.h/////////////

#if !defined(__STRUCT__TEXTURE_DEFINE__)
#define __STRUCT__TEXTURE_DEFINE__
//////////////////////////////////////////
#define  MAX_TEXTURE_NUM               160
//////////////////////////////////////////

//////////////for test
#define  TEX_TEST0                     0
#define  TEX_TEST1                     1

#define  TEX_IMAGE_TEXT                2

///////////// Menu background
#define  TEX_MENU_BKG                  3
#define  TEX_SCREEN_CAPTURE            4
#define  TEX_MENU_CURSOR               5

///////////// My Photos
#define  TEX_MY_PHOTO_0                7
#define  TEX_MY_PHOTO_1                8
#define  TEX_MY_PHOTO_2                9
#define  TEX_MY_PHOTO_3                10

////////////  Hero Photos
#define  TEX_HERO_PHOTO_0              13
#define  TEX_HERO_PHOTO_1              14
#define  TEX_HERO_PHOTO_2              15
#define  TEX_HERO_PHOTO_3              16

////////////  Mission Sketch
#define  TEX_MISSION_SKETCH_0          20
#define  TEX_MISSION_SKETCH_1          21
#define  TEX_MISSION_SKETCH_2          22
#define  TEX_MISSION_SKETCH_3          23
#define  TEX_MISSION_SKETCH_4          24
#define  TEX_MISSION_SKETCH_5          25
#define  TEX_MISSION_SKETCH_6          26
#define  TEX_MISSION_SKETCH_7          27
#define  TEX_MISSION_SKETCH_8          28
#define  TEX_MISSION_SKETCH_9          29
#define  TEX_MISSION_SKETCH_10         30
#define  TEX_MISSION_SKETCH_11         31
#define  TEX_MISSION_SKETCH_12         32
#define  TEX_MISSION_SKETCH_13         33
#define  TEX_MISSION_SKETCH_14         34
#define  TEX_MISSION_SKETCH_15         35

///////////Mission
#define  TEX_MISSION_TEST_0            36
#define  TEX_MISSION_TEST_1            37
#define  TEX_MISSION_TEST_2            38

#define  TEX_SKY_0                     40
#define  TEX_SKY_1                     41
#define  TEX_SKY_2                     42
#define  TEX_SKY_3                     43
#define  TEX_SKY_4                     44

#define  TEX_TERRAIN_A1                48
#define  TEX_TERRAIN_A2                49
#define  TEX_TERRAIN_A3                50
#define  TEX_TERRAIN_A4                51
#define  TEX_TERRAIN_A5                52


#define  TEX_TERRAIN_B1                55
#define  TEX_TERRAIN_B2                56
#define  TEX_TERRAIN_B3                57
#define  TEX_TERRAIN_B4                58
#define  TEX_TERRAIN_B5                59

#define  TEX_TERRAIN_SKN1              61
#define  TEX_TERRAIN_SKN2              62
#define  TEX_TERRAIN_SKN3              63
#define  TEX_TERRAIN_SKN4              64

#define  TEX_TERRAIN_DETAIL_0          67
#define  TEX_TERRAIN_DETAIL_1          68
#define  TEX_TERRAIN_DETAIL_2          69

#define  TEX_LENSFLARE_0               71
#define  TEX_LENSFLARE_1               72
#define  TEX_LENSFLARE_2               73
#define  TEX_LENSFLARE_3               74
#define  TEX_LENSFLARE_4               75
#define  TEX_LENSFLARE_5               76
#define  TEX_LENSFLARE_6               77

#define  TEX_SMOKE_0                   80
#define  TEX_SMOKE_1                   81

#define  TEX_WEAPON_0                  85
#define  TEX_WEAPON_1                  86
#define  TEX_WEAPON_2                  87

#define  TEX_BRANCH_0                  90
#define  TEX_BRANCH_1                  91
#define  TEX_BRANCH_2                  92
#define  TEX_BRANCH_3                  93
#define  TEX_BRANCH_4                  94
#define  TEX_BRANCH_5                  95

#define  TEX_TREEBODY_0                98
#define  TEX_TREEBODY_1                99
#define  TEX_TREEBODY_2                100

#define  TEX_BUSH_0                    102
#define  TEX_BUSH_1                    103
#define  TEX_BUSH_2                    104

#define  TEX_GRASS_0                   106
#define  TEX_GRASS_1                   107

////////////////////////model texture
#define  TEX_SOILDER                   110
#define  TEX_WEAPON                    111
#define  TEX_FRAG                      112
#define  TEX_KNIFE                     113
#define  TEX_M4                        114
#define  TEX_M5                        115
#define  TEX_SNIPER                    116
#define  TEX_MY_GUN                    117
#define  TEX_GUN_FIRE                  118
#define  TEX_METAL                     119

////////////////////// building
#define  TEX_HOUSE_0                   120
#define  TEX_HOUSE_1                   121
#define  TEX_HOUSE_2                   122
#define  TEX_HOUSE_3                   123

////////////////////////navigator
#define  TEX_NAVIGATOR                 125
#define  TEX_HELP                      126
#define  TEX_DOCUMENT                  127


////////////////////////////////////////////////
#endif 
 