// Bullet.cpp: implementation of the CBullet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Bullet.h"
#include "texture.h"
#include "math.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBullet::CBullet()
{
	m_bulletType=M16;

}
CBullet::~CBullet()
{
}
bool CBullet::InitBullet(VERTEX  startPos,float rotx,float roty,NORMAL direction,unsigned int *texResource,int type)
{
	m_pTexResource=texResource;
	m_bulletType=type;
    m_CurPos=startPos;
	m_oldPos=startPos;
	m_rotX=rotx;
	m_rotY=roty;
	m_rotZ=0;
    m_direction = direction;
    m_life=350;

    switch(m_bulletType)
	{
	case M16:
    	m_Speed=3.0f;
		break;
	case RIFLE:
    	m_Speed=3.0f;
		break;
	case ROCKET:
//		m_rocket.InitParticle(startPos,m_pTexResource,BULLET_P,direction);
    	m_Speed=2.0f;
		break;
	}

	return true;
}
bool CBullet::InitBullet(VERTEX  startPos,float rotx,float roty,unsigned int *texResource,int type)
{
	m_pTexResource=texResource;
    NORMAL direction;
    direction.nx=-cosf(rotx*0.0174533f)*sinf(roty*0.0174533f);
    direction.ny=-sinf(rotx*0.0174533f);
    direction.nz=-cosf(rotx*0.0174533f)*cosf(roty*0.0174533f);
    InitBullet(startPos,rotx,roty,direction,m_pTexResource,type);
	return true;
}
void CBullet::UpdateBullet()
{
	m_oldPos=m_CurPos;
	m_CurPos.xpos+=m_direction.nx*m_Speed;
	m_CurPos.ypos+=m_direction.ny*m_Speed;
	m_CurPos.zpos+=m_direction.nz*m_Speed;
    if(m_cHmap.CollideCheck(m_oldPos,m_CurPos,0,2))
	{
		m_life=-1;
	}
    else 
	{
		if(m_bulletType==M16)DrawM16Bullet();
		if(m_bulletType==RIFLE)DrawRifleBullet();
		if(m_bulletType==ROCKET)DrawRocketBullet();
		m_life--;
	}
}

void CBullet::DrawRifleBullet()
{
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
 	glBindTexture(GL_TEXTURE_2D,m_pTexResource[0] );   
	glBlendFunc(GL_ONE,GL_ONE);
	glEnable(GL_BLEND);	
	float size=0.1f;
    glPushMatrix();	
	glTranslatef(m_CurPos.xpos,m_CurPos.ypos,m_CurPos.zpos);
	glRotatef(m_rotY,  0.0f,1.0f,0.0f);
	glRotatef(-m_rotX,  1.0f,0.0f,0.0f);

	glBegin(GL_TRIANGLE_STRIP);
	    glTexCoord2f(0,0);
	    glVertex3f(-size,-size,0);
	    glTexCoord2f(1,0);
	    glVertex3f(size,-size,0);	    
	    glTexCoord2f(0,1);
        glVertex3f(-size,size,0);
	    glTexCoord2f(1,1);
	    glVertex3f(size,size,0);
	glEnd();
    glPopMatrix();
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);	
}
void CBullet::DrawM16Bullet()
{
	glDisable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);
 	glBindTexture(GL_TEXTURE_2D,m_pTexResource[0]  );    

	float size=0.05f;
    glPushMatrix();	
	glTranslatef(m_CurPos.xpos,m_CurPos.ypos,m_CurPos.zpos);
	glRotatef(m_rotY,  0.0f,1.0f,0.0f);
//	glRotatef(m_rotZ,  0.0f,1.0f,0.0f);	
	glRotatef(-m_rotX,  1.0f,0.0f,0.0f);

	glBegin(GL_TRIANGLE_FAN);
	    glTexCoord2f(0,1);
	    glVertex3f(0,0,-size*100);

	    glTexCoord2f(0,0);
	    glVertex3f(-size,0,0);
	    glTexCoord2f(1,0);
	    glVertex3f(size,0,0);
	    glTexCoord2f(0,0);
	    glVertex3f(0,size,0);
	    glTexCoord2f(1,0);
	    glVertex3f(-size,0,0);

	glEnd();
    glPopMatrix();
	glEnable(GL_CULL_FACE);
	glDisable(GL_BLEND);

}
void  CBullet::DrawRocketBullet()
{
 //   m_rocket.DrawParticles(m_CurPos,m_direction);
}
void  CBullet::DrawExplosion()
{
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_ALPHA_TEST);
	glDisable(GL_CULL_FACE);
 	glBindTexture(GL_TEXTURE_2D,m_pTexResource[3] );    
	glBlendFunc(GL_ONE,GL_ONE);
	glEnable(GL_BLEND);  
	float size=3.0f;
    glPushMatrix();	
	glTranslatef(m_oldPos.xpos,m_oldPos.ypos,m_oldPos.zpos);
	glRotatef(m_rotY,  0.0f,1.0f,0.0f);
	
	glBegin(GL_TRIANGLE_STRIP);
	    glTexCoord2f(0,0);
	    glVertex3f(-size,0,0);
	    glTexCoord2f(1,0);
	    glVertex3f(size,0,0);	    
	    glTexCoord2f(0,1);
        glVertex3f(-size,2*size,0);
	    glTexCoord2f(1,1);
	    glVertex3f(size,2*size,0);
	glEnd();
    glPopMatrix();
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
}

void  CBullet::DrawGunFire()
{
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_ALPHA_TEST);
	glDisable(GL_CULL_FACE);
	glBlendFunc(GL_ONE,GL_ONE);
	glEnable(GL_BLEND);
 	glBindTexture(GL_TEXTURE_2D,m_pTexResource[3]);    
	float size=0.05f;
    glPushMatrix();	
	glTranslatef(m_oldPos.xpos,m_oldPos.ypos,m_oldPos.zpos);
	glRotatef(m_rotY,  0.0f,1.0f,0.0f);
	glRotatef(-m_rotX,  1.0f,0.0f,0.0f);	
	glBegin(GL_TRIANGLE_STRIP);
	    glTexCoord2f(0,0);
	    glVertex3f(-size,-size,0);
	    glTexCoord2f(1,0);
	    glVertex3f(size,-size,0);	    
	    glTexCoord2f(0,1);
        glVertex3f(-size,size,0);
	    glTexCoord2f(1,1);
	    glVertex3f(size,size,0);
	glEnd();
    glPopMatrix();
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
}
