// Heightmap.h: interface for the CHeightmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEIGHTMAP_H__5700AE61_401D_11D6_812C_5254AB37CDC9__INCLUDED_)
#define AFX_HEIGHTMAP_H__5700AE61_401D_11D6_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"
#include "FrustumCull.h"
#include "cmath.h"

#define FOCUS_GROUND 0
#define FOCUS_BODY   1 

class CHeightmap  
{
public:
	CHeightmap();
	virtual ~CHeightmap();
	void UpdateHeightmap();

	float   GetHeight(VERTEX *WorldChecked);
	float   GetHeight(float Worldxpos,float Worldzpos);
	void    GetFocusPos();
	bool    CollideCheck(VERTEX startPos,VERTEX endPos,float step);
    bool    CollideTreeBody(VERTEX *check);
    bool    CollideBuilding(VERTEX *oldPos,VERTEX *newPos);
	bool    IsInFrustum(VERTEX *checked);
	bool    IsInFrustum(float x,float z);
	bool    IsInFrustum(BOUNDARY_3D *pBoundary);
    POINT   ConvertToMovemap(VERTEX pos);
	VERTEX  ConvertToWorld(int movemapXPos,int movemapZPos);
	POINT   ConvertToPlantmap(float worldX,float worldZ);

	static MOVE_VERTEX    * m_pMovemap;
	//����(128,128)��¼�۲��ߵľ���λ��
	static CFrustumCull   m_cFrustumCull;

	static unsigned char  * m_pTmap;    //terrain map
	//��������

	static GRID_BIAS      * m_pCoverBias;
	static unsigned char  * m_pCovermap;
	//ֲ������

	static VERTEX           m_ViewPos;
    static int              m_ViewOffsetX;
    static int              m_ViewOffsetZ;

	//�۲���ƫ���������꣨0��0��0����ʵ�ʾ���

	static float            m_ViewRotX;
	static float            m_ViewRotY;
    ////////////////////Ŀ��
    static double           m_focusPosX;//��Ļ���ĵ����������
    static double           m_focusPosY;
    static double           m_focusPosZ;
	static double           m_distFromFocus;
	static int              m_focusState;
	static bool             m_bAttack;
	static float            m_myHealth;
    //////////////////����������
	static int              m_numBuilding;
	static VERTEX          *m_buildingPos;
	static BOUNDARY_3D    **m_bigBndyBuilding;
	static BOUNDARY_3D    **m_smallBndyBuilding;
	//////////////////ʿ��
	static int              m_numSoldier;
	static VERTEX          *m_soldierPos;
    static float           *m_soldierRot;
	static float           *m_soldierHealth;
	/////////////////////////////////////
	static int              m_numTriangles;
private:
	bool    GetMissionSetting();

    bool    CheckTreeCollide(VERTEX startPos,VERTEX endPos);
    bool    CheckTerrainCollide(VERTEX startPos,VERTEX endPos,float step);
    bool    CheckBuildingCollide(VERTEX startPos,VERTEX endPos);

	bool    ReadTerrainmapFile();
	bool    ReadPlantmapFile();
	int     GetPosInMovemap(int x,int z);
	int     GetPlantType(int mapx,int mapz);
    POINT   ConvertToHeightmap(VERTEX *pos);
	bool    IsInBoundary3D(VERTEX *pos, BOUNDARY_3D *boundary);
    void    MakeModulePath(char filename[], char sINIPath[]);

	CMath                  m_cMath;
	static int             m_numUser;

};

#endif // !defined(AFX_HEIGHTMAP_H__5700AE61_401D_11D6_812C_5254AB37CDC9__INCLUDED_)
