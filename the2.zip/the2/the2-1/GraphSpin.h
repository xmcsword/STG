// GraphSpin.h: interface for the CGraphSpin class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHSPIN_H__43FBFC01_A10D_11D2_814D_5254AB37CDC9__INCLUDED_)
#define AFX_GRAPHSPIN_H__43FBFC01_A10D_11D2_814D_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "graphbutton.h"

class CGraphSpin : public CGraphButton
{
public:
	CGraphSpin();
	virtual ~CGraphSpin();
	void     SetSpin(RECT rect,bool isFirstSpin,bool bHorizontal=true);
 	void     RenderSpin();
    bool     m_bChangValue;
private:
	void     UpdateSpin();
	bool     m_bFirstSpin;
	bool     m_bHorz;
	int      m_iPushedTime;
};

#endif // !defined(AFX_GRAPHSPIN_H__43FBFC01_A10D_11D2_814D_5254AB37CDC9__INCLUDED_)
