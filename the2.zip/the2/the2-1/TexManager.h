// TexManager.h: interface for the CTexManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXMANAGER_H__3754CAE1_AEF6_11D6_815A_5254AB37CDC9__INCLUDED_)
#define AFX_TEXMANAGER_H__3754CAE1_AEF6_11D6_815A_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "TextureDef.h"

class CTexManager  
{
public:
	CTexManager();
	virtual ~CTexManager();
	bool          CreateMenuResource();
	bool          CreateMissionResource();
	bool          CreateTempMenuResource();
	void          DeleteMenuResource();
	void          DeleteMissionResource();
	void          DeleteTempMenuResource();

	static unsigned int  GetTextureID(int texDefineName);
	
private:
    static unsigned int *m_texList;
	static int           m_numUser;
};

#endif // !defined(AFX_TEXMANAGER_H__3754CAE1_AEF6_11D6_815A_5254AB37CDC9__INCLUDED_)
