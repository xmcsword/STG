// GraphEdit.cpp: implementation of the CGraphEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphEdit.h"
#include "gamesetting.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraphEdit::CGraphEdit()
{
	m_bEditting=false;
	m_bEnableEdit=true;
	m_bHeightLight=false;
}

CGraphEdit::~CGraphEdit()
{
}
void CGraphEdit::SetEdit(RECT rect,char *sText,int iMaxChar)
{
	if(iMaxChar>31)iMaxChar=31;
	int len=strlen(sText);

	if(len>iMaxChar)
	    sText[iMaxChar]=NULL;

	CGraphButton::SetButton(rect,sText);
	m_iMaxChar=iMaxChar;
}
void CGraphEdit::RenderEdit()
{ 
	UpdateEdit();
	CGraphButton::RenderButton();	

}
void CGraphEdit::UpdateEdit()
{
	if(!m_bEnableEdit)return;

	static int flicker=0;
	flicker++;
	if(flicker>50)flicker=0;
	char cCursor[1];
	if(flicker<25)wsprintf(cCursor," ");
	else wsprintf(cCursor,"_");

	m_cInput.m_bAskTrans=true;

    if(m_bSelected)
	{
		m_bSelected=false;
		int len=strlen(m_sText);
		if(len<m_iMaxChar)
		    strcat(m_sText, cCursor);
		else
			m_sText[m_iMaxChar-1]=cCursor[0];

		m_bEditting=true;
		m_cInput.m_bShowMouse=false;
	}
	if(m_bEditting)
	{
		//////////flicker
        int len=strlen(m_sText);
		m_sText[len-1]=cCursor[0];
		//////////// mouse cling
		SetCursorPos((m_rect.left+m_rect.right)/2,(m_rect.top+m_rect.bottom)/2);
		if(m_cInput.m_keys[MOUSE_0] ||m_cInput.m_keys[13]) // enter 
		{
			m_cInput.m_keys[MOUSE_0]=false;
			m_cInput.m_keys[13]=false;
            FinishEdit();
			return;
		}	
        if(m_cInput.m_keys[8])// BackSpace
		{
			m_cInput.m_keys[8]=false;
			if(len>1)
			{
				m_sText[len-2]=cCursor[0];
				m_sText[len-1]=NULL;
			}
			return;
		}
		/*
		for(int i=0;i<5;i++) // up down left right
		{
			if(m_cInput.m_keys[i])m_cInput.m_keys[i]=false;
			return;
		}*/
		for(int i=32;i<128;i++)
		{	
			if(m_cInput.m_keys[i])
			{
				m_cInput.m_keys[i]=false;

				char a=i;
				int len=strlen(m_sText);
				m_sText[len-1]=a;
				strcat(m_sText, cCursor);
				len++;
				if((len)>m_iMaxChar)
				{
                    FinishEdit();
					return;
				}
			}
		}
	}
}
void  CGraphEdit::SetEnableEdit(bool bEnableEdit)
{
    m_bEnableEdit=bEnableEdit;
}
void  CGraphEdit::SetHeightLight(bool bHLight)
{
	m_bHeightLight=bHLight;
}
void  CGraphEdit::Clear()
{
	CGraphButton::SetButtonText("");
	m_bEnableEdit=true;
}
void  CGraphEdit::SetText(char *sText)
{
	CGraphButton::SetButtonText(sText);
}
void  CGraphEdit::GetFocus()
{
    SetCursorPos((m_rect.left+m_rect.right)/2,(m_rect.top+m_rect.bottom)/2);
	m_bSelected=true;
	m_bEnableEdit=true;
}
bool  CGraphEdit::IsEditting()
{
	return m_bEditting;
}
void CGraphEdit::FinishEdit()
{
	m_bEditting=false;
	m_cInput.m_bShowMouse=true;
    SetCursorPos((m_rect.left+m_rect.right)/2,m_rect.bottom+5);
	int len=strlen(m_sText);
    m_sText[len-1]=NULL;

	if(m_sText[0]!=NULL)m_bEnableEdit=false;
}