// SmokeParticle.h: interface for the CSmokeParticle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMOKEPARTICLE_H__87239981_B5DF_11D6_90D2_5254AB37CDC9__INCLUDED_)
#define AFX_SMOKEPARTICLE_H__87239981_B5DF_11D6_90D2_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "structdef.h"

class CSmokeParticle  
{
public:
	CSmokeParticle();
	virtual ~CSmokeParticle();
	void     InitParticle(unsigned int texid,float fade=0,int  particleNumber=50,float size=1);
	void     SetSmokeSize(float size);
	void     SetSmokeColor(float red,float green,float blue);
	void     SetGravity(float gravity);
	void     Reset();
	void     DrawParticle();

	PARTICLE    *particle;
	float        m_smokeLife;
	float        m_smokeFade;
	float        m_size;
	float        m_gravity;
private:
    void     SetSmokeParticle(int number);

	int          m_numParticle;
	float        m_color[3];
    unsigned int m_texID;
};

#endif // !defined(AFX_SMOKEPARTICLE_H__87239981_B5DF_11D6_90D2_5254AB37CDC9__INCLUDED_)
