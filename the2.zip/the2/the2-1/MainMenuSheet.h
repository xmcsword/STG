// MainMennSheet.h: interface for the CMainMenuSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINMENNSHEET_H__66701B2C_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_)
#define AFX_MAINMENNSHEET_H__66701B2C_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "graphButton.h"

#define  ITEM_NUM  5

class CMainMenuSheet  
{
public:
	CMainMenuSheet();
	virtual ~CMainMenuSheet();

	bool InitSheet();
	int  RenderSheet();

	int    m_iSelect;
	bool   m_bActive;
private:
	CGraphButton  m_cButton[ITEM_NUM];

};

#endif // !defined(AFX_MAINMENNSHEET_H__66701B2C_A5F2_11D6_814C_5254AB37CDC9__INCLUDED_)
