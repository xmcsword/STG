// HitParticle.cpp: implementation of the CHitParticle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HitParticle.h"
#include "heightmap.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHitParticle::CHitParticle()
{
	m_numFragment=30;
	particle=NULL;

	m_Life=1;
	m_Fade=0;

}

CHitParticle::~CHitParticle()
{
	if(particle!=NULL)delete [] particle;
}
void CHitParticle::InitParticle(VERTEX position ,unsigned int texSmoke,
					  int  smokeNumber,int fragmentNumber,
					  float size)
{
	CSmokeParticle::InitParticle(texSmoke,1/float(smokeNumber),smokeNumber,size);
	CSmokeParticle::SetGravity(0.006f);
	m_pos=position;

	m_numFragment=fragmentNumber;
	if(particle==NULL)
	    particle = new PARTICLE [ m_numFragment ];

    Reset(position);

}
void CHitParticle::Reset(VERTEX pos)
{
    CSmokeParticle::Reset();
	m_Life=1;
	m_pos=pos;
	for(int i=0;i<m_numFragment;i++)
		SetFragParticle(i);
}
void CHitParticle::Render()
{
	m_Life-=0.01f;
    glPushMatrix();	  
    glTranslated(m_pos.xpos,m_pos.ypos,m_pos.zpos);
    glRotatef(CHeightmap::m_ViewRotY,  0.0f,1.0f,0.0f);
    glRotatef(-CHeightmap::m_ViewRotX,  1.0f,0.0f,0.0f);
 	///////////////////////////////////////////////////////
	CSmokeParticle::DrawParticle();
	DrawFragment();
	///////////////////////////////////////////////////////
    glPopMatrix();
 }
void CHitParticle::DrawFragment()
{
// 	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_BLEND);
 
	glDisable(GL_TEXTURE_2D);
    
	for(int i=0;i<m_numFragment;i++)
	{
        if (particle[i].life > 0 )
        {
            particle[i].pos.xpos += particle[i].normal.nx;
            particle[i].pos.ypos += particle[i].normal.ny;
            particle[i].pos.zpos += particle[i].normal.nz;

            particle[i].normal.ny -= 0.02f;  // cheap simulated gravity
            particle[i].normal.nx *= 0.9f;
            particle[i].normal.ny *= 0.90f;
            particle[i].normal.nz *= 0.9f;

            particle[i].life -= particle[i].fade;

			particle[i].rotate +=10.0f;

            glColor4f(0,0,0,particle[i].life);
			
			glPushMatrix();
			
	          glTranslatef(particle[i].pos.xpos, particle[i].pos.ypos, particle[i].pos.zpos);
              glRotated(particle[i].rotate,1,1,1);
	          glTranslatef(-particle[i].pos.xpos, -particle[i].pos.ypos, -particle[i].pos.zpos);

            glBegin(GL_TRIANGLES);
              glTexCoord2d(1,1); 
			  glVertex3d( particle[i].pos.xpos,particle[i].pos.ypos,particle[i].pos.zpos);
              glTexCoord2d(1,0); 
			  glVertex3d( particle[i].pos.xpos+particle[i].size,particle[i].pos.ypos,particle[i].pos.zpos);
              glTexCoord2d(0,0); 
			  glVertex3d(particle[i].pos.xpos,particle[i].pos.ypos+particle[i].size,particle[i].pos.zpos);
            glEnd();

			glPopMatrix();

		}

	}
}
void CHitParticle::SetFragParticle(int i)
{
	if(i>(m_numFragment-1))return;
	if(m_Life<0)return ;
	/////////////////////////////////////////
  	particle[i].size =m_size*( (rand()%50)+20 )*0.025f; 

    particle[i].pos.xpos = m_size*((rand()%40)*0.1f-2)*particle[i].size;//  /75.f;
    particle[i].pos.ypos = m_size*((rand()%40)*0.1f-2)*particle[i].size;
    particle[i].pos.zpos = m_size*((rand()%40)*0.1f-2)*particle[i].size;

    particle[i].rotate = float(rand()%100-50);

    particle[i].normal.nx = float((rand()%50)-25)*0.01f;
    particle[i].normal.ny = float((rand()%50)-0)*0.02f+0.01f;
    particle[i].normal.nz = float((rand()%50)-25)*0.01f;

    particle[i].life = 1;
    particle[i].fade =float(rand()%100)/50000 + 0.01f;

}