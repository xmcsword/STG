// CGL.h: interface for the CGL class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CGL_H__C78240E8_DC59_11D5_812C_5254AB37CDC9__INCLUDED_)
#define AFX_CGL_H__C78240E8_DC59_11D5_812C_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGL  
{
public:
	CGL();
	virtual ~CGL();
	void SwapBuffers();
	void DestroyGL();
	bool InitGL( HWND hWnd, int iColorBits);
	void Resize(int iWidth, int iHeight);
	bool SetGLMenuState();
	bool SetGLMissionState();

private:
	HGLRC m_hRC;	// Permanent rendering context
	HDC m_hDC;		// Private GDI device context
	HWND m_hWnd;	// Window to wich the RC is attached
	float  m_fov;
};

#endif // !defined(AFX_CGL_H__C78240E8_DC59_11D5_812C_5254AB37CDC9__INCLUDED_)
