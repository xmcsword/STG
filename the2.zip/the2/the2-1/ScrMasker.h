// ScrMasker.h: interface for the CScrMasker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCRMASKER_H__27929741_AE0B_11D6_8159_5254AB37CDC9__INCLUDED_)
#define AFX_SCRMASKER_H__27929741_AE0B_11D6_8159_5254AB37CDC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CScrMasker
{
public:
	CScrMasker();
	virtual ~CScrMasker();
	static void  BrightnessCtrl();
	static void  MaskScreen(float r,float g,float b,bool bEnhance=true );
	static void  SprayBlood();
	static void  GrayScreen();
    static void  ElideLine();
	static void  FadeIn();
	static void  FadeOut();
private:
	static void  DrawMasker(float r,float g,float b);
	static int   m_iGammaBackup;
	static int   m_iTimer;
	static bool  m_bFadeIn;
	static bool  m_bFadeOut;
	static int   m_iSprayBlood;


};

#endif // !defined(AFX_SCRMASKER_H__27929741_AE0B_11D6_8159_5254AB37CDC9__INCLUDED_)
